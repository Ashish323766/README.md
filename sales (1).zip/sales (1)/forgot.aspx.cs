﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using MySql.Data.MySqlClient;
using System.Data.Odbc;
using System.Configuration;
using BussinessLogic;
using System.Net;
using System.IO;
using System.Text;
using System.Web.Services;

public partial class forgot : System.Web.UI.Page
{
    BusinessLogics blog = new BusinessLogics();
    AdminProperty objProp = new AdminProperty();
    protected void Page_Load(object sender, EventArgs e)
    {
    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        try
        {
            if (txtloginid.Value != "")
            {
                var send = recover(txtloginid.Value.Trim());
                if (send == "Y")
                {
                    string mgs = "Dear Member/Partner, You will receive your password on your registered mobile number (xxxxxx" + txtloginid.Value.Trim().Substring(txtloginid.Value.Trim().Length - 4) + ") shortly"; ;
                   // ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "showSuccess('" + mgs + "');", true);
                    txtloginid.Value = "";
                }
                else
                {
                  //  ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "showError('" + ErrorMessages.InvalidMobile + "');", true);
                }
            }
            else
            {
                // btnlogin.CssClass = "btn btn-primary tst3";
                // btnlogin.Attributes.Add("class", "btn btn-primary tst3");
                //    string Method = "<script language='javascript'>" + "$(document).ready(function () {'use strict';$('.btn3').click(function () { $.toast({ heading: 'Welcome to Material Pro admin',text: 'Use the predefined ones, or specify a custom position object.',position: 'top-right',loaderBg: '#ff6849',icon: 'success',hideAfter: 100000,stack: 6});});});" + "</script>";
                //diverror_alert.InnerHtml = ErrorMessages.EnterMobile;
                // imgpop.Src = objProp.alterUrl;
                //  ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "Script1", Method, true);
              //  ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "showError('" + ErrorMessages.EnterMobile + "');", true);
                // ClientScript.RegisterClientScriptBlock(this.GetType(), "script", "vii();", true);
                //  ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "Script1", "document.getElementByClassName('tst3').click();", true);
            }

        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "showError('" + ex.Message + "');", true);
        }
    }
    [WebMethod]
    public static string recover(string vartpin)
    {
        try
        {
            string strHostName = "NA";

            var otpwd1 = strHostName;
            BusinessLogics blog = new BusinessLogics();
            AdminProperty objProp = new AdminProperty();
            objProp.adminLoginId = vartpin;
            objProp.Query = @"select us_loginid,us_name ,us_password AS pass_word from aks_user_login where us_loginid =" + objProp.adminLoginId;
            blog.forgotPwd(objProp);

            if (objProp.DataReader.Read())
            {
                string strHostName1 = "";
                strHostName1 = System.Net.Dns.GetHostName();
                IPHostEntry ipEntry = System.Net.Dns.GetHostEntry(strHostName1);
                string ipaddress = Convert.ToString(ipEntry.AddressList[2]);
                string pww = objProp.DataReader["us_loginid"].ToString();
                string uname = objProp.DataReader["us_name"].ToString();
                objProp.Description = otpwd1;
                objProp.UserID = pww;
                objProp.ipaddress = ipaddress;
                objProp = blog.forgotpassword(objProp);
                if (objProp.Response != "N")
                {
                    string msg = "Dear " + uname + ", Your password is : " + objProp.Response + ". Please do not share with anyone. Team CityRecharge www.cityrecharge.in";
                    objProp.ApiUrl = "method=sendsms&loginid=" + objProp.adminLoginId + "&pwd=" + msg + "&templeteid=1207161770770474923";
                    blog.postMethodForForgotPassword(objProp);
                    return "Y";
                }
                else
                {
                    return objProp.Response;
                }
            }
            else
            {
                //  string f = "Valid Password";
                return "N";
            }
        }
        catch (Exception ea) { return "Z"; }
    }
}