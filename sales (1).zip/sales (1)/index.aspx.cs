﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Net;
using System.IO;
using System.Text;
using System.Web.Services;
using Newtonsoft.Json;
using MySql.Data.MySqlClient;
using System.Configuration;
using BussinessLogic;

public partial class index : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        diverr.Visible = false;
    }

    public void btncheckrotp_Click(object sender, EventArgs e)
    {
        Login("", "");
    }
    //[WebMethod]
    public void Login(string mobile, string password)
    {

        try
        {
            mobile = loginid.Value.Trim();
            password = passid.Value.Trim();

            if (mobile.Length < 9)
            {
                diverr.Visible = true;
                diverr.Attributes.Add("class", "alert alert-danger alert-dismissible bg-danger text-white border-0 fade show");
                lblmessgae.InnerHtml = "Invalid Mobile Number";

            }

            if (password.Length < 3)
            {
                diverr.Visible = true;
                diverr.Attributes.Add("class", "alert alert-danger alert-dismissible bg-danger text-white border-0 fade show");
                lblmessgae.InnerHtml = "Invalid Mobile or Password";

            }

            MySqlDataReader dTable = apiuserlogin(mobile, password);
            if (dTable.HasRows)
            {
                while (dTable.Read())
                {
                    if (dTable["id"].ToString() == "Y")
                    {
                        // Create Session
                        HttpContext.Current.Session["UserName"] = dTable["usname"].ToString();
                        HttpContext.Current.Session["UserCode"] = dTable["uscode"].ToString();
                        HttpContext.Current.Session["UserId"] = dTable["pkid"].ToString();
                        HttpContext.Current.Session["UserMobile"] = dTable["mobile"].ToString();
                        HttpContext.Current.Session["IsLogin"] = true;
                        //return JsonConvert.SerializeObject(JsonResponse.success("", ""));
                        diverr.Visible = true;
                        diverr.Attributes.Add("class", "alert alert-success alert-dismissible bg-success text-white border-0 fade show");
                        lblmessgae.InnerHtml = "Successfully Login";
                        Response.RedirectToRoute("dashboard");
                    }
                    else
                    {
                        diverr.Visible = true;
                        diverr.Attributes.Add("class", "alert alert-danger alert-dismissible bg-danger text-white border-0 fade show");
                        lblmessgae.InnerHtml = "Invalid Mobile or Password";
                    }
                }
                dTable.Close();
            }
        }
        catch (Exception ex)
        {
            diverr.Visible = true;
            diverr.Attributes.Add("class", "alert alert-danger alert-dismissible bg-danger text-white border-0 fade show");
            lblmessgae.InnerHtml = "Server Error" + ex.ToString();
        }
        finally
        {
            //Logging
        }

    }

    public static MySqlDataReader apiuserlogin(string mobile, string password)
    {
        try
        {
            MySqlParameter[] prm = new MySqlParameter[2];
            prm[0] = new MySqlParameter("_loginid", mobile);
            prm[1] = new MySqlParameter("_password", password);
            MySqlDataReader dSet = DataLayer.ExecuteReader(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "aks_sales_login", prm);

            return dSet;

        }
        catch (Exception ea)
        { throw; }

    }
}