﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Script.Services;
using System.Web.Services;

/// <summary>
/// Summary description for pm_services
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
// [System.Web.Script.Services.ScriptService]
public class pm_services : System.Web.Services.WebService {

    public pm_services () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public string HelloWorld() {
        return "Hello World";
    }
    [WebMethod]
    //[ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public LastSuccessTransaction.LastTransaction getPlan(PlanRequest objRequest)
    {
        // Rplan objRplan = new Rplan();
        LastSuccessTransaction.LastTransaction obj = new LastSuccessTransaction.LastTransaction();
        string data = GetMethod("http://apiv1.cityrecharge.in/recApiFinal/apiget.aspx?method=getPlanNew&login=" + objRequest.LoginId + "&mobile=" + objRequest.Mobile + "&operator=" + objRequest.Operator + "");
        return JsonConvert.DeserializeObject<LastSuccessTransaction.LastTransaction>(data);
    }

    public string GetMethod(string uri)
    {
        HttpWebRequest request = (HttpWebRequest)WebRequest.Create(uri);
        request.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;
        using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
        using (Stream stream = response.GetResponseStream())
        using (StreamReader reader = new StreamReader(stream))
        {
            return reader.ReadToEnd();
        }

    }
}
