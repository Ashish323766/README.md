﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Web;
using System.Net.Configuration;

using System.Data;
using MySql.Data.MySqlClient;
using System.Data.Odbc;
using System.Collections.Specialized;
using System.Configuration;
using System.Net;
using System.IO;
using System.Web.UI.WebControls;
using System.Web.Configuration;

/// <summary>
/// Summary description for BusinessLogics
/// </summary>
namespace BussinessLogic
{
    public class BusinessLogics
    {
        AdminProperty objProp = new AdminProperty();

public DataSet adminLoginWithOtp(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[4];
                prm[0] = new MySqlParameter("_loginid", objProp.adminLoginId);
                prm[1] = new MySqlParameter("_password", objProp.adminPassword);
                prm[2] = new MySqlParameter("_ipaddress", objProp.ipaddress);
                prm[3] = new MySqlParameter("_otp", objProp.otp);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_admin_login_with_otp", prm);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        	public DataSet adminLoginOtpVerify(AdminProperty objProp)
		{
			try
			{
				MySqlParameter[] prm = new MySqlParameter[2];
				prm[0] = new MySqlParameter("_mobile", objProp.Mobile);
				prm[1] = new MySqlParameter("_otp", objProp.otp);
				objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "askom_admin_verify_otp", prm);

				if (objProp.DataSet.Tables[0].Rows.Count > 0)
				{
				}

				return objProp.DataSet;

			}
			catch (Exception ea)
			{ throw; }
		}
        public DataSet adminLogin(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_loginid", objProp.adminLoginId);
                prm[1] = new MySqlParameter("_password", objProp.adminPassword);
                prm[2] = new MySqlParameter("_ipaddress", objProp.ipaddress);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_admin_login", prm);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }
        public DataSet createTicker(AdminProperty objProp)
        {

            try
            {

                MySqlParameter[] prm = new MySqlParameter[2];
                prm[0] = new MySqlParameter("_usid", objProp.UserID);
                prm[1] = new MySqlParameter("_msg", objProp.marqueetxt);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_create_marquee", prm);

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }
        public DataSet getmarqueedelete(AdminProperty objProp)
        {

            try
            {

                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }
        public DataSet manualRefund(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[2];
                prm[0] = new MySqlParameter("_transactionid", objProp.TrnsID);
                prm[1] = new MySqlParameter("_remark", objProp.Remark);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_recharge_manual_refund", prm);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet getBulkApiAllocationFiller(AdminProperty objProp)
        {
            try
            {
                objProp.Query = @"SELECT pk_allocate_id AS 'id',amount,(SELECT st_name FROM aks_service_type WHERE pk_service_id=fk_service_id) AS srname,
		(SELECT pdr_name FROM aks_provider WHERE pk_provider_id=fk_provider_id) AS pdrname,(SELECT tt_name FROM aks_transaction_type WHERE pk_ttype_id=fk_ttype_id) AS tname,
		(SELECT tarif_name FROM aks_tarif WHERE pk_tarif_id=fk_tarif_id) AS tfname,(SELECT api_name FROM aks_master_api WHERE pk_api_id=api_api1) AS api_api1,
		(SELECT api_name FROM aks_master_api WHERE pk_api_id=api_api2) AS api_api2,(SELECT api_name FROM aks_master_api WHERE pk_api_id=api_api3) AS api_api3
		,alc_comission AS 'alccomm',api_indate AS 'indate',api_indate AS 'update' FROM aks_api_allocate_recharge WHERE fk_provider_id= '" + objProp.providerlist + "' ";
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet getTransactionRecordType(AdminProperty objProp)
        {

            try
            {

                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_view_transaction_type");

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet getBulkApiAllocationRecord(AdminProperty objProp)
        {
            try
            {
                //sp_view_api_allocation_bulk
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_view_allocate_bulk");

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }

        public AdminProperty addrechargerehit(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[6];
                prm[0] = new MySqlParameter("_rchtid", objProp.transctnid);
                prm[1] = new MySqlParameter("_fkuserid", objProp.UserID);
                prm[2] = new MySqlParameter("_fkadminid", objProp.upkid);
                prm[3] = new MySqlParameter("_description", objProp.Description);
                prm[4] = new MySqlParameter("_apiid", objProp.ApiID);
                prm[5] = new MySqlParameter("_pdrid", objProp.PdrID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_recharge_rechit", prm);
                return objProp;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet Loadreceiveamount(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[9];
                prm[0] = new MySqlParameter("_userId", objProp.retpkid);
                prm[1] = new MySqlParameter("_amount", objProp.amount);
                prm[2] = new MySqlParameter("_receiveamount", objProp.rAmount);
                prm[3] = new MySqlParameter("_usercomment", objProp.comment);
                prm[4] = new MySqlParameter("_transactionid", objProp.transctnid);
                prm[5] = new MySqlParameter("_utrno", objProp.utrno);
                prm[6] = new MySqlParameter("_bankname", objProp.bankname);
                prm[7] = new MySqlParameter("_paymode", objProp.paymode);
                prm[8] = new MySqlParameter("_receivdate", objProp.rcvdate);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_receive_loadAmount", prm);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }
        public void fill_ddl(DropDownList dp, string Sp_Name, string textField, string textValue)
        {
            try
            {
                dp.Items.Clear();
                ListItem liState = new ListItem();
                liState.Text = "  Select  ";
                liState.Value = "-1";
                dp.Items.Add(liState);

                objProp.DataReader = DataLayer.ExecuteReader(ConfigurationManager.ConnectionStrings["champshopconstr"].ToString(), CommandType.Text, Sp_Name);
                while (objProp.DataReader.Read())
                {
                    ListItem li = new ListItem();
                    li.Value = objProp.DataReader[textField].ToString().Trim();
                    li.Text = objProp.DataReader[textValue].ToString().Trim();
                    dp.Items.Add(li);
                }
                objProp.DataReader.Close();
            }
            catch (Exception ex)
            {
               // Log_Detail("Blogic.cs" + ex.ToString());
            }
        }

        public DataSet CreateRole(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[5];
                prm[0] = new MySqlParameter("_roleName", objProp.RoleName);
                prm[1] = new MySqlParameter("_menu", objProp.RoleMenu);
                prm[2] = new MySqlParameter("_submenu", objProp.RoleSubMenu);
                prm[3] = new MySqlParameter("_desc", objProp.RoleDesc);
                prm[4] = new MySqlParameter("_createBy", objProp.RoleCreatedBy);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_create_role", prm);
            }
            catch (Exception ea)
            { throw; }
            return objProp.DataSet;
        }

        public AdminProperty bindcat_subcate(AdminProperty objProp)
        {
            try
            {
                objProp.Query = "SELECT `submenu_title`,`pk_submenu_id`,`fk_menu_id`,a.`menu_title` menu_parent_id FROM `aks_submenu` b , `aks_menu` a WHERE  b.`fk_menu_id`=a.pk_menu_id and b.fk_menu_id != '0' ORDER BY fk_menu_id,submenu_title ";
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);
                return objProp;
            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet createAEPSTarifPlanRecordList(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_trfname", objProp.TfName);
                prm[1] = new MySqlParameter("_trfcode", objProp.OpCode);
                prm[2] = new MySqlParameter("_old_tfrId", objProp.TarifID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_create_bulk_aepstariff", prm);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }

        public AdminProperty getServiceRecordNew(AdminProperty objProp)
        {
            try
            {
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);

            }
            catch (Exception ea)
            { ea.Message.ToString(); }
            return objProp;
        }

        public DataSet getDmtTarifRecord(AdminProperty objProp)
        {

            try
            {
                objProp.Query = @"SELECT pk_tarif_id AS 'id', tarif_name AS 'tfName',tarif_code AS 'tfAlias',tarif_indate AS 'date',tarif_status AS 'status'
        FROM aks_tarif_dmt where `tarif_status` !='1'";
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet getUpdatedmtTariffPlan(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_cnfid", objProp.FkSId);
                prm[1] = new MySqlParameter("_tariffid", objProp.TarifID);
                prm[2] = new MySqlParameter("_type", "D");
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_admin_update_dmttariff2", prm);


            }
            catch (Exception ea)
            { objProp.Error = ea.Message; }
            return objProp.DataSet;
        }

        public DataSet getUpdatedmtTariffPlanuva(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_cnfid", objProp.FkSId);
                prm[1] = new MySqlParameter("_tariffid", objProp.TarifID);
                prm[2] = new MySqlParameter("_type", "D");
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_admin_update_dmttariffuva", prm);


            }
            catch (Exception ea)
            { objProp.Error = ea.Message; }
            return objProp.DataSet;
        }

        public int updateUsertDmtStatus(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[2];
                prm[0] = new MySqlParameter("_usId", objProp.FkSId);
                prm[1] = new MySqlParameter("_dmt", objProp.UserTypeStrDmt);
                objProp.Result = DataLayer.ExecuteNonQuery(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_update_user_dmtstatus", prm);

                if (objProp.Result > 0)
                {
                    objProp.Result = 1;
                }
                else
                {
                    objProp.Result = 0;
                }

                return objProp.Result;

            }
            catch (Exception ea)
            { throw; }
        }

        public int updateUsertRchStatus(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[2];
                prm[0] = new MySqlParameter("_usId", objProp.FkSId);
                prm[1] = new MySqlParameter("_dmt", objProp.UserTypeStrDmt);
                objProp.Result = DataLayer.ExecuteNonQuery(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_update_user_rchstatus", prm);

                if (objProp.Result > 0)
                {
                    objProp.Result = 1;
                }
                else
                {
                    objProp.Result = 0;
                }

                return objProp.Result;

            }
            catch (Exception ea)
            { throw; }
        }

        public AdminProperty createTariffPlan(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[11];
                prm[0] = new MySqlParameter("_trfid", objProp.ApiID);
                prm[1] = new MySqlParameter("_pdrid", objProp.PdrID);
                prm[2] = new MySqlParameter("_srvid", objProp.SrvcID);
                prm[3] = new MySqlParameter("_ttid", objProp.TrnsID);
                prm[4] = new MySqlParameter("_tfcomson", objProp.APICommission);
                prm[5] = new MySqlParameter("_createby", objProp.PdrCreatedBy);
                prm[6] = new MySqlParameter("_ret_comm", objProp.RetailCommission);
                prm[7] = new MySqlParameter("_dist_comm", objProp.DistCommission);
                prm[8] = new MySqlParameter("_cnf_comm", objProp.CNFCommission);
                prm[9] = new MySqlParameter("_adm_comm", objProp.ADMINCommission);
                prm[10] = new MySqlParameter("_tfamount", objProp.Amount);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_insert_tariff_plan", prm);

                return objProp;

            }
            catch (Exception ea)
            { throw; }
        }

        public int createApiAllocation(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[7];
                prm[0] = new MySqlParameter("_tfId", objProp.TarifID);
                prm[1] = new MySqlParameter("_pdrId", objProp.PdrID);
                prm[2] = new MySqlParameter("_svcId", objProp.SrvcID);
                prm[3] = new MySqlParameter("_ttypeId", objProp.TrnsID);
                prm[4] = new MySqlParameter("_api1", objProp.RetailCommission);
                prm[5] = new MySqlParameter("_api2", objProp.ApiID);
                prm[6] = new MySqlParameter("_apiComison", objProp.APICommission);

                objProp.Result = DataLayer.ExecuteNonQuery(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_insert_api_allocation1", prm);

                if (objProp.Result > 0)
                {
                    objProp.Result = 1;
                }
                else
                {
                    objProp.Result = 0;
                }

                return objProp.Result;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet getprovider(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_servicetype", objProp.ServiceType);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "cr_tariff_list", prm);
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }
        public AdminProperty createDMTTarifPlanRecordList(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[4];
                prm[0] = new MySqlParameter("_trfname", objProp.TariffName);
                prm[1] = new MySqlParameter("_trfcode", objProp.TariffAlias);
                prm[2] = new MySqlParameter("_old_tfrId", objProp.OldTariffID);
                prm[3] = new MySqlParameter("_apiId", objProp.ApiID);
                objProp.DataReader = DataLayer.ExecuteReader(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_create_bulk_dmt_tariff", prm);



            }
            catch (Exception ea)
            { objProp.Remark = ea.ToString(); }
            return objProp;
        }

        public DataSet getDmtTarifPlanRecord(AdminProperty objProp)
        {

            try
            {
                objProp.Query = @"SELECT `pk_dmtcharges_id` AS 'id',(SELECT tarif_name FROM aks_tarif_dmt WHERE pk_tarif_id=fk_tariff_id) AS 'tfname',
(SELECT CONCAT(api_name,' [',api_company,']') FROM aks_master_api WHERE pk_api_id=fk_api_id) AS 'srname',dmt_from_amt AS 'dmtFrmAmt',dmt_to_amt AS 'dmtToAmt',dmt_other_charges AS 'dmtOthrChrg',
api1 AS 'api1',api2 AS 'api2',api3 AS 'api3',api4 AS 'api4', dmt_charges AS 'tcomm',dmt_api_deduct AS 'dmtapidts',dmt_status AS 'status',dmt_indate AS 'indate',
 tf_dist_comm AS 'dcomm',tf_cnf_comm AS 'ccomm',tf_admin_comm AS 'adcomm',(case dmt_type when 'F' then '[Flat]' ELSE '[ % ]' END) AS 'type' FROM dmt_charges  WHERE dmt_status='1'";
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet getAEPSTarifPlanRecord(AdminProperty objProp)
        {

            try
            {
                objProp.Query = @"SELECT `pk_dmtcharges_id` AS 'id',(SELECT tarif_name FROM aeps_tarif WHERE pk_tarif_id=fk_tariff_id) AS 'tfname',
(SELECT CONCAT(api_name,' [',api_company,']') FROM aks_master_api WHERE pk_api_id=fk_api_id) AS 'srname',dmt_from_amt AS 'dmtFrmAmt',dmt_to_amt AS 'dmtToAmt',
tf_comm AS 'tcomm',dmt_status AS 'status',dmt_indate AS 'indate',tf_dist_comm AS 'dcomm',tf_cnf_comm AS 'ccomm',tf_admin_comm AS 'adcomm',(case dmt_type when 'F' then '[Flat]' ELSE '[ % ]' END) AS 'type' 
FROM aeps_charges WHERE dmt_status='1'";
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet getUpdateTariffPlan(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_cnfid", objProp.FkSId);
                prm[1] = new MySqlParameter("_tariffid", objProp.TarifID);
                prm[2] = new MySqlParameter("_type", "D");
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_admin_update_tariff", prm);
            }
            catch (Exception ea)
            { objProp.Error = ea.Message; }
            return objProp.DataSet;
        }

        public DataSet getUpdatedistdmttariff(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_distid", objProp.FkSId);
                prm[1] = new MySqlParameter("_tariffid", objProp.TarifID);
                prm[2] = new MySqlParameter("_type", "D");
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_distributor_update_dmttariff", prm);
            }
            catch (Exception ea)
            { objProp.Error = ea.Message; }
            return objProp.DataSet;
        }

        public DataSet getUpdatedistdmttariff2(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_distid", objProp.FkSId);
                prm[1] = new MySqlParameter("_tariffid", objProp.TarifID);
                prm[2] = new MySqlParameter("_type", "D");
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_distributor_update_dmttariff2", prm);
            }
            catch (Exception ea)
            { objProp.Error = ea.Message; }
            return objProp.DataSet;
        }

        public DataSet getUpdatedistdmttariffuva(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_distid", objProp.FkSId);
                prm[1] = new MySqlParameter("_tariffid", objProp.TarifID);
                prm[2] = new MySqlParameter("_type", "D");
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_distributor_update_dmttariff_uva", prm);
            }
            catch (Exception ea)
            { objProp.Error = ea.Message; }
            return objProp.DataSet;
        }

        public DataSet getUpdatedisttariff(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_distid", objProp.FkSId);
                prm[1] = new MySqlParameter("_tariffid", objProp.TarifID);
                prm[2] = new MySqlParameter("_type", "R");
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_distributor_update_dmttariff", prm);
            }
            catch (Exception ea)
            { objProp.Error = ea.Message; }
            return objProp.DataSet;
        }

        public DataSet getUpdateretailerdmttariff(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_cnfid", objProp.FkSId);
                prm[1] = new MySqlParameter("_tariffid", objProp.TarifID);
                prm[2] = new MySqlParameter("_type", "D");
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_retailer_update_dmttariff", prm);
            }
            catch (Exception ea)
            { objProp.Error = ea.Message; }
            return objProp.DataSet;
        }

        public DataSet getUpdateretailerAEPStariff(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_cnfid", objProp.FkSId);
                prm[1] = new MySqlParameter("_tariffid", objProp.TarifID);
                prm[2] = new MySqlParameter("_type", "A");
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_retailer_update_aepstariff", prm);
            }
            catch (Exception ea)
            { objProp.Error = ea.Message; }
            return objProp.DataSet;
        }

        public DataSet getUpdateretailerdmttariff2(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_cnfid", objProp.FkSId);
                prm[1] = new MySqlParameter("_tariffid", objProp.TarifID);
                prm[2] = new MySqlParameter("_type", "D");
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_retailer_update_dmttariff2", prm);
            }
            catch (Exception ea)
            { objProp.Error = ea.Message; }
            return objProp.DataSet;
        }

        public DataSet getUpdateretailerdmttariffuva(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_cnfid", objProp.FkSId);
                prm[1] = new MySqlParameter("_tariffid", objProp.TarifID);
                prm[2] = new MySqlParameter("_type", "D");
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_update_uva_dmt_tariff", prm);
            }
            catch (Exception ea)
            { objProp.Error = ea.Message; }
            return objProp.DataSet;
        }

        public DataSet getUpdateretailerdmttariff3(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_cnfid", objProp.FkSId);
                prm[1] = new MySqlParameter("_tariffid", objProp.TarifID);
                prm[2] = new MySqlParameter("_type", "D");
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_retailer_update_dmttariff3", prm);
            }
            catch (Exception ea)
            { objProp.Error = ea.Message; }
            return objProp.DataSet;
        }


        public DataSet getUpdateretailerTariffPlan(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_cnfid", objProp.FkSId);
                prm[1] = new MySqlParameter("_tariffid", objProp.TarifID);
                prm[2] = new MySqlParameter("_type", "R");
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_retailer_update_dmttariff", prm);
            }
            catch (Exception ea)
            { objProp.Error = ea.Message; }
            return objProp.DataSet;
        }

        public DataSet getUpdaterchTariffPlan(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_cnfid", objProp.FkSId);
                prm[1] = new MySqlParameter("_tariffid", objProp.TarifID);
                prm[2] = new MySqlParameter("_type", "R");
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_admin_update_tariff", prm);


            }
            catch (Exception ea)
            { objProp.Error = ea.Message; }
            return objProp.DataSet;
        }


        public int updateTarifPlan(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[2];
                prm[0] = new MySqlParameter("_pid", objProp.ID);
                prm[1] = new MySqlParameter("_tfamount", objProp.Amount);
                objProp.Result = DataLayer.ExecuteNonQuery(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_update_tariff_plan", prm);
                return objProp.Result;

            }
            catch (Exception ea)
            { throw; }
        }
        public DataSet getUserRecordCnf(AdminProperty objProp)
        {

            try
            {
                //  MySqlParameter[] prm = new MySqlParameter[1];
                //  prm[0] = new MySqlParameter("_cnfid", objProp.FkSId);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);


            }
            catch (Exception ea)
            { objProp.Error = ea.Message; }
            return objProp.DataSet;
        }

        public DataSet createTarifPlanRecordList(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_trfname", objProp.ADMINCommission);
                prm[1] = new MySqlParameter("_trfcode", objProp.RetailCommission);
                prm[2] = new MySqlParameter("_old_tfrId", objProp.ApiID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_create_bulk_tariff", prm);

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet createTarifPlanRecordListbbps(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_trfname", objProp.ADMINCommission);
                prm[1] = new MySqlParameter("_trfcode", objProp.RetailCommission);
                prm[2] = new MySqlParameter("_old_tfrId", objProp.ApiID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_create_bulk_tariff_bbps", prm);

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public int updateUsertStatus(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_usId", objProp.FkSId);
                prm[1] = new MySqlParameter("_status", objProp.ID);
                prm[2] = new MySqlParameter("_dmt", objProp.UserTypeStrDmt);
                objProp.Result = DataLayer.ExecuteNonQuery(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_update_user_status", prm);

                if (objProp.Result > 0)
                {
                    objProp.Result = 1;
                }
                else
                {
                    objProp.Result = 0;
                }

                return objProp.Result;

            }
            catch (Exception ea)
            { throw; }
        }
        public DataSet getDMTTarifRecord(AdminProperty objProp)
        {

            try
            {

                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_view_dmt_tariff");

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet getDMTTarifRecorduva(AdminProperty objProp)
        {

            try
            {

                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_view_dmt_tariff_uva");

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet getDMTTarifRecord2(AdminProperty objProp)
        {

            try
            {

                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_view_dmt_tariff2");

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet getapicommissions(AdminProperty objProp)
        {
            try
            {
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet createupitariff(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_tafiffname", objProp.FullName);
                prm[1] = new MySqlParameter("_shortname", objProp.TfAlias);
                prm[2] = new MySqlParameter("_amount", objProp.amount);

                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "create_upi_tariff", prm);

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }
		
		public DataSet RefundPgTrans(AdminProperty objProp)
		{

			try
			{
				MySqlParameter[] prm = new MySqlParameter[1];
				prm[0] = new MySqlParameter("_tid", objProp.TransId);
				objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_pgdmt_refund", prm);
				return objProp.DataSet;
			}
			catch (Exception ea)
			{ throw; }
		}

public DataSet SaveTransTrackingData(AdminProperty objProp)
		{

			try
			{
				MySqlParameter[] prm = new MySqlParameter[12];
				prm[0] = new MySqlParameter("_transaid", objProp.TransId);
				prm[1] = new MySqlParameter("_uscode", objProp.RemitterId);
				prm[2] = new MySqlParameter("_amount", objProp.Amount);
				prm[3] = new MySqlParameter("_bank", objProp.bankname);
				prm[4] = new MySqlParameter("_api", objProp.ApiName);
				prm[5] = new MySqlParameter("_transdate", objProp.transdate);
				prm[6] = new MySqlParameter("_empid", objProp.adminLoginId);
				prm[7] = new MySqlParameter("_status", objProp.Status);
				prm[8] = new MySqlParameter("_empresponse", objProp.Response);
				prm[9] = new MySqlParameter("_tpin", objProp.Tpin);
				prm[10] = new MySqlParameter("_changedStatus", objProp.UserTypeStr);
				prm[11] = new MySqlParameter("_utrno", objProp.utrno);
				objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "aksom_dmt_history_update", prm);
				return objProp.DataSet;
			}
			catch (Exception ea)
			{ throw; }
		}
        public DataSet getFMRecord(AdminProperty objProp)
        {
            try
            {
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet updatetrfplan(AdminProperty objProp)
        {
            try
            {
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);


                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet getAepsTarifRecord(AdminProperty objProp)
        {

            try
            {
                objProp.Query = @"SELECT pk_tarif_id AS 'id', tarif_name AS 'tfName',tarif_code AS 'tfAlias',tarif_indate AS 'date',tarif_status AS 'status'
        FROM aeps_tarif where `tarif_status` ='1'";
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }
        public DataSet getTarifPlanRecordList(AdminProperty objProp)
        {

            try
            {

                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet updateutrnodmt(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[2];
                prm[0] = new MySqlParameter("_utrno", objProp.utrno);
                prm[1] = new MySqlParameter("_transid", objProp.transctnid);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_update_utrnodmt", prm);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet updateopiddmt(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[2];
                prm[0] = new MySqlParameter("_opid", objProp.OpCode);
                prm[1] = new MySqlParameter("_transid", objProp.transctnid);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_opid_updates", prm);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet refundInitiate(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[2];
                prm[0] = new MySqlParameter("_transId", objProp.transctnid);
                prm[1] = new MySqlParameter("_userID", objProp.UserID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_refund_initiate", prm);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }

        public AdminProperty userLedgers(AdminProperty objProp)
        {

            try
            {
                objProp.DataReader = DataLayer.ExecuteReader(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);
            }
            catch (Exception ea)
            { objProp.Error = ea.ToString(); }
            return objProp;
        }

        public MySqlDataReader bbpsservices(AdminProperty objProp)
        {
            try
            {
                objProp.DataReader = DataLayer.ExecuteReader(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_bbps_services_web");
                return objProp.DataReader;
            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet fillbbpsServices(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_type", objProp.PdrType);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_bbps_by_type", prm);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public MySqlDataReader getBBPSStructure(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[2];
                prm[0] = new MySqlParameter("_type", objProp.PdrType);
                prm[1] = new MySqlParameter("_pkid", objProp.ID);
                objProp.DataReader = DataLayer.ExecuteReader(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_bbps_structure", prm);
                return objProp.DataReader;

            }
            catch (Exception ea)
            { throw; }
        }


        public void LogWrite(string query, string infile)
        {
            System.IO.StreamWriter file = null;
            try
            {

                objProp.FileName = "C:\\SIDHMONEY\\" + System.DateTime.Now.ToString("dd-MMM-yyyy") + "_LOG_" + infile.ToUpper() + ".txt";
                file = new System.IO.StreamWriter(objProp.FileName, true);
                file.WriteLine(".................................." + System.DateTime.Now.ToString() + " IP ..........................>\r\n" + query);
                file.Close();
            }
            catch (Exception ex)
            { }
        }

        public DataSet getBankListBankit(AdminProperty objProp)
        {
            try
            {
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_get_bankit_bank");
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet bindreatilerDetails(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_loginid", objProp.PdrID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_get_retailer_details", prm);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

		       public AdminProperty getremitter(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_account", objProp.accountNumber);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_selectremitter_byaccc", prm);
                return objProp;
            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet checkupidata(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_referid", objProp.UserID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "upi_checkuser_status", prm);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet rechargehstrydes(AdminProperty objProp)
        {
            try
            {
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);

            }
            catch (Exception ea)
            { throw; }
            return objProp.DataSet;
        }

        public DataSet getbankname(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_account", objProp.accountNumber);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_getbank_name", prm);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }

        /*------------------Bulk DMT---------------------------------*/
        public DataSet createlistbulk(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[2];
                prm[0] = new MySqlParameter("_userid", objProp.UserID);
                prm[1] = new MySqlParameter("_listname", objProp.adminName);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "bulk_dmt_create_list", prm);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }
        public DataSet viewremitterlist(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_listid", objProp.UserID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "bulk_view_remitter", prm);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet getaepslist(AdminProperty objProp)
        {
            try
            {
                objProp.Query = @"SELECT * FROM `aks_bank_eko` WHERE `aeps_code`!='' AND aeps_status='Y' ORDER BY bank_name ASC";
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);
                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }

                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet createremitter(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[4];
                prm[0] = new MySqlParameter("_userid", objProp.UserID);
                prm[1] = new MySqlParameter("_listid", objProp.lipaddress);
                prm[2] = new MySqlParameter("_mobileno", objProp.MobileNumber);
                prm[3] = new MySqlParameter("_name", objProp.adminName);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "bulk_dmt_create_remitter", prm);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet getlistview(AdminProperty objProp)
        {
            try
            {
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }
        /*------------------Bulk DMT---------------------------------*/
        /*------------------API---------------------------------*/
        public DataSet getappuserlogin(AdminProperty objProp)
        {
            try
            {              
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet updatebankdmtimage(AdminProperty objProp)
        {
            try
            {
                objProp.Query = "UPDATE `aks_bank_eko` SET `bank_image`='" + objProp.uploadpic + "' where pk_bank_id='" + objProp.OfferPkID + "'";

                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);

            }
            catch (Exception ea)
            { throw; }
            return objProp.DataSet;
        }
        /*------------------API---------------------------------*/
        public DataSet updatedistdata(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[5];
                prm[0] = new MySqlParameter("_logid", objProp.PdrID);
                prm[1] = new MySqlParameter("_email", objProp.TfName);
                prm[2] = new MySqlParameter("_name", objProp.TfAlias);
                prm[3] = new MySqlParameter("_shop_name", objProp.shopnames);
                prm[4] = new MySqlParameter("_ofc_adress", objProp.OfficeAddress);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_update_retailer_new", prm);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet checkpassword(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[2];
                prm[0] = new MySqlParameter("_loginid", objProp.adminLoginId);
                prm[1] = new MySqlParameter("_password", objProp.Password);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_check_password", prm);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet updatdistPwd(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[2];
                prm[0] = new MySqlParameter("_rtpwd", objProp.Description);
                prm[1] = new MySqlParameter("_loginId", objProp.UserID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_distpass_update", prm);
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }


        public AdminProperty getrmtrName(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_phone", objProp.MobileNumber);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_get_remitter_name", prm);
                return objProp;

            }
            catch (Exception ea)
            { throw; }
        }


        public DataSet BarChartDataNew(AdminProperty objProp)
        {

            try
            {
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);

            }
            catch (Exception ea)
            { objProp.Error = ea.ToString(); }
            return objProp.DataSet;
        }

        public AdminProperty userLedgernew(AdminProperty objProp)
        {

            try
            {
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);
            }
            catch (Exception ea)
            { objProp.Error = ea.ToString(); }
            return objProp;
        }

        public DataSet userLedger(AdminProperty objProp)
        {

            try
            {
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);
            }
            catch (Exception ea)
            { objProp.Error = ea.ToString(); }
            return objProp.DataSet;
        }

        public DataSet getUserRecord(AdminProperty objProp)
        {

            try
            {
                //  MySqlParameter[] prm = new MySqlParameter[4];
                //prm[0] = new MySqlParameter("_amount", objProp.Amount);
                //prm[1] = new MySqlParameter("_userId", objProp.UserID);
                //prm[2] = new MySqlParameter("_type", objProp.UserTypeStr);
                //prm[3] = new MySqlParameter("_status", objProp.Status);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);


            }
            catch (Exception ea)
            { objProp.Error = ea.Message; }
            return objProp.DataSet;
        }

        public DataSet getBankName(AdminProperty objProp)
        {
            try
            {
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_get_bank_list");

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }
        public DataSet updateopidrch(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[2];
                prm[0] = new MySqlParameter("_opidno", objProp.OpCode);
                prm[1] = new MySqlParameter("_transid", objProp.transctnid);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_opidupdate_rch", prm);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }
        public AdminProperty shopnameddl(AdminProperty objProp)
        {
            try
            {
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);
                //return objProp;
            }
            catch (Exception ea)
            { objProp.Error = ea.ToString(); }
            return objProp;
        }

        public DataSet getPdrName(AdminProperty objProp)
        {
            try
            {
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_get_pname");

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public AdminProperty createRTDmt(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_fk_rt_id", objProp.UserID);
                prm[1] = new MySqlParameter("_kyc_pan", objProp.TfName);
                prm[2] = new MySqlParameter("_kyc_aadhaar", objProp.ApiName);
                objProp.Description = Convert.ToString(DataLayer.ExecuteScalar(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_insert_retailer_kyc", prm));

            }
            catch (Exception ea)
            { objProp.Description = ea.ToString(); }
            return objProp;
        }

        public DataSet createRTAEPS(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_fk_rt_id", objProp.UserID);
                prm[1] = new MySqlParameter("_kyc_pan", objProp.TfName);
                prm[2] = new MySqlParameter("_kyc_aadhaar", objProp.ApiName);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_aeps_activation", prm);
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }


        public DataSet getHistoryCount(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_userid", objProp.UserID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_ret_dashboard_data", prm);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }
		
		  public DataSet retailerUpdatePwd(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[2];
                prm[0] = new MySqlParameter("_rtpwd", objProp.adminPassword);
				prm[1] = new MySqlParameter("_loginId", objProp.adminLoginId);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_rt_update_password", prm);
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet getapiuserbalnce(AdminProperty objProp)
        {
            try
            {
                objProp.Query = @"SELECT ROUND((SELECT `wl_balance` FROM `aks_user_balance` WHERE `fk_refer_id`=us_code),2) AS wl_balance FROM `aks_user_login` WHERE `us_type`='5' AND `us_code`='" + objProp.UserID + "'";
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }
        public MySqlDataReader getrchstatusReader(AdminProperty objProp)
        {
            try
            {
                objProp.Query = @"SELECT `rch_status`,rch_status_desc,rch_operator_id FROM `aks_recharge_history` WHERE `rch_transaction_id`='" + objProp.UserID + "'";
                objProp.DataReader = DataLayer.ExecuteReader(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);
                return objProp.DataReader;
            }
            catch (Exception ea)
            { }
            return objProp.DataReader;
        }
        public DataSet getrchstatus(AdminProperty objProp)
        {
            try
            {
                objProp.Query = @"SELECT `rch_status`,rch_status_desc,rch_operator_id FROM `aks_recharge_history` WHERE `rch_transaction_id`='" + objProp.UserID + "'";
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);
                return objProp.DataSet;
            }
            catch (Exception ea)
            {  }
            return objProp.DataSet;
        }

        public DataSet getupiTarifRecord(AdminProperty objProp)
        {

            try
            {

                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_view_upi_tariff");

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet getUpdateretailerUPItariff(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_cnfid", objProp.FkSId);
                prm[1] = new MySqlParameter("_tariffid", objProp.TarifID);
                prm[2] = new MySqlParameter("_type", "D");
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_update_BBPStariff", prm);
            }
            catch (Exception ea)
            { objProp.Error = ea.Message; }
            return objProp.DataSet;
        }

        public DataSet updateupistatus(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[2];
                prm[0] = new MySqlParameter("_usId", objProp.pktkrid);
                prm[1] = new MySqlParameter("_aepssst", objProp.aepstatus);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_update_user_upiStatus", prm);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet updateaepsstatus(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[2];
                prm[0] = new MySqlParameter("_usId", objProp.pktkrid);
                prm[1] = new MySqlParameter("_aepssst", objProp.aepstatus);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_update_user_aepsstatus", prm);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet updateInvoice(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[2];
                prm[0] = new MySqlParameter("_usId", objProp.pktkrid);
                prm[1] = new MySqlParameter("_aepssst", objProp.aepstatus);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_update_invoice", prm);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet deleteuserid(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[2];
                prm[0] = new MySqlParameter("_userid", objProp.UserID);
                prm[1] = new MySqlParameter("_usertype", objProp.usertype);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_delete_user_new", prm);
            }
            catch (Exception ea)
            { throw; }
            return objProp.DataSet;
        }
        public DataSet usermapped(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_userid", objProp.UserID);
                prm[1] = new MySqlParameter("_parentid", objProp.username);
                prm[2] = new MySqlParameter("_usertype", objProp.usertype);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_mapping", prm);
            }
            catch (Exception ea)
            { throw; }
            return objProp.DataSet;
        }
        public AdminProperty UserInfoUpdate(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_userid", objProp.UserID);
                prm[1] = new MySqlParameter("_updatedata", objProp.Description);
                prm[2] = new MySqlParameter("_updatetype", objProp.usertype);
                // objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_update_userinfo_new", prm);
                objProp.DataReader = DataLayer.ExecuteReader(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_update_userinfo_new", prm);
            }
            catch (Exception ea)
            { throw; }
            return objProp;
        }

        public AdminProperty usesReport(AdminProperty objProp)
        {

            try
            {
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);
                
            }
            catch (Exception ea)
            { objProp.Error = ea.ToString(); }
            return objProp;
        }

        public AdminProperty forgotPwd(AdminProperty objProp)
        {
            try
            {
                objProp.DataReader = DataLayer.ExecuteReader(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);
                return objProp;
            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet retailerTpin(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[2];
                prm[0] = new MySqlParameter("_loginid", objProp.adminLoginId);
                prm[1] = new MySqlParameter("_tpin", objProp.adminPassword);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_check_tpin", prm);
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet findretailers(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_loginid", objProp.adminLoginId);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_find_retailer", prm);
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }
        public DataSet findadmin(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[2];
                prm[0] = new MySqlParameter("_loginid", objProp.adminLoginId);
                prm[1] = new MySqlParameter("_portalId", "1");
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_find_admin_mobile", prm);
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet electricityPdrList(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_type", objProp.PdrType);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_electricity_ddl", prm);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet landlinePdrList(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_type", objProp.PdrType);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_landline_data", prm);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet BroaadBandPdrList(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_type", objProp.PdrType);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_datacard_provider", prm);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet WaterPdrList(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_type", objProp.PdrType);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_water_provider", prm);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet retailerLogin(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_loginid", objProp.adminLoginId);
                prm[1] = new MySqlParameter("_password", objProp.adminPassword);
                prm[2] = new MySqlParameter("_ipaddress", objProp.IpAddress);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_retailer_login", prm);
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }


        public DataSet retaildistLogin_new(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[5];
                prm[0] = new MySqlParameter("_loginid", objProp.adminLoginId);
                prm[1] = new MySqlParameter("_password", objProp.adminPassword);
                prm[2] = new MySqlParameter("_ipaddress", objProp.IpAddress);
                prm[3] = new MySqlParameter("_ustype", objProp.ustype);
                prm[4] = new MySqlParameter("_cacheId", objProp.ORDERID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_retail_dist_login_2021", prm);
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }
        public DataSet webportallogin(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[5];
                prm[0] = new MySqlParameter("_loginid", objProp.adminLoginId);
                prm[1] = new MySqlParameter("_password", objProp.adminPassword);
                prm[2] = new MySqlParameter("_ipaddress", objProp.IpAddress);
                prm[3] = new MySqlParameter("_ustype", objProp.ustype);
                prm[4] = new MySqlParameter("_cacheId", objProp.ORDERID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_retail_dist_login_2021_new", prm);
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }
        public string verifyOtp(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[2];
                prm[0] = new MySqlParameter("_mobile", objProp.Mobile);
                prm[1] = new MySqlParameter("_otp", objProp.PanNumber);
                objProp.Query = Convert.ToString(DataLayer.ExecuteScalar(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "spt_verify_login_otp", prm));
                return objProp.Query;

            }
            catch (Exception ea)
            { throw; }
        }
        public string verifyOtpNew(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_mobile", objProp.Mobile);
                prm[1] = new MySqlParameter("_otp", objProp.PanNumber);
                prm[2] = new MySqlParameter("_cacheid", objProp.ORDERID);
                objProp.Query = Convert.ToString(DataLayer.ExecuteScalar(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "spt_verify_login_otp_sidh", prm));
                return objProp.Query;

            }
            catch (Exception ea)
            { throw; }
        }
        public string savebrowserDetails(AdminProperty objProp)
        {

            try
            {
                //`save_browser_details`(_userid VARCHAR(20),_latitude VARCHAR(25),_longitude VARCHAR(25),_guid VARCHAR(120),_browser VARCHAR(120),_ipaddress VARCHAR(50),_mobileno VARCHAR(15))
                MySqlParameter[] prm = new MySqlParameter[7];
                prm[0] = new MySqlParameter("_userid", objProp.adminLoginId);
                prm[1] = new MySqlParameter("_latitude", objProp.Latitude);
                prm[2] = new MySqlParameter("_longitude", objProp.Longitude);
                prm[3] = new MySqlParameter("_guid", objProp.BrowserId);
                prm[4] = new MySqlParameter("_browser", objProp.Remark);
                prm[5] = new MySqlParameter("_ipaddress", objProp.IpAddress);
                prm[6] = new MySqlParameter("_mobileno", objProp.Mobile);
                objProp.Query = Convert.ToString(DataLayer.ExecuteScalar(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "save_browser_details", prm));

                return objProp.Query;

            }
            catch (Exception ea)
            { throw; }
        }
        public string savebrowserDetailsNew(AdminProperty objProp)
        {

            try
            {
                //`save_browser_details`(_userid VARCHAR(20),_latitude VARCHAR(25),_longitude VARCHAR(25),_guid VARCHAR(120),_browser VARCHAR(120),_ipaddress VARCHAR(50),_mobileno VARCHAR(15))
                MySqlParameter[] prm = new MySqlParameter[7];
                prm[0] = new MySqlParameter("_userid", objProp.adminLoginId);
                prm[1] = new MySqlParameter("_latitude", objProp.Latitude);
                prm[2] = new MySqlParameter("_longitude", objProp.Longitude);
                prm[3] = new MySqlParameter("_guid", objProp.BrowserId);
                prm[4] = new MySqlParameter("_browser", objProp.Remark);
                prm[5] = new MySqlParameter("_ipaddress", objProp.IpAddress);
                prm[6] = new MySqlParameter("_mobileno", objProp.Mobile);
                objProp.Query = Convert.ToString(DataLayer.ExecuteScalar(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "save_browser_details_new", prm));

                return objProp.Query;

            }
            catch (Exception ea)
            { throw; }
        }
        public DataSet retaildistLogin(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[4];
                prm[0] = new MySqlParameter("_loginid", objProp.adminLoginId);
                prm[1] = new MySqlParameter("_password", objProp.adminPassword);
                prm[2] = new MySqlParameter("_ipaddress", objProp.IpAddress);
                prm[3] = new MySqlParameter("_ustype", objProp.ustype);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_retail_dist_login", prm);
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }



        public int createTariff(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[2];
                prm[0] = new MySqlParameter("_tf_name", objProp.TfName);
                prm[1] = new MySqlParameter("_tf_code", objProp.TfAlias);
                objProp.Result = DataLayer.ExecuteNonQuery(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_insert_tariff", prm);

                if (objProp.Result > 0)
                {
                    objProp.Result = 1;
                }
                else
                {
                    objProp.Result = 0;
                }

                return objProp.Result;

            }
            catch (Exception ea)
            { throw; }
        }
        public int updateTarif(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_pk_id", objProp.TarifID);
                prm[1] = new MySqlParameter("_tf_name", objProp.TfName);
                prm[2] = new MySqlParameter("_tf_code", objProp.TfAlias);
                objProp.Result = DataLayer.ExecuteNonQuery(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_update_tariff", prm);

                if (objProp.Result > 0)
                {
                    objProp.Result = 1;
                }
                else
                {
                    objProp.Result = 0;
                }

                return objProp.Result;

            }
            catch (Exception ea)
            { throw; }
        }
        public DataSet getTarifRecord(AdminProperty objProp)
        {

            try
            {

                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_view_tariff");

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet getTarifRecordbbps(AdminProperty objProp)
        {

            try
            {

                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_view_bbps_tariff");

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public AdminProperty updatPwd(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_loginId", objProp.Mobile);
                prm[1] = new MySqlParameter("_pwdnew", objProp.Tpin);
                prm[2] = new MySqlParameter("_ipadd", objProp.ipaddress);
                objProp.DataReader = DataLayer.ExecuteReader(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_retail_dist_passupdate", prm);
                return objProp;

            }
            catch (Exception ea)
            { throw; }
        }

        public AdminProperty updatetip(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_loginId", objProp.Mobile);
                prm[1] = new MySqlParameter("_pwdnew", objProp.Tpin);
                prm[2] = new MySqlParameter("_ipadd", objProp.ipaddress);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_users_tpin_update", prm);
                return objProp;

            }
            catch (Exception ea)
            { throw; }
        }

        public AdminProperty forgotpassword(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_loginId", objProp.adminLoginId);
                prm[1] = new MySqlParameter("_pwdnew", objProp.Description);
                prm[2] = new MySqlParameter("_ipadd", objProp.ipaddress);
                objProp.Response = Convert.ToString(DataLayer.ExecuteScalar(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_retail_dist_passupdate", prm));
            }
            catch (Exception ea)
            { objProp.Response = "N"; }
            return objProp;
        }
        public DataSet getAPIRecord(AdminProperty objProp)
        {

            try
            {

                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_view_api");

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }
        public int createAPI(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[5];
                prm[0] = new MySqlParameter("_api_name", objProp.ApiName);
                prm[1] = new MySqlParameter("_api_comp", objProp.ApiCompny);
                prm[2] = new MySqlParameter("_api_pwd", objProp.ApiPwd);
                prm[3] = new MySqlParameter("_api_key", objProp.ApiKey);
                prm[4] = new MySqlParameter("_api_url", objProp.ApiUrl);
                objProp.Result = DataLayer.ExecuteNonQuery(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_insert_api", prm);

                if (objProp.Result > 0)
                {
                    objProp.Result = 1;
                }
                else
                {
                    objProp.Result = 0;
                }

                return objProp.Result;

            }
            catch (Exception ea)
            { throw; }
        }
        public int updateAPI(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[6];
                prm[0] = new MySqlParameter("_pk_id", objProp.ApiID);
                prm[1] = new MySqlParameter("_api_name", objProp.ApiName);
                prm[2] = new MySqlParameter("_api_comp", objProp.ApiCompny);
                prm[3] = new MySqlParameter("_api_pwd", objProp.ApiPwd);
                prm[4] = new MySqlParameter("_api_key", objProp.ApiKey);
                prm[5] = new MySqlParameter("_api_url", objProp.ApiUrl);
                objProp.Result = DataLayer.ExecuteNonQuery(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_update_api", prm);

                if (objProp.Result > 0)
                {
                    objProp.Result = 1;
                }
                else
                {
                    objProp.Result = 0;
                }

                return objProp.Result;

            }
            catch (Exception ea)
            { throw; }
        }

        public int createService(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_service_name", objProp.SrvcName);
                prm[1] = new MySqlParameter("_pdr_alias", objProp.SrvcAlias);
                prm[2] = new MySqlParameter("_modifyby", objProp.ModifyBy);
                objProp.Result = DataLayer.ExecuteNonQuery(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_insert_service_type", prm);

                if (objProp.Result > 0)
                {
                    objProp.Result = 1;
                }
                else
                {
                    objProp.Result = 0;
                }

                return objProp.Result;

            }
            catch (Exception ea)
            { throw; }
        }
        public DataSet getServiceRecord(AdminProperty objProp)
        {

            try
            {

                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_view_service_type");

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }
        public int updateService(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[4];
                prm[0] = new MySqlParameter("_serviceid", objProp.SrvcID);
                prm[1] = new MySqlParameter("_service_name", objProp.SrvcName);
                prm[2] = new MySqlParameter("_st_alias", objProp.SrvcAlias);
                prm[3] = new MySqlParameter("_modifyby", objProp.ModifyBy);
                objProp.Result = DataLayer.ExecuteNonQuery(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_update_service_type", prm);

                if (objProp.Result > 0)
                {
                    objProp.Result = 1;
                }
                else
                {
                    objProp.Result = 0;
                }

                return objProp.Result;

            }
            catch (Exception ea)
            { throw; }
        }

        public int createProvider(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[5];
                prm[0] = new MySqlParameter("_pdr_name", objProp.PdrName);
                prm[1] = new MySqlParameter("_pdr_alias", objProp.PdrAlias);
                prm[2] = new MySqlParameter("_fk_serviceId", objProp.FkSId);
                prm[3] = new MySqlParameter("_createby", objProp.PdrCreatedBy);
                prm[4] = new MySqlParameter("_pdr_type", objProp.PdrType);
                objProp.Result = DataLayer.ExecuteNonQuery(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_insert_provider_type", prm);

                if (objProp.Result > 0)
                {
                    objProp.Result = 1;
                }
                else
                {
                    objProp.Result = 0;
                }

                return objProp.Result;

            }
            catch (Exception ea)
            { throw; }
        }

        public int getloginattempts(AdminProperty objProp)
        {
            try
            {
                objProp.Query = @"SELECT `login_attempts` FROM `aks_user_login` WHERE `us_loginid`= '" + objProp.UserID + "' OR `us_code`= '" + objProp.UserID + "'";
                objProp.Result = Convert.ToInt16(DataLayer.ExecuteScalar(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query));
                return objProp.Result;
            }
            catch(Exception ea)
            { throw; }
        }
        public DataSet getloginattemptss(AdminProperty objProp)
        {
            try
            {
                objProp.Query = @"SELECT `login_attempts` FROM `aks_user_login` WHERE `us_loginid`= '" + objProp.UserID + "' OR `us_code`= '" + objProp.UserID + "'";
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }
        public DataSet getusersbalnce(AdminProperty objProp)
        {
            try
            {
                objProp.Query = @"SELECT `wl_balance` FROM `aks_user_balance` WHERE `fk_user_id`='"+objProp.UserID+"'";
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet getProviderRecord(AdminProperty objProp)
        {

            try
            {
               //objProp.UserID = "1";
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_userId", objProp.UserID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "spt_get_commision_chart", prm);
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }
        public int updateProvider(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[6];
                prm[0] = new MySqlParameter("_pdr_name", objProp.PdrName);
                prm[1] = new MySqlParameter("_pdr_alias", objProp.PdrAlias);
                prm[2] = new MySqlParameter("_serviceId", objProp.FkSId);
                prm[3] = new MySqlParameter("_modifyby", objProp.PdrCreatedBy);
                prm[4] = new MySqlParameter("_pdr_type", objProp.PdrType);
                prm[5] = new MySqlParameter("_pdrid", objProp.PdrType);
                objProp.Result = DataLayer.ExecuteNonQuery(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_update_provider_type", prm);

                if (objProp.Result > 0)
                {
                    objProp.Result = 1;
                }
                else
                {
                    objProp.Result = 0;
                }

                return objProp.Result;

            }
            catch (Exception ea)
            { throw; }
        }

        public int createTransaction(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_trans_name", objProp.TrnsName);
                prm[1] = new MySqlParameter("_trans_alias", objProp.TrnsAlias);
                prm[2] = new MySqlParameter("_createby", objProp.TrnsCreatedBy);
                objProp.Result = DataLayer.ExecuteNonQuery(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_insert_transaction_type", prm);

                if (objProp.Result > 0)
                {
                    objProp.Result = 1;
                }
                else
                {
                    objProp.Result = 0;
                }

                return objProp.Result;

            }
            catch (Exception ea)
            { throw; }
        }
        
        public int updateUPI(string userid,string shopname,string name,string upiaddress, string pancard)
        {

            try
            {
                // `us_name`,`us_loginid`,`us_code`,us_shop_name,us_pan,(SELECT `office_address` FROM `aks_retailer_gstin_details` 
                objProp.Query = "update aks_user_login set us_upi_address='"+ upiaddress.Trim() + "', us_pan='" + pancard + "',us_shop_name='" + shopname.Trim() + "',us_name='"+ name + "' where us_code='"+ userid + "'";
                objProp.Result = DataLayer.ExecuteNonQuery(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query );
                return objProp.Result;

            }
            catch (Exception ea)
            { throw; }
        }

        public int updateMPIN(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[2];
                prm[0] = new MySqlParameter("_logid", objProp.PdrID);
                prm[1] = new MySqlParameter("_pin", objProp.ApiPwd);
                objProp.Result = DataLayer.ExecuteNonQuery(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_update_mpin", prm);

                if (objProp.Result > 0)
                {
                    objProp.Result = 1;
                }
                else
                {
                    objProp.Result = 0;
                }

                return objProp.Result;

            }
            catch (Exception ea)
            { throw; }
        }
		
        public int updateRTDetails(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[7];
                prm[0] = new MySqlParameter("_logid", objProp.PdrID);
                prm[1] = new MySqlParameter("_email", objProp.TfName);
                prm[2] = new MySqlParameter("_name", objProp.TfAlias);
                prm[3] = new MySqlParameter("_shop_name", objProp.TarifID);
                prm[4] = new MySqlParameter("_pk_user_id", objProp.ApiID);
                prm[5] = new MySqlParameter("_postcode", objProp.ApiPwd);
                prm[6] = new MySqlParameter("_ofc_adress", objProp.ApiCompny);
                objProp.Result = DataLayer.ExecuteNonQuery(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_update_retailer", prm);

                if (objProp.Result > 0)
                {
                    objProp.Result = 1;
                }
                else
                {
                    objProp.Result = 0;
                }

                return objProp.Result;

            }
            catch (Exception ea)
            { throw; }
        }
		
		//------------------------- Rohit ------------------------------------------
		public DataSet getslider(AdminProperty objProp)
        {
            try
            {
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);             

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }
		
		//------------------------- Rohit ------------------------------------------
		
        public DataSet bindRTDetails(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_loginid", objProp.PdrID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_get_retailer_details", prm);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public string GetMethod(string uri)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(uri);
            request.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;
            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            using (Stream stream = response.GetResponseStream())
            using (StreamReader reader = new StreamReader(stream))
            {
                return reader.ReadToEnd();
            }

        }
        public AdminProperty getdbDatas_due(AdminProperty objProp)
        {
            try
            {
                objProp.Query = @"sp_find_customer_credit";
                objProp.Loadid = Convert.ToString(DataLayer.ExecuteScalar(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, objProp.Query));
                return objProp;
            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet getFM(AdminProperty objProp)
        {

            try
            {
               
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet getMasterBalance(AdminProperty objProp)
        {

            try
            {
                objProp.Query = "sp_ret_get_balance";
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_userid", objProp.UserID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, objProp.Query, prm);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }
        public DataSet getTransactionRecord(AdminProperty objProp)
        {

            try
            {
                objProp.Query = "sp_ret_get_transaction";
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_userid", objProp.UserID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, objProp.Query, prm);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }
        public DataSet getDTHTransaction(AdminProperty objProp)
        {

            try
            {
                objProp.Query = "sp_ret_get_dth_transaction";
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_userid", objProp.UserID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, objProp.Query, prm);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }
        public DataSet getelectricTransaction(AdminProperty objProp)
        {

            try
            {
                objProp.Query = "sp_ret_get_elec_trans";
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_userid", objProp.UserID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, objProp.Query, prm);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }
        public DataSet getgasTransaction(AdminProperty objProp)
        {

            try
            {
                objProp.Query = "sp_ret_get_gas_trans";
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_userid", objProp.UserID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, objProp.Query, prm);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet getWaterTransaction(AdminProperty objProp)
        {

            try
            {
                objProp.Query = "sp_ret_get_water_trans";
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_userid", objProp.UserID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, objProp.Query, prm);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }
        public DataSet transactionHistory(AdminProperty objProp)
        {

            try
            {
                  objProp.Query = "sp_ret_transaction_history";
                  MySqlParameter[] prm = new MySqlParameter[1];
                  prm[0] = new MySqlParameter("_userid", objProp.UserID); 
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, objProp.Query,prm);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet getStateCity(AdminProperty objLogin)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_pincode", objLogin.pincode);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_get_state_by_pincode", prm);
            }
            catch (Exception ea)
            { throw; }
            return objProp.DataSet;
        }

        public DataSet transactionHistory1(AdminProperty objProp)
        {

            try
            {
              /*  objProp.Query = "sp_ret_transaction_history";
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_userid", objProp.UserID); */
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }
        public DataSet createComplaint(AdminProperty objProp)
        {

            try
            {
              
                MySqlParameter[] prm = new MySqlParameter[4];
                prm[0] = new MySqlParameter("_tid", objProp.transctnid);
                prm[1] = new MySqlParameter("_type", objProp.TYPE);
                prm[2] = new MySqlParameter("_message", objProp.Description);
                prm[3] = new MySqlParameter("_userid", objProp.UserID);
                //prm[4] = new MySqlParameter("_amount", objProp.Amount);
                //prm[5] = new MySqlParameter("_tckid", objProp.TarifID);
                //prm[6] = new MySqlParameter("_mobile", objProp.MobileNumber);
                //prm[7] = new MySqlParameter("_transid", objProp.TrnsID);
                //prm[8] = new MySqlParameter("_opid", objProp.otp);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "city_ticket_create", prm);

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public int updateTransaction(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[4];
                prm[0] = new MySqlParameter("_transid", objProp.TrnsID);
                prm[1] = new MySqlParameter("_trans_name", objProp.TrnsName);
                prm[2] = new MySqlParameter("_trans_alias", objProp.TrnsAlias);
                prm[3] = new MySqlParameter("_createby", objProp.TrnsCreatedBy);
                objProp.Result = DataLayer.ExecuteNonQuery(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_update_transaction_type", prm);

                if (objProp.Result > 0)
                {
                    objProp.Result = 1;
                }
                else
                {
                    objProp.Result = 0;
                }
                return objProp.Result;

            }
            catch (Exception ea)
            { throw; }
        }
        public DataSet bindPdrList(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_type", objProp.PdrType);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_ret_get_provider", prm);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet bindDthPdrList(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_type", objProp.PdrType);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_dth_provider", prm);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet bindPPPdrList(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_type", objProp.PdrType);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_postpaid_provider", prm);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public AdminProperty getPaymentByDate(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[2];
                prm[0] = new MySqlParameter("_userid", objProp.UserID);
				prm[1] = new MySqlParameter("_indate", objProp.LoginDate);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_ret_payment_by_date", prm);
                objProp.Response = "Y";
               

            }
            catch (Exception ea)
            { objProp.Response = ea.ToString(); }
            return objProp;
        }
        
        public AdminProperty getfundreports(AdminProperty objProp)
        {
            try
            {
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);
                return objProp;
            }
            catch (Exception ea)
            { throw; }
        }

        public int AddPayment(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[6];
                prm[0] = new MySqlParameter("_userid", objProp.UserID);
                prm[1] = new MySqlParameter("_amount", objProp.Amount);
                prm[2] = new MySqlParameter("_remark", objProp.Remark);
                prm[3] = new MySqlParameter("_addBy", objProp.ADDBY);
                prm[4] = new MySqlParameter("_type", objProp.TYPE);
                prm[5] = new MySqlParameter("_transactionid", objProp.TxnID);
                objProp.Result = DataLayer.ExecuteNonQuery(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_admin_payment_add", prm);

                if (objProp.Result > 0)
                {
                    objProp.Result = 1;
                }
                else
                {
                    objProp.Result = 0;
                }

                return objProp.Result;

            }
            catch (Exception ea)
            { throw; }
        }
        public string doRecharge(AdminProperty.Recharge objRec)
        {
            string responseString = string.Empty;
            try
            {
                string url = "method=recharge&loginid=" + objRec.Loginid + "&mobile=" + objRec.Mobile + "&provider=" + objRec.Provider + "&ttype=" + objRec.transType + "&Service=" + objRec.service + "&amount=" + objRec.Amount;
                string newurl = "http://api.payesmoney.in/recApiFinal/service.aspx";
                HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create(newurl);
                ASCIIEncoding encoding = new ASCIIEncoding();
                byte[] PostData = encoding.GetBytes(url.ToString());
                httpWReq.Method = "POST";
                httpWReq.ContentType = "application/x-www-form-urlencoded";
                httpWReq.ContentLength = PostData.Length;
                using (Stream stream = httpWReq.GetRequestStream())
                {
                    stream.Write(PostData, 0, PostData.Length);
                }
                HttpWebResponse response = (HttpWebResponse)httpWReq.GetResponse();
                responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();

            }
            catch (Exception ex)
            {
                responseString = "N";
            }
            return responseString;
        }
        public AdminProperty generatePassword(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[4];
                prm[0] = new MySqlParameter("_userid", objProp.UserID);
                prm[1] = new MySqlParameter("_old_pass", objProp.adminPassword);
                prm[2] = new MySqlParameter("_password", objProp.Password);
                prm[3] = new MySqlParameter("_pin", objProp.Tpin);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "create_password_pin", prm);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                    objProp.TrnsID = objProp.DataSet.Tables[0].Rows[0]["id"].ToString();
                    objProp.Description = objProp.DataSet.Tables[0].Rows[0]["desc"].ToString();
                }
                else
                {
                    objProp.TrnsID = "N";
                    objProp.Description = "No Result Found";
                }

               

            }
            catch (Exception ea)
            { objProp.TrnsID = "N"; }
            return objProp;
        }

        //DMT Logic


        public string postMethodForForgotPassword(AdminProperty prop)
        {
            string responseString = string.Empty;
            try
            {

                string url = WebConfigurationManager.AppSettings["PAYESAPI_URLPOST"].ToString();
                HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create(url);
                ASCIIEncoding encoding = new ASCIIEncoding();
                byte[] PostData = encoding.GetBytes(prop.ApiUrl.ToString());
                httpWReq.Method = "POST";
                httpWReq.Headers.Add("aksom", "d03b2278463ff425948a39b827417f20s");
                httpWReq.ContentType = "application/x-www-form-urlencoded";
                httpWReq.ContentLength = PostData.Length;
                using (Stream stream = httpWReq.GetRequestStream())
                {
                    stream.Write(PostData, 0, PostData.Length);
                }
                HttpWebResponse response = (HttpWebResponse)httpWReq.GetResponse();
                responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();

            }
            catch (Exception ex)
            {
                responseString = "N";
            }
            return responseString;
        }



        public string postMethod(AdminProperty prop)
        {
            string responseString = string.Empty;
            try
            {

                string newurl = objProp.EKOURL;
                HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create(newurl);
                ASCIIEncoding encoding = new ASCIIEncoding();
                byte[] PostData = encoding.GetBytes(prop.ApiUrl.ToString());
                httpWReq.Method = "POST";
                httpWReq.ContentType = "application/x-www-form-urlencoded";
                httpWReq.ContentLength = PostData.Length;
                using (Stream stream = httpWReq.GetRequestStream())
                {
                    stream.Write(PostData, 0, PostData.Length);
                }
                HttpWebResponse response = (HttpWebResponse)httpWReq.GetResponse();
                responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();

            }
            catch (Exception ex)
            {
                responseString = "N";
            }
            return responseString;
        }


        public string postmethodoperator(AdminProperty prop)
        {
            string responseString = string.Empty;
            try
            {

                string newurl = objProp.findprovider;
                HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create(newurl);
                ASCIIEncoding encoding = new ASCIIEncoding();
                byte[] PostData = encoding.GetBytes(prop.ApiUrl.ToString());
                httpWReq.Method = "POST";
                httpWReq.ContentType = "application/x-www-form-urlencoded";
                httpWReq.ContentLength = PostData.Length;
                using (Stream stream = httpWReq.GetRequestStream())
                {
                    stream.Write(PostData, 0, PostData.Length);
                }
                HttpWebResponse response = (HttpWebResponse)httpWReq.GetResponse();
                responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();

            }
            catch (Exception ex)
            {
                responseString = "N";
            }
            return responseString;
        }


        public DataSet getRMTRKYC(AdminProperty objProp)
        {
            try
            {
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }


        public DataSet retailerGSTINUpdate(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[15];
                prm[0] = new MySqlParameter("_rtMob", objProp.MobileNumber);
                prm[1] = new MySqlParameter("_gstin", objProp.GSTN);
                prm[2] = new MySqlParameter("_officeName", objProp.OfficialName);
                prm[3] = new MySqlParameter("_officeAdd", objProp.OfficeAddress);
                prm[4] = new MySqlParameter("_state", objProp.State);
                prm[5] = new MySqlParameter("_city", objProp.City);
                prm[6] = new MySqlParameter("_authoSign", objProp.AuthorisedName);
                prm[7] = new MySqlParameter("_pancard_front", objProp.PancardFront);
                prm[8] = new MySqlParameter("_adhaar_front", objProp.AdhaarNoFront);
                prm[9] = new MySqlParameter("_adhaar_back", objProp.AdhaarNoBack);
                prm[10] = new MySqlParameter("_us_type", objProp.TYPE);
                prm[11] = new MySqlParameter("_profile_photo", objProp.ProfilePhoto);
                prm[12] = new MySqlParameter("_pan_no", objProp.PanNumber);
                prm[13] = new MySqlParameter("_adhaar_no", objProp.AdhaarNumber);
                prm[14] = new MySqlParameter("_fk_gstinId", objProp.FkSId);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_rt_gstin_details_update", prm);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }



        public DataSet retailerGSTIN(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[16];
                prm[0] = new MySqlParameter("_rtMob", objProp.MobileNumber);
                prm[1] = new MySqlParameter("_gstin", objProp.GSTN);
                prm[2] = new MySqlParameter("_officeName", objProp.OfficialName);
                prm[3] = new MySqlParameter("_officeAdd", objProp.OfficeAddress);
                prm[4] = new MySqlParameter("_state", objProp.State);
                prm[5] = new MySqlParameter("_city", objProp.City);
                prm[6] = new MySqlParameter("_authoSign", objProp.AuthorisedName);
                prm[7] = new MySqlParameter("_pancard_front", objProp.PancardFront);
                prm[8] = new MySqlParameter("_adhaar_front", objProp.AdhaarNoFront);
                prm[9] = new MySqlParameter("_adhaar_back", objProp.AdhaarNoBack);
                prm[10] = new MySqlParameter("_us_type", objProp.TYPE);
                prm[11] = new MySqlParameter("_profile_photo", objProp.ProfilePhoto);
                prm[12] = new MySqlParameter("_pan_no", objProp.PanNumber);
                prm[13] = new MySqlParameter("_adhaar_no", objProp.AdhaarNumber);
                prm[14] = new MySqlParameter("_fk_userid", objProp.FkSId);
                prm[15] = new MySqlParameter("_state_code", objProp.statecode);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_rt_gstin_details", prm);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet remitterKYC(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[5];
                prm[0] = new MySqlParameter("_rmtrno", objProp.MobileNumber);
                prm[1] = new MySqlParameter("_docType", objProp.DocType);
                prm[2] = new MySqlParameter("_doc_front", objProp.DocFront);
                prm[3] = new MySqlParameter("_doc_back", objProp.DocBack);
                prm[4] = new MySqlParameter("_rmtr_photo", objProp.SelfPhoto);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_remitter_kyc_doc",prm);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet getStateList(AdminProperty objProp)
        {
            try
            {
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text,objProp.Query);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }
        public DataSet getBankListAddBene(AdminProperty objProp)
        {
            try
            {
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_get_paytm_bank_new");
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }
        public DataSet getBankList(AdminProperty objProp)
        {
            try
            {
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_get_paytm_bank");

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }
        public DataSet getProviderRecordApp(AdminProperty objProp)
        {

            try
            {
                // objProp.UserID = "1";
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_userId", objProp.UserID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "spt_get_com_chart", prm);
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }
        public DataSet bindBankIFSC(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_pk_bid", objProp.ApiID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_get_bank_ifsc", prm);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }
        public DataSet bindMoneyHistory(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_cust_id", objProp.UserID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_get_money_trans_history", prm);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }
        public string validateTPIN(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_userid", objProp.ifscCode);
                prm[1] = new MySqlParameter("_tpin", objProp.MobileNumber);
                prm[2] = new MySqlParameter("_amount", objProp.accountNumber);
                objProp.Query = Convert.ToString(DataLayer.ExecuteScalar(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_insert_tariff", prm));

                return objProp.Query;

            }
            catch (Exception ea)
            { throw; }
        }
        public string deleteBene(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_userid", objProp.ifscCode);
                prm[1] = new MySqlParameter("_tpin", objProp.MobileNumber);
                prm[2] = new MySqlParameter("_amount", objProp.accountNumber);
                objProp.Query = Convert.ToString(DataLayer.ExecuteScalar(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_insert_tariff", prm));

                return objProp.Query;

            }
            catch (Exception ea)
            { throw; }
        }
        public AdminProperty serviceCharge(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_amount", objProp.Amount);
                prm[1] = new MySqlParameter("_tpin", objProp.Tpin);
                prm[2] = new MySqlParameter("_userid", objProp.UserID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "dmt_service_charge_rbi", prm);
            }
            catch (Exception ea)
            { objProp.Remark = "N"; objProp.PdrType = ea.ToString(); }
            return objProp;
        }
        public AdminProperty updateData(AdminProperty objProp)
        {
            try
            {
                LogWrite(objProp.UserID + "Bank Name " + objProp.BankName + "_AEPS", "_AEPS");
                //('PRT10011','RNFIAEPS','1','AEPS','TPP','8285000637','184.107.37.228','xxxx9856','Bank Of India','Successfull Operation','8787878787','OK')
                MySqlParameter[] prm = new MySqlParameter[12];
                prm[0] = new MySqlParameter("_userid", objProp.UserID);
                prm[1] = new MySqlParameter("_provider", "RNFIAEPS");
                prm[2] = new MySqlParameter("_amount", objProp.AEPSAmount);
                prm[3] = new MySqlParameter("_service", "AEPS");
                prm[4] = new MySqlParameter("_ttype", "TPP");
                prm[5] = new MySqlParameter("_mobileno", objProp.Mobile);
                prm[6] = new MySqlParameter("_ipaddress", "184.107.37.228");
                prm[7] = new MySqlParameter("_adhaarcard", objProp.Adhaarcard);
                prm[8] = new MySqlParameter("_bank_name", objProp.BankName);
                prm[9] = new MySqlParameter("_finalMessage", objProp.Description);
                prm[10] = new MySqlParameter("_operatorId", objProp.ORDERID);
                prm[11] = new MySqlParameter("_api_message", objProp.FinalResponse);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_api_recharge_aeps", prm);
                if(objProp.DataSet.Tables[0].Rows.Count > 0)
                {

                    LogWrite(objProp.DataSet.Tables[0].Rows[0][1].ToString(), "_AEPS");
                }
            }
            catch (Exception ea)
            {
                objProp.Remark = "N"; objProp.PdrType = ea.ToString();
                LogWrite(objProp.paytype, "_AEPS");
            }
            return objProp;
        }
        // code by sandeep harjuniya
        public AdminProperty updatetales(AdminProperty objProp)
        {
            try
            {
                objProp.Result = DataLayer.ExecuteNonQuery(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);
            }
            catch (Exception ex)
            {
            }
            return objProp;
        }

    }

    public static class JsonResponse
    {

        public static Success success(string message, string exception, object data = null)
        {
            Success objSuccess = new Success();
            objSuccess.message = message;
            objSuccess.data = data;
            objSuccess.code = 0;
            objSuccess.exception = exception;
            return objSuccess;
        }
        public static Fail fail(string message, string exception, object data = null)
        {
            Fail objFail = new Fail();
            objFail.message = message;
            objFail.data = data;
            objFail.code = 0;
            objFail.exception = exception;
            return objFail;
        }
    }

    public class Success
    {
        public bool status { get { return true; } }
        public int code { get; set; }
        public string message { get; set; }
        public object data { get; set; }
        public string exception { get; set; }
    }

    public class Fail
    {
        public bool status { get { return false; } }
        public int code { get; set; }
        public string message { get; set; }
        public object data { get; set; }
        public string exception { get; set; }
    }
}
    
