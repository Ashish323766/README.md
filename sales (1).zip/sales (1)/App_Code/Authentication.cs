﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Authentication
/// </summary>
public class Authentication
{
    public Authentication()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public static void GetUserDetailsByJsonObjectKey(string jObjectKey, out string value)
    {
        value = "";

        try
        {
            /*
             * {
                    "Id": "4",
                    "Pkid": "4",
                    "ReferId": "R1001",
                    "Mobile": "8285000637",
                    "Email": "ankit@aksomenterprises.com",
                    "ShopName": "City Retailer",
                    "IsUserActive": "0",
                    "walletBalance": 13959.57,
                    "UserType": "(Retailer) \r\n R1001",
                    "DistributorID": "3",
                    "DistributorName": "Distributor",
                    "Company": "Ankit Sharma",
                    "IsPassChange": "1",
                    "Result": null,
                    "Ticker": "Happy Independence Week, Get Load of Rs 100000/- and get upto Rs 5000/- rewards. TNC Apply...",
                    "Image1": "http://admin.cityrecharge.in/img/app_top_images/3.jpg",
                    "Image2": "http://admin.cityrecharge.in/img/app_top_images/6.jpg",
                    "Image3": "http://admin.cityrecharge.in/img/app_top_images/1.jpg",
                    "Image4": "http://admin.cityrecharge.in/img/app_top_images/4.jpg",
                    "Image5": "http://admin.cityrecharge.in/img/app_top_images/2.png",
                    "IsDmtActive": "0",
                    "DmtMessage": "Thank you for choosing Domestic Money Remittance (DMR) Services.",
                    "IsAepsActive": "0",
                    "AepsMessage": "Thank you for choosing Adhaar Enable Payment System (AEPS) Services.",
                    "Message": "N",
                    "Image": "N",
                    "UpiId": "cityrecharge1011001@yesbank",
                    "Image6": "http://api.payesmoney.in/images/dec/6.jpg|http://shop.cityrecharge.in/details.aspx?id=c81e728d9d4c2f636f067f89cc14862c",
                    "Image7": "http://api.payesmoney.in/images/dec/7.jpg|http://shop.cityrecharge.in/details.aspx?id=eccbc87e4b5ce2fe28308fd9f2a7baf3",
                    "Image8": "http://api.payesmoney.in/images/dec/8.jpg|http://shop.cityrecharge.in/details.aspx?id=c4ca4238a0b923820dcc509a6f75849b",
                    "Image9": "http://api.payesmoney.in/images/dec/9.jpg|http://shop.cityrecharge.in/details.aspx?id=a87ff679a2f3e71d9181a67b7542122c",
                    "Image10": "http://api.payesmoney.in/images/dec/10.jpg|http://shop.cityrecharge.in/details.aspx?id=e4da3b7fbbce2345d7772b0674a318d5",
                    "IsTpinRequired": "1",
                    "IsBenepopupRequired": "1"
                }
             */


            JObject jObject = JObject.Parse(HttpContext.Current.Session["UserLoginJSON"].ToString());

            string jTable = jObject["Table"][0].ToString();
            JObject TObject = JObject.Parse(jTable);
            value = TObject[jObjectKey].ToString();

        }
        catch(Exception ex)
        {
            //value = ex.ToString();
        }        
    }


    public static bool GetValueByLoggedInTableByColumn(string columnName, out string value)
    {
        value = "";
        try
        {
            DataTable UserTable = (DataTable)HttpContext.Current.Session["UserTable"];

            if (UserTable != null && UserTable.Rows.Count > 0)
            {
                DataRow userRow = UserTable.Rows[0];
                value = userRow[columnName].ToString();
                return true;
            }
            else
            {
                return false;
            }
        }
        catch
        {
            return false;
        }
    }

    public static bool IsUserLogin()
    {
        try
        {

            if(HttpContext.Current.Session["UserLoginJSON"] != null)
            {
                return true;
            }
        }
        catch
        {
            
        }

        return false;
    }

}

