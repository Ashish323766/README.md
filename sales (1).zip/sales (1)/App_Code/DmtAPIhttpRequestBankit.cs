﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;

/// <summary>
/// Summary description for DmtAPIhttpRequest
/// </summary>

public class DmtAPIhttpRequestBankit
{
    public static string PostRequest(string Parameters)
    {
        // parameter being add as 'method=rlogi&loginid=R1001&password=123456'

        using (WebClient webClient = new WebClient())
        {
            webClient.Headers.Add(HttpRequestHeader.ContentType, "application/x-www-form-urlencoded");
            //webClient.Headers.Add("aksom", "01e51a812b515af9177fef3df70fee10");

            byte[] parameterBytes = System.Text.Encoding.ASCII.GetBytes(Parameters);

            byte[] response = webClient.UploadData("http://bankitv3.sidhmoney.com/multidmt.aspx", "POST", parameterBytes);

            return System.Text.Encoding.ASCII.GetString(response);
        }
    }
}