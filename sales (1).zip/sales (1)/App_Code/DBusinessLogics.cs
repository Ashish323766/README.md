using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Web;
using System.Net.Configuration;

using System.Data;
using MySql.Data.MySqlClient;
using System.Data.Odbc;
using System.Collections.Specialized;
using System.Configuration;
using System.Net;
using System.IO;
using BussinessLogic;

/// <summary>
/// Summary description for BusinessLogics
/// </summary>
namespace DistributorLogic
{
    public class DBusinessLogics
    {
        AdminProperty objProp = new AdminProperty();

        public string Get(string uri)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(uri);
            request.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;

            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            using (Stream stream = response.GetResponseStream())
            using (StreamReader reader = new StreamReader(stream))
            {
                return reader.ReadToEnd();
            }
        }
		

        public string getMethod(AdminProperty prop)
        {
            string responseString = string.Empty;
            try
            {
                string urlValues = prop.Query ;
                string newurl = "http://apiv1.cityrecharge.in/recApiFinal/apiget.aspx?method=sendsms_sidh" + urlValues;
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(newurl);
                request.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;

                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                using (Stream stream = response.GetResponseStream())
                using (StreamReader reader = new StreamReader(stream))
                {
                    responseString = reader.ReadToEnd();
                }

            }
            catch (Exception ex)
            {
                responseString = "N";
            }
            return responseString;
        }
		
		public DataSet aepsRefund(AdminProperty objProp)
		{
			try
			{
				MySqlParameter[] prm = new MySqlParameter[7];
				prm[0] = new MySqlParameter("_txnid", objProp.TxnID);
				prm[1] = new MySqlParameter("_userid", objProp.UserID);
				prm[2] = new MySqlParameter("_amount", objProp.Amount);
				prm[3] = new MySqlParameter("_bank", objProp.accountNumber);
				prm[4] = new MySqlParameter("_empid", objProp.adminLoginId);
				prm[5] = new MySqlParameter("_remark", objProp.Remark);
				prm[6] = new MySqlParameter("_transdate", objProp.TransDate);
				objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "aksom_aeps_settlement_refund", prm);
				return objProp.DataSet;

			}
			catch (Exception ea)
			{ throw; }
		}
		public DataSet createSalesman(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[5];
                prm[0] = new MySqlParameter("_name", objProp.retailername);
                prm[1] = new MySqlParameter("_mobile", objProp.retailerloginid);
                prm[2] = new MySqlParameter("_designation", objProp.Tpin);
                prm[3] = new MySqlParameter("_desialias", objProp.retaileremail);
                prm[4] = new MySqlParameter("_createdby", objProp.retailercretedby);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_add_salesman", prm);
            }
            catch (Exception ea)
            { objProp.ExceptionMessage = ea.ToString(); }
            return objProp.DataSet;
        }

        public DataSet findretailers(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_loginid", objProp.adminLoginId);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_find_admin_mobile", prm);
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet getUserAgreement1(AdminProperty objProp)
        {
            try
            {
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);
            }
            catch (Exception ea)
            { objProp.Error = ea.Message; }
            return objProp.DataSet;
        }

        public DataSet amountDeduct(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[7];
                prm[0] = new MySqlParameter("_userId", objProp.UserID);
                prm[1] = new MySqlParameter("_parentId", objProp.FkSId);
                prm[2] = new MySqlParameter("_amount", Convert.ToDecimal(objProp.Amount));
                prm[3] = new MySqlParameter("_ipaddress", objProp.ipaddress);
                prm[4] = new MySqlParameter("_userType", objProp.TYPE);
                prm[5] = new MySqlParameter("_usercomment", objProp.Remark);
                prm[6] = new MySqlParameter("_loadID", objProp.PdrID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_less_balance_AdminJVM", prm);
            }
            catch (Exception ea)
            { objProp.Error = ea.Message; }
            return objProp.DataSet;
        }

        public DataSet amountadd(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[6];
                prm[0] = new MySqlParameter("_userId", objProp.UserID);
                prm[1] = new MySqlParameter("_parentId", objProp.FkSId);
                prm[2] = new MySqlParameter("_amount", Convert.ToDecimal(objProp.Amount));
                prm[3] = new MySqlParameter("_ipaddress", objProp.ipaddress);
                prm[4] = new MySqlParameter("_userType", objProp.TYPE);
                prm[5] = new MySqlParameter("_usercomment", objProp.Remark);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_add_balance_manually", prm);
            }
            catch (Exception ea)
            { objProp.Error = ea.Message; }
            return objProp.DataSet;
        }


        public AdminProperty bindcat_subcate(AdminProperty objProp)
        {
            try
            {
                objProp.Query = "SELECT `submenu_title`,`pk_submenu_id`,`fk_menu_id`,a.`menu_title` menu_parent_id FROM `aks_submenu` b , `aks_menu` a WHERE  b.`fk_menu_id`=a.pk_menu_id and b.fk_menu_id != '0' and portal_name='b' ORDER BY fk_menu_id,submenu_title ";
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);
                return objProp;
            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet adminLogin(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_loginid", objProp.adminLoginId);
                prm[1] = new MySqlParameter("_password", objProp.adminPassword);
                prm[2] = new MySqlParameter("_ipaddress", objProp.ipaddress);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_admin_login", prm);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public AdminProperty getroleids(AdminProperty objProp)
        {
            try
            {
                //objProp.Role = objProp.Role.Replace(",", "','");
                objProp.Query = @"SELECT pk_role_id,rl_menu,rl_sub_menu  FROM  `master_role` WHERE pk_role_id IN ('" + objProp.Role + "') ";
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);
                return objProp;
            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet UpadteRole(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[6];
                prm[0] = new MySqlParameter("_roleName", objProp.RoleName);
                prm[1] = new MySqlParameter("_menu", objProp.RoleMenu);
                prm[2] = new MySqlParameter("_submenu", objProp.RoleSubMenu);
                prm[3] = new MySqlParameter("_desc", objProp.RoleDesc);
                prm[4] = new MySqlParameter("_createBy", objProp.RoleCreatedBy);
                prm[5] = new MySqlParameter("_pkroleid", objProp.OfferPkID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_update_role", prm);
            }
            catch (Exception ea)
            { throw; }
            return objProp.DataSet;
        }

        public void LogWrite(string query, string infile)
        {
            System.IO.StreamWriter file = null;
            try
            {

                objProp.FileName = "C:\\PayIMPSPAY\\" + System.DateTime.Now.ToString("dd-MMM-yyyy") + "_LOG_" + infile.ToUpper() + ".txt";
                file = new System.IO.StreamWriter(objProp.FileName, true);
                file.WriteLine(".................................." + System.DateTime.Now.ToString() + " IP ..........................>\r\n" + query);
                file.Close();
            }
            catch (Exception ex)
            { }
        }

        public AdminProperty updatetip(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_loginId", objProp.Mobile);
                prm[1] = new MySqlParameter("_pwdnew", objProp.Tpin);
                prm[2] = new MySqlParameter("_ipadd", objProp.ipaddress);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_users_tpin_update", prm);
                return objProp;

            }
            catch (Exception ea)
            { throw; }
        }

        public AdminProperty wtwtransfer(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[5];
                prm[0] = new MySqlParameter("_ReceiverID", objProp.UserID);
                prm[1] = new MySqlParameter("_SenderID", objProp.FkSId);
                prm[2] = new MySqlParameter("_amount", objProp.amount);
                prm[3] = new MySqlParameter("_usercomment", objProp.comment);
                prm[4] = new MySqlParameter("_tpin", objProp.Tpin);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_wallet_to_wallet_send", prm);
                return objProp;
            }
            catch (Exception ea)
            { throw; }
        }


        public AdminProperty updatPwdN(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_loginId", objProp.adminLoginId);
                prm[1] = new MySqlParameter("_pwdnew", objProp.Description);
                prm[2] = new MySqlParameter("_ipadd", objProp.ipaddress);
                objProp.DataReader = DataLayer.ExecuteReader(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_retail_dist_passupdate", prm);
                return objProp;

            }
            catch (Exception ea)
            { throw; }
        }

        public AdminProperty updatTpin(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_loginId", objProp.adminLoginId);
                prm[1] = new MySqlParameter("_pwdnew", objProp.Description);
                prm[2] = new MySqlParameter("_ipadd", objProp.ipaddress);
                objProp.DataReader = DataLayer.ExecuteReader(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_users_tpin_update", prm);
                return objProp;

            }
            catch (Exception ea)
            { throw; }
        }

        //Update Load Request BLogic

        public AdminProperty LoadReupDate(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[7];
                prm[0] = new MySqlParameter("_utrno", objProp.UTRNO);
                prm[1] = new MySqlParameter("_amount", objProp.Amount);
                prm[2] = new MySqlParameter("_bankid", objProp.bankId);
                prm[3] = new MySqlParameter("_paydate", objProp.paydate);
                prm[4] = new MySqlParameter("_paymode", objProp.PaytmentMode);
                prm[5] = new MySqlParameter("_remark", objProp.Remark);
                prm[6] = new MySqlParameter("_loadid", objProp.ORDERID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_update_load", prm);
                return objProp;
            }
            catch (Exception ea)
            { throw; }
        }

        public AdminProperty LoadReupDate_v1(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[8];
                prm[0] = new MySqlParameter("_utrno", objProp.UTRNO);
                prm[1] = new MySqlParameter("_amount", objProp.Amount);
                prm[2] = new MySqlParameter("_bankid", objProp.bankId);
                prm[3] = new MySqlParameter("_paydate", objProp.paydate);
                prm[4] = new MySqlParameter("_paymode", objProp.PaytmentMode);
                prm[5] = new MySqlParameter("_remark", objProp.Remark);
                prm[6] = new MySqlParameter("_loadid", objProp.ORDERID);
                prm[7] = new MySqlParameter("_payslip", objProp.payslip);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_update_load_v1", prm);
                return objProp;
            }
            catch (Exception ea)
            { throw; }
        }



        public AdminProperty updatMpin(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[2];
                prm[0] = new MySqlParameter("_logid", objProp.UserID);
                prm[1] = new MySqlParameter("_pin", objProp.pincode);
                objProp.DataReader = DataLayer.ExecuteReader(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_update_mpin", prm);
                return objProp;

            }
            catch (Exception ea)
            { throw; }
        }


        public AdminProperty forgotPwd(AdminProperty objProp)
        {
            try
            {
                objProp.DataReader = DataLayer.ExecuteReader(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);
                return objProp;
            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet retailerTpin(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[2];
                prm[0] = new MySqlParameter("_loginid", objProp.adminLoginId);
                prm[1] = new MySqlParameter("_tpin", objProp.adminPassword);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_check_tpin", prm);
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet checkmobile(AdminProperty objProp)
        {
            try
            {
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }


        public DataSet bindDistDetails(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_loginid", objProp.PdrID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_get_dist_details", prm);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet bindcnfDetails(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_loginid", objProp.PdrID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_get_pmcnf_details", prm);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet updatedistdata(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[4];
                prm[0] = new MySqlParameter("_logid", objProp.PdrID);
                prm[1] = new MySqlParameter("_email", objProp.TfName);
                prm[2] = new MySqlParameter("_name", objProp.TfAlias);
                prm[3] = new MySqlParameter("_shopname", objProp.shopnames);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_distributor_update", prm);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet checkpassword(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[2];
                prm[0] = new MySqlParameter("_loginid", objProp.adminLoginId);
                prm[1] = new MySqlParameter("_password", objProp.Password);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_check_password", prm);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet updatdistPwd(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[2];
                prm[0] = new MySqlParameter("_rtpwd", objProp.Description);
                prm[1] = new MySqlParameter("_loginId", objProp.UserID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_distpass_update", prm);
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public AdminProperty AddLoad(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[4];
                prm[0] = new MySqlParameter("_loadid", objProp.FkSId);
                prm[1] = new MySqlParameter("_amount", objProp.Amountn);
                prm[2] = new MySqlParameter("_usercomment", objProp.Remark);
                prm[3] = new MySqlParameter("_status", objProp.Status);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_admin_add_load", prm);

            }
            catch (Exception ea)
            { objProp.Error = ea.ToString(); }
            return objProp;
        }
        public AdminProperty AddLoadBySuperCNF(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[6];
                prm[0] = new MySqlParameter("_loadid", objProp.FkSId);
                prm[1] = new MySqlParameter("_amount", objProp.amount);
                prm[2] = new MySqlParameter("_usercomment", objProp.Remark);
                prm[3] = new MySqlParameter("_status", objProp.Status);
                prm[4] = new MySqlParameter("_sessionprtid", objProp.PdrID);
                prm[5] = new MySqlParameter("_banktid", objProp.BankTransId);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_addload_by_JvmPay_v2", prm);
				// objProp.DataReader = DataLayer.ExecuteReader(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_addload_by_JvmPay_v2", prm);
				
            }
            catch (Exception ea)
            { objProp.Error = ea.ToString(); }
            return objProp;
        }
        public AdminProperty AddLoadByParent(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[5];
                prm[0] = new MySqlParameter("_loadid", objProp.FkSId);
                prm[1] = new MySqlParameter("_amount", objProp.amount);
                prm[2] = new MySqlParameter("_usercomment", objProp.Remark);
                prm[3] = new MySqlParameter("_status", objProp.Status);
                prm[4] = new MySqlParameter("_sessionprtid", objProp.PdrID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_addload_byparent", prm);

            }
            catch (Exception ea)
            { objProp.Error = ea.ToString(); }
            return objProp;
        }


        public AdminProperty getrmtrName(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_phone", objProp.MobileNumber);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_get_remitter_name", prm);
                return objProp;

            }
            catch (Exception ea)
            { throw; }
        }


        public DataSet BarChartDataNew(AdminProperty objProp)
        {

            try
            {
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);

            }
            catch (Exception ea)
            { objProp.Error = ea.ToString(); }
            return objProp.DataSet;
        }

        public AdminProperty userLedger(AdminProperty objProp)
        {

            try
            {
                objProp.DataReader = DataLayer.ExecuteReader(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);
            }
            catch (Exception ea)
            { objProp.Error = ea.ToString(); }
            return objProp;
        }

        public AdminProperty PaytmAddLoad(AdminProperty objProp)
        {

            try
            {
                LogWrite(objProp.ORDERID + "|" + objProp.TxnAmount + "|" + objProp.Status, "PAYTM_RESPONSE");
                MySqlParameter[] prm = new MySqlParameter[4];
                prm[0] = new MySqlParameter("_loadid", objProp.ORDERID);
                prm[1] = new MySqlParameter("_amount", objProp.TxnAmount);
                prm[2] = new MySqlParameter("_usercomment", objProp.Remark);
                prm[3] = new MySqlParameter("_status", objProp.Status);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_admin_add_load", prm);

            }
            catch (Exception ea)
            { objProp.Error = ea.ToString(); LogWrite(objProp.ORDERID + ea.ToString(), "PAYTM_RESPONSE"); }
            return objProp;
        }

        public AdminProperty getUserRecord1(AdminProperty objProp)
        {
            try
            {
                objProp.DataReader = DataLayer.ExecuteReader(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);
            }
            catch (Exception ea)
            { objProp.Error = ea.Message; }
            return objProp;
        }

        public AdminProperty advanceaddbalance(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[4];
                prm[0] = new MySqlParameter("_userId", objProp.retlpkid);
                prm[1] = new MySqlParameter("_parentId", objProp.distrilpkid);
                prm[2] = new MySqlParameter("_amount", objProp.lamount);
                prm[3] = new MySqlParameter("_usercomment", objProp.lcomment);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_addbal_fromadvance", prm);
                return objProp;
            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet getUserRecord(AdminProperty objProp)
        {

            try
            {
                //  MySqlParameter[] prm = new MySqlParameter[4];
                //prm[0] = new MySqlParameter("_amount", objProp.Amount);
                //prm[1] = new MySqlParameter("_userId", objProp.UserID);
                //prm[2] = new MySqlParameter("_type", objProp.UserTypeStr);
                //prm[3] = new MySqlParameter("_status", objProp.Status);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);


            }
            catch (Exception ea)
            { objProp.Error = ea.Message; }
            return objProp.DataSet;
        }

        public AdminProperty gettransactionhistoryn(AdminProperty objProp)
        {
            try
            {
                //  MySqlParameter[] prm = new MySqlParameter[4];
                //prm[0] = new MySqlParameter("_amount", objProp.Amount);
                //prm[1] = new MySqlParameter("_userId", objProp.UserID);
                //prm[2] = new MySqlParameter("_type", objProp.UserTypeStr);
                //prm[3] = new MySqlParameter("_status", objProp.Status);
                objProp.DataReader = DataLayer.ExecuteReader(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);
                return objProp;

            }
            catch (Exception ea)
            { throw; }
            
        }

        public DataSet updateload(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[4];
                prm[0] = new MySqlParameter("_pkloadid", objProp.FkSId);
                prm[1] = new MySqlParameter("_amount", objProp.Amount);
                prm[2] = new MySqlParameter("_loadid", objProp.load);
                prm[3] = new MySqlParameter("_remark", objProp.Remark);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_load_update", prm);

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet getAPIPartLoadRequest(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[11];
                prm[0] = new MySqlParameter("_userid", objProp.FkSId);
                prm[1] = new MySqlParameter("_type", objProp.TYPE);
                prm[2] = new MySqlParameter("_amount", objProp.Amount);
                prm[3] = new MySqlParameter("_description", objProp.Description);
                prm[4] = new MySqlParameter("_priority", objProp.Priority);
                prm[5] = new MySqlParameter("_userType", objProp.UserTypeStr);
                prm[6] = new MySqlParameter("_bnkid", objProp.bankId);
                prm[7] = new MySqlParameter("_utrno", objProp.UTRNO);
                prm[8] = new MySqlParameter("_paymode", objProp.payModen);
                prm[9] = new MySqlParameter("_pay_slip", objProp.payslip);
                prm[10] = new MySqlParameter("_paydate", objProp.TransDate);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_load_request_sidh_toadmin", prm);

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet addCompanyPersonalBankAccount(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[7];
                prm[0] = new MySqlParameter("_bank", objProp.bankname);
                prm[1] = new MySqlParameter("_acc_holder", objProp.username);
                prm[2] = new MySqlParameter("_accno", objProp.accountNumber);
                prm[3] = new MySqlParameter("_ifsc", objProp.ifscCode);
                prm[4] = new MySqlParameter("_branch", objProp.branch);
                prm[5] = new MySqlParameter("_logo", objProp.ProfilePhoto);
                prm[6] = new MySqlParameter("_charge", objProp.amount);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_add_bank", prm);

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }
        public DataSet deleteCompanyPersonalBankAccount(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_bankid", objProp.bankId);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_delete_company_bank", prm);

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }
        public DataSet getBankName(AdminProperty objProp)
        {
            try
            {
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_get_bank_list");

                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet getPdrName(AdminProperty objProp)
        {
            try
            {
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_get_pname");

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public AdminProperty createRTDmt(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_fk_rt_id", objProp.UserID);
                prm[1] = new MySqlParameter("_kyc_pan", objProp.TfName);
                prm[2] = new MySqlParameter("_kyc_aadhaar", objProp.ApiName);
                objProp.Description = Convert.ToString(DataLayer.ExecuteScalar(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_insert_retailer_kyc", prm));

            }
            catch (Exception ea)
            { objProp.Description = ea.ToString(); }
            return objProp;
        }


        public DataSet getHistoryCount(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_userid", objProp.UserID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_dist_dashboard_new", prm);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }
		
		  public DataSet retailerUpdatePwd(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[2];
                prm[0] = new MySqlParameter("_rtpwd1", objProp.adminPassword);
				prm[1] = new MySqlParameter("_loginId", objProp.adminLoginId);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_rt_change_password", prm);
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet updateopidrch(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[2];
                prm[0] = new MySqlParameter("_opidno", objProp.OpCode);
                prm[1] = new MySqlParameter("_transid", objProp.transctnid);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_opidupdate_rch", prm);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }

        public AdminProperty shopnameddl(AdminProperty objProp)
        {
            try
            {
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);
                //return objProp;
            }
            catch (Exception ea)
            { objProp.Error = ea.ToString(); }
            return objProp;
        }

        public AdminProperty usesReport(AdminProperty objProp)
        {

            try
            {
                objProp.DataReader = DataLayer.ExecuteReader(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);
            }
            catch (Exception ea)
            { objProp.Error = ea.ToString(); }
            return objProp;
        }

       


        public AdminProperty viewretailer(AdminProperty objProp)
        {
            try
            {
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);
                return objProp;
            }
            catch (Exception ea)
            { throw; }
        }

        public AdminProperty addcreditDiary(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[7];
                prm[0] = new MySqlParameter("_userId", objProp.retpkid);
                prm[1] = new MySqlParameter("_parentId", objProp.distripkid);
                prm[2] = new MySqlParameter("_amount", objProp.amount);
                prm[3] = new MySqlParameter("_userType", objProp.usertype);
                prm[4] = new MySqlParameter("_usercomment", objProp.comment);
                prm[5] = new MySqlParameter("_ipaddress", objProp.ipaddress);
                prm[6] = new MySqlParameter("_type", objProp.paytype);

                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_addcredit", prm);
                return objProp;
            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet receiveamount(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[4];
                prm[0] = new MySqlParameter("_userId", objProp.retpkid);
                prm[1] = new MySqlParameter("_amount", objProp.amount);
                prm[2] = new MySqlParameter("_creditBalance", objProp.usertype);
                prm[3] = new MySqlParameter("_usercomment", objProp.comment);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_receive_amount", prm);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }


        public AdminProperty updatebalane(AdminProperty objProp)
        {
            
            try
            {
                 MySqlParameter[] prm = new MySqlParameter[6];
                 prm[0] = new MySqlParameter("_userId", objProp.retpkid);
                 prm[1] = new MySqlParameter("_parentId", objProp.distripkid);
                 prm[2] = new MySqlParameter("_amount", objProp.amount);
                 prm[3] = new MySqlParameter("_ipaddress", objProp.ipaddress);
                 prm[4] = new MySqlParameter("_userType", objProp.usertype);
                 prm[5] = new MySqlParameter("_usercomment", objProp.comment);
                 objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_add_balance", prm);
                return objProp;
            }
            catch (Exception ea)
            { throw; }
        }

        public AdminProperty lessuserbalane(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[7];
                prm[0] = new MySqlParameter("_userId", objProp.retlpkid);
                prm[1] = new MySqlParameter("_parentId", objProp.distrilpkid);
                prm[2] = new MySqlParameter("_amount", objProp.lamount);
                prm[3] = new MySqlParameter("_ipaddress", objProp.lipaddress);
                prm[4] = new MySqlParameter("_userType", objProp.lusertype);
                prm[5] = new MySqlParameter("_usercomment", objProp.lcomment);
                prm[6] = new MySqlParameter("_loadID", objProp.load);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_less_balance", prm);
                return objProp;
            }
            catch (Exception ea)
            { throw; }
        }
        


        public DataSet createcnf(AdminProperty objProp)
        {

            try
            {
                 LogWrite("Start cnf creation","_CREATE_CNF");
				MySqlParameter[] prm = new MySqlParameter[15];
				prm[0] = new MySqlParameter("_loginid", objProp.retailerloginid);
				prm[1] = new MySqlParameter("_password", objProp.retailerpassword);
				prm[2] = new MySqlParameter("_emailid", objProp.retaileremail);
				prm[3] = new MySqlParameter("_type", objProp.retailertype);
				prm[4] = new MySqlParameter("_createdby", objProp.retailercretedby);
				prm[5] = new MySqlParameter("_shopname", objProp.retailershopname);
				prm[6] = new MySqlParameter("_shoppin", objProp.retailershoppin);
				prm[7] = new MySqlParameter("_shopaddress", objProp.retailershopaddress);
				prm[8] = new MySqlParameter("_aadhar", objProp.retaileraadhar);
				prm[9] = new MySqlParameter("_pancard", objProp.retailerpancard);
				prm[10] = new MySqlParameter("_gst", objProp.retailergst);
				prm[11] = new MySqlParameter("_name", objProp.retailername);
				prm[12] = new MySqlParameter("_tpin", objProp.Tpin);
				prm[13] = new MySqlParameter("_salesperson", objProp.SalesPerson);
				prm[14] = new MySqlParameter("_mpin", objProp.MPin);
				objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_registration_cnf_bymcnf", prm);
            }
            catch (Exception ea)
            { objProp.ExceptionMessage = ea.ToString();
            LogWrite(ea.ToString(),"_CREATE_CNF");
             }
            return objProp.DataSet;
        }
        public AdminProperty createuser(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[13];
                prm[0] = new MySqlParameter("_loginid", objProp.retailerloginid);
                prm[1] = new MySqlParameter("_password", objProp.retailerpassword);
                prm[2] = new MySqlParameter("_emailid", objProp.retaileremail);
                prm[3] = new MySqlParameter("_type", objProp.retailertype);
                prm[4] = new MySqlParameter("_createdby", objProp.retailercretedby);
                prm[5] = new MySqlParameter("_shopname", objProp.retailershopname);
                prm[6] = new MySqlParameter("_shoppin", objProp.retailershoppin);
                prm[7] = new MySqlParameter("_shopaddress", objProp.retailershopaddress);
                prm[8] = new MySqlParameter("_aadhar", objProp.retaileraadhar);
                prm[9] = new MySqlParameter("_pancard", objProp.retailerpancard);
                prm[10] = new MySqlParameter("_gst", objProp.retailergst);
                prm[11] = new MySqlParameter("_name", objProp.retailername);
                prm[12] = new MySqlParameter("_tpin", objProp.Tpin);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_b2b_registration", prm);
            }
            catch (Exception ea)
            { objProp.ExceptionMessage = ea.ToString(); }
            return objProp;
        }
        public DataSet createretailer(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[13];
                prm[0] = new MySqlParameter("_loginid", objProp.retailerloginid);
                prm[1] = new MySqlParameter("_password", objProp.retailerpassword);
                prm[2] = new MySqlParameter("_emailid", objProp.retaileremail);
                prm[3] = new MySqlParameter("_type", objProp.retailertype);
                prm[4] = new MySqlParameter("_createdby", objProp.retailercretedby);
                prm[5] = new MySqlParameter("_shopname", objProp.retailershopname);
                prm[6] = new MySqlParameter("_shoppin", objProp.retailershoppin);
                prm[7] = new MySqlParameter("_shopaddress", objProp.retailershopaddress);
                prm[8] = new MySqlParameter("_aadhar", objProp.retaileraadhar);
                prm[9] = new MySqlParameter("_pancard", objProp.retailerpancard);
                prm[10] = new MySqlParameter("_gst", objProp.retailergst);
                prm[11] = new MySqlParameter("_name", objProp.retailername);
                prm[12] = new MySqlParameter("_tpin", objProp.Tpin);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_b2b_registration", prm);

            }
            catch (Exception ea)
            { objProp.ExceptionMessage = ea.ToString(); }
            return objProp.DataSet;
        }


        public DataSet distributorLogin(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_loginid", objProp.adminLoginId);
                prm[1] = new MySqlParameter("_password", objProp.adminPassword);
                prm[2] = new MySqlParameter("_ipaddress", objProp.IpAddress);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_distributor_login", prm);
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }



        public int createTariff(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[2];
                prm[0] = new MySqlParameter("_tf_name", objProp.TfName);
                prm[1] = new MySqlParameter("_tf_code", objProp.TfAlias);
                objProp.Result = DataLayer.ExecuteNonQuery(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_insert_tariff", prm);

                if (objProp.Result > 0)
                {
                    objProp.Result = 1;
                }
                else
                {
                    objProp.Result = 0;
                }
                return objProp.Result;
            }
            catch (Exception ea)
            { throw; }
        }
        public int updateTarif(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_pk_id", objProp.TarifID);
                prm[1] = new MySqlParameter("_tf_name", objProp.TfName);
                prm[2] = new MySqlParameter("_tf_code", objProp.TfAlias);
                objProp.Result = DataLayer.ExecuteNonQuery(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_update_tariff", prm);

                if (objProp.Result > 0)
                {
                    objProp.Result = 1;
                }
                else
                {
                    objProp.Result = 0;
                }

                return objProp.Result;

            }
            catch (Exception ea)
            { throw; }
        }
        public DataSet getTarifRecord(AdminProperty objProp)
        {

            try
            {

                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_view_tariff");

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public AdminProperty updatPwd(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[2];
                prm[0] = new MySqlParameter("_rtpwd", objProp.Description);
                prm[1] = new MySqlParameter("_loginId", objProp.UserID);
                objProp.Password = Convert.ToString(DataLayer.ExecuteScalar(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_rt_update_password", prm));
                return objProp;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet getAPIRecord(AdminProperty objProp)
        {

            try
            {

                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_view_api");

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }
        public int createAPI(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[5];
                prm[0] = new MySqlParameter("_api_name", objProp.ApiName);
                prm[1] = new MySqlParameter("_api_comp", objProp.ApiCompny);
                prm[2] = new MySqlParameter("_api_pwd", objProp.ApiPwd);
                prm[3] = new MySqlParameter("_api_key", objProp.ApiKey);
                prm[4] = new MySqlParameter("_api_url", objProp.ApiUrl);
                objProp.Result = DataLayer.ExecuteNonQuery(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_insert_api", prm);

                if (objProp.Result > 0)
                {
                    objProp.Result = 1;
                }
                else
                {
                    objProp.Result = 0;
                }

                return objProp.Result;

            }
            catch (Exception ea)
            { throw; }
        }
        public int updateAPI(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[6];
                prm[0] = new MySqlParameter("_pk_id", objProp.ApiID);
                prm[1] = new MySqlParameter("_api_name", objProp.ApiName);
                prm[2] = new MySqlParameter("_api_comp", objProp.ApiCompny);
                prm[3] = new MySqlParameter("_api_pwd", objProp.ApiPwd);
                prm[4] = new MySqlParameter("_api_key", objProp.ApiKey);
                prm[5] = new MySqlParameter("_api_url", objProp.ApiUrl);
                objProp.Result = DataLayer.ExecuteNonQuery(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_update_api", prm);

                if (objProp.Result > 0)
                {
                    objProp.Result = 1;
                }
                else
                {
                    objProp.Result = 0;
                }

                return objProp.Result;

            }
            catch (Exception ea)
            { throw; }
        }

        public int createService(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_service_name", objProp.SrvcName);
                prm[1] = new MySqlParameter("_pdr_alias", objProp.SrvcAlias);
                prm[2] = new MySqlParameter("_modifyby", objProp.ModifyBy);
                objProp.Result = DataLayer.ExecuteNonQuery(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_insert_service_type", prm);

                if (objProp.Result > 0)
                {
                    objProp.Result = 1;
                }
                else
                {
                    objProp.Result = 0;
                }

                return objProp.Result;

            }
            catch (Exception ea)
            { throw; }
        }
        public DataSet getServiceRecord(AdminProperty objProp)
        {

            try
            {

                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_view_service_type");

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }
        public int updateService(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[4];
                prm[0] = new MySqlParameter("_serviceid", objProp.SrvcID);
                prm[1] = new MySqlParameter("_service_name", objProp.SrvcName);
                prm[2] = new MySqlParameter("_st_alias", objProp.SrvcAlias);
                prm[3] = new MySqlParameter("_modifyby", objProp.ModifyBy);
                objProp.Result = DataLayer.ExecuteNonQuery(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_update_service_type", prm);

                if (objProp.Result > 0)
                {
                    objProp.Result = 1;
                }
                else
                {
                    objProp.Result = 0;
                }

                return objProp.Result;

            }
            catch (Exception ea)
            { throw; }
        }

        public int createProvider(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[5];
                prm[0] = new MySqlParameter("_pdr_name", objProp.PdrName);
                prm[1] = new MySqlParameter("_pdr_alias", objProp.PdrAlias);
                prm[2] = new MySqlParameter("_fk_serviceId", objProp.FkSId);
                prm[3] = new MySqlParameter("_createby", objProp.PdrCreatedBy);
                prm[4] = new MySqlParameter("_pdr_type", objProp.PdrType);
                objProp.Result = DataLayer.ExecuteNonQuery(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_insert_provider_type", prm);

                if (objProp.Result > 0)
                {
                    objProp.Result = 1;
                }
                else
                {
                    objProp.Result = 0;
                }

                return objProp.Result;

            }
            catch (Exception ea)
            { throw; }
        }
        public DataSet getProviderRecord(AdminProperty objProp)
        {

            try
            {
               // objProp.UserID = "1";
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_userId", objProp.UserID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "spt_get_commision_chart", prm);
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }
        public int updateProvider(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[6];
                prm[0] = new MySqlParameter("_pdr_name", objProp.PdrName);
                prm[1] = new MySqlParameter("_pdr_alias", objProp.PdrAlias);
                prm[2] = new MySqlParameter("_serviceId", objProp.FkSId);
                prm[3] = new MySqlParameter("_modifyby", objProp.PdrCreatedBy);
                prm[4] = new MySqlParameter("_pdr_type", objProp.PdrType);
                prm[5] = new MySqlParameter("_pdrid", objProp.PdrType);
                objProp.Result = DataLayer.ExecuteNonQuery(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_update_provider_type", prm);

                if (objProp.Result > 0)
                {
                    objProp.Result = 1;
                }
                else
                {
                    objProp.Result = 0;
                }

                return objProp.Result;

            }
            catch (Exception ea)
            { throw; }
        }

        public int createTransaction(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_trans_name", objProp.TrnsName);
                prm[1] = new MySqlParameter("_trans_alias", objProp.TrnsAlias);
                prm[2] = new MySqlParameter("_createby", objProp.TrnsCreatedBy);
                objProp.Result = DataLayer.ExecuteNonQuery(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_insert_transaction_type", prm);

                if (objProp.Result > 0)
                {
                    objProp.Result = 1;
                }
                else
                {
                    objProp.Result = 0;
                }

                return objProp.Result;

            }
            catch (Exception ea)
            { throw; }
        }
		
		
        public int updateMPIN(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[2];
                prm[0] = new MySqlParameter("_logid", objProp.PdrID);
                prm[1] = new MySqlParameter("_pin", objProp.ApiPwd);
                objProp.Result = DataLayer.ExecuteNonQuery(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_update_mpin", prm);

                if (objProp.Result > 0)
                {
                    objProp.Result = 1;
                }
                else
                {
                    objProp.Result = 0;
                }

                return objProp.Result;

            }
            catch (Exception ea)
            { throw; }
        }
		
        public int updateRTDetails(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[7];
                prm[0] = new MySqlParameter("_logid", objProp.PdrID);
                prm[1] = new MySqlParameter("_email", objProp.TfName);
                prm[2] = new MySqlParameter("_name", objProp.TfAlias);
                prm[3] = new MySqlParameter("_shop_name", objProp.TarifID);
                prm[4] = new MySqlParameter("_pk_user_id", objProp.ApiID);
                prm[5] = new MySqlParameter("_postcode", objProp.ApiPwd);
                prm[6] = new MySqlParameter("_ofc_adress", objProp.ApiCompny);
                objProp.Result = DataLayer.ExecuteNonQuery(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_update_retailer", prm);

                if (objProp.Result > 0)
                {
                    objProp.Result = 1;
                }
                else
                {
                    objProp.Result = 0;
                }

                return objProp.Result;

            }
            catch (Exception ea)
            { throw; }
        }
        public DataSet bindRTDetails(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_loginid", objProp.PdrID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_get_retailer_details", prm);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet getFM(AdminProperty objProp)
        {

            try
            {
               
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet getMasterBalance(AdminProperty objProp)
        {

            try
            {
                objProp.Query = "sp_ret_get_balance";
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_userid", objProp.UserID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, objProp.Query, prm);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }
        public DataSet getTransactionRecord(AdminProperty objProp)
        {

            try
            {
                objProp.Query = "sp_ret_get_transaction";
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_userid", objProp.UserID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, objProp.Query, prm);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }
        public DataSet getDTHTransaction(AdminProperty objProp)
        {

            try
            {
                objProp.Query = "sp_ret_get_dth_transaction";
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_userid", objProp.UserID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, objProp.Query, prm);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }
        public DataSet transactionHistory(AdminProperty objProp)
        {

            try
            {
                  objProp.Query = "sp_ret_transaction_history";
                  MySqlParameter[] prm = new MySqlParameter[1];
                  prm[0] = new MySqlParameter("_userid", objProp.UserID); 
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, objProp.Query,prm);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet getStateCity(AdminProperty objLogin)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_pincode", objLogin.pincode);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_get_state_by_pincode", prm);
            }
            catch (Exception ea)
            { throw; }
            return objProp.DataSet;
        }

        public DataSet transactionHistory1(AdminProperty objProp)
        {

            try
            {
              /*  objProp.Query = "sp_ret_transaction_history";
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_userid", objProp.UserID); */
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet createComplaint(AdminProperty objProp)
        {

            try
            {

                MySqlParameter[] prm = new MySqlParameter[4];
                prm[0] = new MySqlParameter("_tid", objProp.transctnid);
                prm[1] = new MySqlParameter("_type", objProp.TYPE);
                prm[2] = new MySqlParameter("_message", objProp.Description);
                prm[3] = new MySqlParameter("_userid", objProp.UserID);
                //prm[4] = new MySqlParameter("_amount", objProp.Amount);
                //prm[5] = new MySqlParameter("_tckid", objProp.TarifID);
                //prm[6] = new MySqlParameter("_mobile", objProp.MobileNumber);
                //prm[7] = new MySqlParameter("_transid", objProp.TrnsID);
                //prm[8] = new MySqlParameter("_opid", objProp.otp);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "city_ticket_create", prm);

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

       // public DataSet createComplaint(AdminProperty objProp)
       // {
       //
       //     try
       //     {
       //       
       //         MySqlParameter[] prm = new MySqlParameter[9];
       //         prm[0] = new MySqlParameter("_compt_by", objProp.UserID);
       //         prm[1] = new MySqlParameter("_trans_type", objProp.TrnsName);
       //         prm[2] = new MySqlParameter("_complaint", objProp.TrnsAlias);
       //         prm[3] = new MySqlParameter("_opname", objProp.TrnsCreatedBy);
       //         prm[4] = new MySqlParameter("_amount", objProp.Amount);
       //         prm[5] = new MySqlParameter("_tckid", objProp.TarifID);
       //         prm[6] = new MySqlParameter("_mobile", objProp.MobileNumber);
       //         prm[7] = new MySqlParameter("_transid", objProp.TrnsID);
       //         prm[8] = new MySqlParameter("_opid", objProp.otp);
       //         objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_ret_create_ticket",prm);
       //
       //         return objProp.DataSet;
       //
       //     }
       //     catch (Exception ea)
       //     { throw; }
       // }

        public int updateTransaction(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[4];
                prm[0] = new MySqlParameter("_transid", objProp.TrnsID);
                prm[1] = new MySqlParameter("_trans_name", objProp.TrnsName);
                prm[2] = new MySqlParameter("_trans_alias", objProp.TrnsAlias);
                prm[3] = new MySqlParameter("_createby", objProp.TrnsCreatedBy);
                objProp.Result = DataLayer.ExecuteNonQuery(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_update_transaction_type", prm);

                if (objProp.Result > 0)
                {
                    objProp.Result = 1;
                }
                else
                {
                    objProp.Result = 0;
                }
                return objProp.Result;

            }
            catch (Exception ea)
            { throw; }
        }
        public DataSet bindPdrList(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_type", objProp.PdrType);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_ret_get_provider", prm);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }
		
		 public AdminProperty getPaymentByDate(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[2];
                prm[0] = new MySqlParameter("_userid", objProp.UserID);
				prm[1] = new MySqlParameter("_indate", objProp.LoginDate);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_ret_payment_by_date", prm);
                objProp.Response = "Y";
               

            }
            catch (Exception ea)
            { objProp.Response = ea.ToString(); }
            return objProp;
        }
        public DataSet getPaymentRequest(AdminProperty objProp)
        {

            try
            {
                //   MySqlParameter[] prm = new MySqlParameter[1];
                //  prm[0] = new MySqlParameter("_userid", objProp.UserID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet getretailersdetailsN(AdminProperty objProp)
        {
            try
            {
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);
            }
            catch (Exception ea)
            { throw; }
            return objProp.DataSet;
        }

        public AdminProperty getretailersdetails(AdminProperty objProp)
        {
            try
            {                
                objProp.DataReader = DataLayer.ExecuteReader(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);                
                return objProp;
            }
            catch (Exception ea)
            { throw; }
        }

        public int AddPayment(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[6];
                prm[0] = new MySqlParameter("_userid", objProp.UserID);
                prm[1] = new MySqlParameter("_amount", objProp.Amount);
                prm[2] = new MySqlParameter("_remark", objProp.Remark);
                prm[3] = new MySqlParameter("_addBy", objProp.ADDBY);
                prm[4] = new MySqlParameter("_type", objProp.TYPE);
                prm[5] = new MySqlParameter("_transactionid", objProp.TxnID);
                objProp.Result = DataLayer.ExecuteNonQuery(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_admin_payment_add", prm);

                if (objProp.Result > 0)
                {
                    objProp.Result = 1;
                }
                else
                {
                    objProp.Result = 0;
                }

                return objProp.Result;

            }
            catch (Exception ea)
            { throw; }
        }
        public string doRecharge(AdminProperty.Recharge objRec)
        {
            string responseString = string.Empty;
            try
            {
                string url = "method=recharge&loginid=" + objRec.Loginid + "&mobile=" + objRec.Mobile + "&provider=" + objRec.Provider + "&ttype=" + objRec.transType + "&Service=" + objRec.service + "&amount=" + objRec.Amount;
                string newurl = "http://apiv1.cityrecharge.in/recApiFinal/service.aspx";
                HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create(newurl);
                ASCIIEncoding encoding = new ASCIIEncoding();
                byte[] PostData = encoding.GetBytes(url.ToString());
                httpWReq.Method = "POST";
                httpWReq.ContentType = "application/x-www-form-urlencoded";
                httpWReq.ContentLength = PostData.Length;
                using (Stream stream = httpWReq.GetRequestStream())
                {
                    stream.Write(PostData, 0, PostData.Length);
                }
                HttpWebResponse response = (HttpWebResponse)httpWReq.GetResponse();
                responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();

            }
            catch (Exception ex)
            {
                responseString = "N";
            }
            return responseString;
        }
        public AdminProperty generatePassword(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[4];
                prm[0] = new MySqlParameter("_userid", objProp.UserID);
                prm[1] = new MySqlParameter("_old_pass", objProp.adminPassword);
                prm[2] = new MySqlParameter("_password", objProp.Password);
                prm[3] = new MySqlParameter("_pin", objProp.Tpin);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "create_password_pin", prm);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                    objProp.TrnsID = objProp.DataSet.Tables[0].Rows[0]["id"].ToString();
                    objProp.Description = objProp.DataSet.Tables[0].Rows[0]["desc"].ToString();
                }
                else
                {
                    objProp.TrnsID = "N";
                    objProp.Description = "No Result Found";
                }

               

            }
            catch (Exception ea)
            { objProp.TrnsID = "N"; }
            return objProp;
        }

        //DMT Logic


        public string postMethodForForgotPassword(AdminProperty prop)
        {
            string responseString = string.Empty;
            try
            {

                string newurl = "http://api.payimps.in/recApiFinal/service.aspx";
                HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create(newurl);
                ASCIIEncoding encoding = new ASCIIEncoding();
                byte[] PostData = encoding.GetBytes(prop.ApiUrl.ToString());
                httpWReq.Method = "POST";
                httpWReq.ContentType = "application/x-www-form-urlencoded";
                httpWReq.ContentLength = PostData.Length;
                using (Stream stream = httpWReq.GetRequestStream())
                {
                    stream.Write(PostData, 0, PostData.Length);
                }
                HttpWebResponse response = (HttpWebResponse)httpWReq.GetResponse();
                responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();

            }
            catch (Exception ex)
            {
                responseString = "N";
            }
            return responseString;
        }



        public string postMethod(AdminProperty prop)
        {
            string responseString = string.Empty;
            try
            {

                string newurl = objProp.EKOURL;
                HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create(newurl);
                ASCIIEncoding encoding = new ASCIIEncoding();
                byte[] PostData = encoding.GetBytes(prop.ApiUrl.ToString());
                httpWReq.Method = "POST";
                httpWReq.ContentType = "application/x-www-form-urlencoded";
                httpWReq.ContentLength = PostData.Length;
                using (Stream stream = httpWReq.GetRequestStream())
                {
                    stream.Write(PostData, 0, PostData.Length);
                }
                HttpWebResponse response = (HttpWebResponse)httpWReq.GetResponse();
                responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();

            }
            catch (Exception ex)
            {
                responseString = "N";
            }
            return responseString;
        }

        public DataSet getRMTRKYC(AdminProperty objProp)
        {
            try
            {
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }


        public DataSet retailerGSTINUpdate(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[15];
                prm[0] = new MySqlParameter("_rtMob", objProp.MobileNumber);
                prm[1] = new MySqlParameter("_gstin", objProp.GSTN);
                prm[2] = new MySqlParameter("_officeName", objProp.OfficialName);
                prm[3] = new MySqlParameter("_officeAdd", objProp.OfficeAddress);
                prm[4] = new MySqlParameter("_state", objProp.State);
                prm[5] = new MySqlParameter("_city", objProp.City);
                prm[6] = new MySqlParameter("_authoSign", objProp.AuthorisedName);
                prm[7] = new MySqlParameter("_pancard_front", objProp.PancardFront);
                prm[8] = new MySqlParameter("_adhaar_front", objProp.AdhaarNoFront);
                prm[9] = new MySqlParameter("_adhaar_back", objProp.AdhaarNoBack);
                prm[10] = new MySqlParameter("_us_type", objProp.TYPE);
                prm[11] = new MySqlParameter("_profile_photo", objProp.ProfilePhoto);
                prm[12] = new MySqlParameter("_pan_no", objProp.PanNumber);
                prm[13] = new MySqlParameter("_adhaar_no", objProp.AdhaarNumber);
                prm[14] = new MySqlParameter("_fk_gstinId", objProp.FkSId);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_rt_gstin_details_update", prm);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }



        public DataSet retailerGSTIN(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[16];
                prm[0] = new MySqlParameter("_rtMob", objProp.MobileNumber);
                prm[1] = new MySqlParameter("_gstin", objProp.GSTN);
                prm[2] = new MySqlParameter("_officeName", objProp.OfficialName);
                prm[3] = new MySqlParameter("_officeAdd", objProp.OfficeAddress);
                prm[4] = new MySqlParameter("_state", objProp.State);
                prm[5] = new MySqlParameter("_city", objProp.City);
                prm[6] = new MySqlParameter("_authoSign", objProp.AuthorisedName);
                prm[7] = new MySqlParameter("_pancard_front", objProp.PancardFront);
                prm[8] = new MySqlParameter("_adhaar_front", objProp.AdhaarNoFront);
                prm[9] = new MySqlParameter("_adhaar_back", objProp.AdhaarNoBack);
                prm[10] = new MySqlParameter("_us_type", objProp.TYPE);
                prm[11] = new MySqlParameter("_profile_photo", objProp.ProfilePhoto);
                prm[12] = new MySqlParameter("_pan_no", objProp.PanNumber);
                prm[13] = new MySqlParameter("_adhaar_no", objProp.AdhaarNumber);
                prm[14] = new MySqlParameter("_fk_userid", objProp.FkSId);
                prm[15] = new MySqlParameter("_state_code", objProp.statecode);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_rt_gstin_details", prm);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet remitterKYC(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[5];
                prm[0] = new MySqlParameter("_rmtrno", objProp.MobileNumber);
                prm[1] = new MySqlParameter("_docType", objProp.DocType);
                prm[2] = new MySqlParameter("_doc_front", objProp.DocFront);
                prm[3] = new MySqlParameter("_doc_back", objProp.DocBack);
                prm[4] = new MySqlParameter("_rmtr_photo", objProp.SelfPhoto);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_remitter_kyc_doc",prm);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet getStateList(AdminProperty objProp)
        {
            try
            {
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text,objProp.Query);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet getBankList(AdminProperty objProp)
        {
            try
            {
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_get_paytm_bank");

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }

                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet bindBankIFSC(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_pk_bid", objProp.ApiID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_get_bank_ifsc", prm);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }
        public DataSet bindMoneyHistory(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_cust_id", objProp.UserID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_get_money_trans_history", prm);

                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                }
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }
        public string validateTPIN(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_userid", objProp.ifscCode);
                prm[1] = new MySqlParameter("_tpin", objProp.MobileNumber);
                prm[2] = new MySqlParameter("_amount", objProp.accountNumber);
                objProp.Query = Convert.ToString(DataLayer.ExecuteScalar(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_insert_tariff", prm));

                return objProp.Query;

            }
            catch (Exception ea)
            { throw; }
        }
        public string deleteBene(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_userid", objProp.ifscCode);
                prm[1] = new MySqlParameter("_tpin", objProp.MobileNumber);
                prm[2] = new MySqlParameter("_amount", objProp.accountNumber);
                objProp.Query = Convert.ToString(DataLayer.ExecuteScalar(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_insert_tariff", prm));

                return objProp.Query;

            }
            catch (Exception ea)
            { throw; }
        }
        public AdminProperty serviceCharge(AdminProperty objProp)
        {
            try
            {
                MySqlParameter[] prm = new MySqlParameter[3];
                prm[0] = new MySqlParameter("_amount", objProp.Amount);
                prm[1] = new MySqlParameter("_tpin", objProp.Tpin);
                prm[2] = new MySqlParameter("_userid", objProp.UserID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "dmt_service_charge_rbi", prm);
            }
            catch (Exception ea)
            { objProp.Remark = "N"; objProp.PdrType = ea.ToString(); }
            return objProp;
        }

        public static implicit operator DBusinessLogics(BusinessLogics v)
        {
            throw new NotImplementedException();
        }
    }
    
}