﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Configuration;
/// <summary>
/// Summary description for DmtAPIhttpRequest
/// </summary>
public class DmtAPIhttpRequest
{
     public static string PostRequestMerge(string Parameters)
    {
        // parameter being add as 'method=rlogi&loginid=R1001&password=123456'

        using (WebClient webClient = new WebClient())
        {
            webClient.Headers.Add(HttpRequestHeader.ContentType, "application/x-www-form-urlencoded");
            //webClient.Headers.Add("aksom", "01e51a812b515af9177fef3df70fee10");

            byte[] parameterBytes = System.Text.Encoding.ASCII.GetBytes(Parameters);

            byte[] response = webClient.UploadData("http://localhost/Sidhmoney_Api/paytm.sidhmoney.com/multidmt.aspx", "POST", parameterBytes);

            return System.Text.Encoding.ASCII.GetString(response);
        }
    }
    public static string PostRequest_q(string Parameters)
    {
        // parameter being add as 'method=rlogi&loginid=R1001&password=123456'

        using (WebClient webClient = new WebClient())
        {
            webClient.Headers.Add(HttpRequestHeader.ContentType, "application/x-www-form-urlencoded");
            //webClient.Headers.Add("aksom", "01e51a812b515af9177fef3df70fee10");

            byte[] parameterBytes = System.Text.Encoding.ASCII.GetBytes(Parameters);

            byte[] response = webClient.UploadData("http://localhost/Sidhmoney_Api/paytm.sidhmoney.com/multidmt.aspx", "POST", parameterBytes);

            return System.Text.Encoding.ASCII.GetString(response);
        }
    }
    public static string PostRequestBankit(string Parameters)
    {
        // parameter being add as 'method=rlogi&loginid=R1001&password=123456'

        using (WebClient webClient = new WebClient())
        {
            webClient.Headers.Add(HttpRequestHeader.ContentType, "application/x-www-form-urlencoded");
            //webClient.Headers.Add("aksom", "01e51a812b515af9177fef3df70fee10");
            string url = WebConfigurationManager.AppSettings["PAYTMDMT"].ToString();
            byte[] parameterBytes = System.Text.Encoding.ASCII.GetBytes(Parameters);

            byte[] response = webClient.UploadData(url, "POST", parameterBytes);

            return System.Text.Encoding.ASCII.GetString(response);
        }
    }
}