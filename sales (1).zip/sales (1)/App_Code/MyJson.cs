﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;

/// <summary>
/// Summary description for MyJson
/// </summary>
public class MyJson
{
    OrderedDictionary dataList;

    public MyJson()
    {
        dataList = new OrderedDictionary();
    }

    public string error(string msg)
    {

        dataList.Insert(0, "msg", msg);
        dataList.Insert(0, "success", false);

        JavaScriptSerializer serializer = new JavaScriptSerializer();
        return serializer.Serialize(dataList);

        //return "{'success' : false,'msg' : '" + msg + "'}";
    }

    public string success(string msg)
    {
        dataList.Insert(0, "msg", msg);
        dataList.Insert(0, "success", true);

        JavaScriptSerializer serializer = new JavaScriptSerializer();
        return serializer.Serialize(dataList);

        //return "{'success' : '1','msg' : '" + msg + "'}";
    }

    public void addItem(string key, string value)
    {
        dataList.Add(key, value);
    }

    public string communication_error()
    {

        dataList.Insert(0, "msg", "Communication error. Please try again later.");
        dataList.Insert(0, "success", false);

        JavaScriptSerializer serializer = new JavaScriptSerializer();
        return serializer.Serialize(dataList);
    }

    public string sessionExpired_error()
    {

        dataList.Insert(0, "msg", "Session expired. Please login again.");
        dataList.Insert(0, "success", false);

        JavaScriptSerializer serializer = new JavaScriptSerializer();
        return serializer.Serialize(dataList);
    }


}