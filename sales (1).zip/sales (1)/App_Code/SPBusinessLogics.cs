﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Web;
using System.Net.Configuration;

using System.Data;
using MySql.Data.MySqlClient;
using System.Data.Odbc;
using System.Collections.Specialized;
using System.Configuration;
using System.Net;
using System.IO;
using System.Web.UI.WebControls;

/// <summary>
/// Summary description for BusinessLogics
/// </summary>

    public class SPBusinessLogics
    {
        AdminProperty objProp = new AdminProperty();
        public void fill_ddl(DropDownList dp, string Sp_Name, string textField, string textValue)
        {
            try
            {
                dp.Items.Clear();
                ListItem liState = new ListItem();
                liState.Text = "  Select  ";
                liState.Value = "-1";
                dp.Items.Add(liState);

                objProp.DataReader = DataLayer.ExecuteReader(ConfigurationManager.ConnectionStrings["champshopconstr"].ToString(), CommandType.Text, Sp_Name);
                while (objProp.DataReader.Read())
                {
                    ListItem li = new ListItem();
                    li.Value = objProp.DataReader[textField].ToString().Trim();
                    li.Text = objProp.DataReader[textValue].ToString().Trim();
                    dp.Items.Add(li);
                }
                objProp.DataReader.Close();
            }
            catch (Exception ex)
            {
               // Log_Detail("Blogic.cs" + ex.ToString());
            }
        }

    public DataSet salesReportByDate(AdminProperty objProp)
    {

        try
        {
            MySqlParameter[] prm = new MySqlParameter[2];
            prm[0] = new MySqlParameter("_date", objProp.fromDate);
            prm[1] = new MySqlParameter("_userid", objProp.UserID);
            objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_get_all_sale_bydate_crm_v1", prm);
            return objProp.DataSet;
        }
        catch (Exception ea)
        { throw; }
    }

    public DataSet getPdrName(AdminProperty objProp)
    {
        try
        {
            objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_get_pname");

            return objProp.DataSet;

        }
        catch (Exception ea)
        { throw; }
    }
    public DataSet getBankName(AdminProperty objProp)
    {
        try
        {
            objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_get_bank_list");

            return objProp.DataSet;

        }
        catch (Exception ea)
        { throw; }
    }
    public DataSet CreateUserID(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[13];
                prm[0] = new MySqlParameter("_loginid", objProp.retailerloginid);
                prm[1] = new MySqlParameter("_salespID", objProp.SuperCNFPkID);
                prm[2] = new MySqlParameter("_emailid", objProp.retaileremail);
                prm[3] = new MySqlParameter("_type", objProp.retailertype);
                prm[4] = new MySqlParameter("_createdby", objProp.retailercretedby);
                prm[5] = new MySqlParameter("_shopname", objProp.retailershopname);
                prm[6] = new MySqlParameter("_shoppin", "NA");
                prm[7] = new MySqlParameter("_shopaddress", "NA");
                prm[8] = new MySqlParameter("_aadhar", objProp.retaileraadhar);
                prm[9] = new MySqlParameter("_pancard", objProp.retailerpancard);
                prm[10] = new MySqlParameter("_gst", "NA");
                prm[11] = new MySqlParameter("_name", objProp.retailername);
                prm[12] = new MySqlParameter("_tpin", objProp.Tpin);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_b2b_registration_bySales", prm);
               // return objProp.DataSet;
            }
            catch (Exception ea)
            { objProp.Error = ea.ToString(); }
        return objProp.DataSet;
    }

        public DataSet checkmobile(AdminProperty objProp)
        {
            try
            {
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);
                return objProp.DataSet;
            }
            catch (Exception ea)
            { throw; }
        }

    public AdminProperty shopnameddl(AdminProperty objProp)
    {
        try
        {
            objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);
            //return objProp;
        }
        catch (Exception ea)
        { objProp.Error = ea.ToString(); }
        return objProp;
    }
    public AdminProperty shopnamedd2l(AdminProperty objProp)
    {
        try
        {
            objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.Text, objProp.Query);
            //return objProp;
        }
        catch (Exception ea)
        { objProp.Error = ea.ToString(); }
        return objProp;
    }
    public DataSet getUserRecord(AdminProperty objProp)
    {
        try
        {
            objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr_slave"]), CommandType.Text, objProp.Query);
            //return objProp;
        }
        catch (Exception ea)
        { objProp.Error = ea.ToString(); }
        return objProp.DataSet;
    }

    public DataSet ReatilerView(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[2];
                prm[0] = new MySqlParameter("_userID", objProp.UserID);
                prm[1] = new MySqlParameter("_usType", objProp.usertype);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr_slave"]), CommandType.StoredProcedure, "sp_ViewRetailer_Sales", prm);
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet DashboardView(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_spuserid", objProp.UserID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_salesPerson_dashboard", prm);
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

    public DataSet DashboardViewNew(AdminProperty objProp)
    {

        try
        {
            MySqlParameter[] prm = new MySqlParameter[3];
            prm[0] = new MySqlParameter("_userID", objProp.UserID);
            prm[1] = new MySqlParameter("_fromdate", objProp.fromDate);
            prm[2] = new MySqlParameter("_todate", objProp.toDate);
            objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_CRMDashboard", prm);
            return objProp.DataSet;

        }
        catch (Exception ea)
        { throw; }
    }
	
	  public DataSet UserByParentId(string ustype,string userid)
    {

        try
        {
            MySqlParameter[] prm = new MySqlParameter[2];
            prm[0] = new MySqlParameter("_ustype", ustype);
            prm[1] = new MySqlParameter("_userid", userid);
            objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_userhirerchy_byparentid", prm);
            return objProp.DataSet;

        }
        catch (Exception ea)
        { throw; }
    }

    public DataSet Dashboardsales(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_spuserid", objProp.UserID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_SalesBoard_data", prm);
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

    public DataSet ByUserSalesall(AdminProperty objProp)
    {

        try
        {
            MySqlParameter[] prm = new MySqlParameter[1];
            prm[0] = new MySqlParameter("_spuserid", objProp.UserID);
            objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_getUserbyData_bysp", prm);
            return objProp.DataSet;

        }
        catch (Exception ea)
        { throw; }
    }

    public DataSet ByUserDMTSalesall(AdminProperty objProp)
    {

        try
        {
            MySqlParameter[] prm = new MySqlParameter[1];
            prm[0] = new MySqlParameter("_spuserid", objProp.UserID);
            objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_getUserbyDMTData_bysp", prm);
            return objProp.DataSet;

        }
        catch (Exception ea)
        { throw; }
    }

    public DataSet ByUserAePSSalesall(AdminProperty objProp)
    {

        try
        {
            MySqlParameter[] prm = new MySqlParameter[1];
            prm[0] = new MySqlParameter("_spuserid", objProp.UserID);
            objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_getUserbyAepsData_bysp", prm);
            return objProp.DataSet;

        }
        catch (Exception ea)
        { throw; }
    }

    public DataSet ByUserDMTSales(AdminProperty objProp)
    {

        try
        {
            MySqlParameter[] prm = new MySqlParameter[1];
            prm[0] = new MySqlParameter("_spuserid", objProp.UserID);
            objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_getsalesdmt_bysp", prm);
            return objProp.DataSet;

        }
        catch (Exception ea)
        { throw; }
    }

    public DataSet CreditViewsales(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[1];
                prm[0] = new MySqlParameter("_spuserid", objProp.UserID);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_creditview_bysp", prm);
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }

        public DataSet createQuery(AdminProperty objProp)
        {

            try
            {
                MySqlParameter[] prm = new MySqlParameter[4];
                prm[0] = new MySqlParameter("_usersid", objProp.UserID);
                prm[1] = new MySqlParameter("_qname", objProp.adminName);
                prm[2] = new MySqlParameter("_qmobile", objProp.Mobile);
                prm[3] = new MySqlParameter("_qdetails", objProp.Description);
                objProp.DataSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_insertQuery_sales", prm);
                return objProp.DataSet;

            }
            catch (Exception ea)
            { throw; }
        }
    }
    
