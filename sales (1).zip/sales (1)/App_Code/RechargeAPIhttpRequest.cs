﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;

/// <summary>
/// Summary description for RechargeAPIhttpRequest
/// </summary>
public class RechargeAPIhttpRequest
{
    public static string PostRequest(string Parameters)
    {
        // parameter being add as 'method=rlogi&loginid=R1001&password=123456'

        using (WebClient webClient = new WebClient())
        {
            webClient.Headers.Add(HttpRequestHeader.ContentType, "application/x-www-form-urlencoded");
            webClient.Headers.Add("aksom", "01e51a812b515af9177fef3df70fee10");

            byte[] parameterBytes = System.Text.Encoding.ASCII.GetBytes(Parameters);

            byte[] response = webClient.UploadData("http://apiv1.cityrecharge.in/recApiFinal/service.aspx", "POST", parameterBytes);

            return System.Text.Encoding.ASCII.GetString(response);
        }
    }

    public static string GetRequest(string url, string Parameters)
    {
        // parameter being add as 'method=rlogi&loginid=R1001&password=123456'
        WebRequest request = WebRequest.Create(url + Parameters);
        request.Method = "GET";
        using (WebResponse response = request.GetResponse())
        {
            StreamReader sr = new StreamReader(response.GetResponseStream());
            return sr.ReadToEnd();
        }
    }
}