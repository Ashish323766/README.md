﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Miscellaneous
/// </summary>
public class Miscellaneous
{
    
    public static bool isAllDigits(string mobileNumber)
    {
        foreach (Char ch in mobileNumber)
        {
            if (!Char.IsDigit(ch))
            {
                return false;
            }
        }

        return true;
    }


}