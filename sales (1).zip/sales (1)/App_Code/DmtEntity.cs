﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DmtEntity
/// </summary>
public class GetDmtCustomer
{

    

    public class Limit
    {
        public string name { get; set; }
        public string pipe { get; set; }
        public string used { get; set; }
        public int? priority { get; set; }
        public string remaining { get; set; }
        public string status { get; set; }
    }
    public class Data
    {
        public string customer_id_type { get; set; }
        public decimal available_limit { get; set; }
        public string balance { get; set; }
        public string state_desc { get; set; }
        public string name { get; set; }
        public string mobile { get; set; }
        public List<Limit> limit { get; set; }
        public string currency { get; set; }
        public string state { get; set; }
        public string customer_id { get; set; }
        public decimal used_limit { get; set; }
        public decimal total_limit { get; set; }
        public string invalid_params { get; set; }
    }
    public class RootObject
    {
        public int response_status_id { get; set; }
        public Data data { get; set; }
        public int response_type_id { get; set; }
        public string message { get; set; }
        public int status { get; set; }
    }
}

public class CreateCustomer
{
    public class Data
    {
        public string customer_id_type { get; set; }
        public string state_desc { get; set; }
        public string name { get; set; }
        public string otp { get; set; }
        public string state { get; set; }
        public string customer_id { get; set; }
        public string list_specific_id { get; set; }
    }
    public class RootObject
    {
        public int response_status_id { get; set; }
        public Data data { get; set; }
        public int response_type_id { get; set; }
        public string message { get; set; }
        public int status { get; set; }
    }
}

public class verifyCustomer
{
    public class Data
    {
        public string state { get; set; }
        public string customer_id_type { get; set; }
        public string customer_id { get; set; }
    }

    public class RootObject
    {
        public string message { get; set; }
        public int response_type_id { get; set; }
        public int response_status_id { get; set; }
        public int status { get; set; }
        public Data data { get; set; }
        
    }
}
public class resendOTP
{
    public class Data
    {
        public string otp { get; set; }
    }

    public class RootObject
    {
        public string message { get; set; }
        public int response_type_id { get; set; }
        public int response_status_id { get; set; }
        public int status { get; set; }
        public Data data { get; set; }
    }
}


public class GetBeneficiaryList
{
    public class three
    {
        public int pipe { get; set; }
        public int status { get; set; }
    }

    public class Pipes
    {
        public three three { get; set; }
    }

    public class RecipientList
    {
        public int channel_absolute { get; set; }
        public int available_channel { get; set; }
        public string account_type { get; set; }
        public int ifsc_status { get; set; }
        public string is_self_account { get; set; }
        public int channel { get; set; }
        public int is_imps_scheduled { get; set; }
        public string recipient_id_type { get; set; }
        public string imps_inactive_reason { get; set; }
        public int allowed_channel { get; set; }
        public int is_verified { get; set; }
        public string bank { get; set; }
        public string is_otp_required { get; set; }
        public string recipient_mobile { get; set; }
        public string recipient_name { get; set; }
        public string ifsc { get; set; }
        public string account { get; set; }
        public Pipes pipes { get; set; }
        public string recipient_id { get; set; }
        public int is_rblbc_recipient { get; set; }
        public string recipient_info { get; set; }
    }

    public class Data
    {
        public int pan_required { get; set; }
        public List<RecipientList> recipient_list { get; set; }
        public int remaining_limit_before_pan_required { get; set; }
    }

    public class RootObject
    {
        public int response_status_id { get; set; }
        public Data data { get; set; }
        public int response_type_id { get; set; }
        public string message { get; set; }
        public string status { get; set; }
        public string refundable { get; set; }
        public string totaldebit { get; set; }
        public string service_charge { get; set; }
        public string amount { get; set; }
    }
}

public class GetBaneficiaryDesc
{
    public class Three
    {
        public int pipe { get; set; }
        public int status { get; set; }
    }

    public class Pipes
    {
        public Three three { get; set; }
    }

    public class Data
    {
        public string name { get; set; }
        public string recipient_id_type { get; set; }
        public string ifsc { get; set; }
        public string is_verified { get; set; }
        public string account { get; set; }
        public Pipes pipes { get; set; }
        public int recipient_id { get; set; }
    }

    public class RootObject
    {
        public int response_status_id { get; set; }
        public Data data { get; set; }
        public int response_type_id { get; set; }
        public string message { get; set; }
        public int status { get; set; }
    }
}

public class AddBeneficiary
{
    public class Data
    {
        public string recipient_id_type { get; set; }
        public int recipient_id { get; set; }
        public string recipient_mobile { get; set; }
        public string customer_id { get; set; }
        public string is_self_account { get; set; }
        public List<CustDataList> custdata_list { get; set; }
    }

    public class CustDataList
    {
        public string recipient_name { get; set; }
        public string account { get; set; }
        public string aadhar { get; set; }
        public string ifsc { get; set; }
        public string bank { get; set; }
    }

    public class RootObject
    {
        public string message { get; set; }
        public int response_type_id { get; set; }
        public int response_status_id { get; set; }
        public int status { get; set; }
        public Data data { get; set; }
    }
}

public class findprovider
{
    public class Rootobject
    {
        public string providerid { get; set; }
        public int providerimg { get; set; }
    }
}

public class SendMoney
{
    public class Rootobject
    {
        public string message { get; set; }
        public int response_type_id { get; set; }
        public int response_status_id { get; set; }
        public int status { get; set; }
        public Data data { get; set; }
    }

    public class Data
    {
        public DateTime timestamp { get; set; }
        public string tx_status { get; set; }
        public string txstatus_desc { get; set; }
        public string debit_user_id { get; set; }
        public string balance { get; set; }
        public string fee { get; set; }
        public string amount { get; set; }
        public string state { get; set; }
        public string recipient_id { get; set; }
        public string service_tax { get; set; }
        public string transaction_id { get; set; }
        public string customer_id { get; set; }
        public string channel { get; set; }
        public string currency { get; set; }
        public long client_ref_id { get; set; }
    }
}

public class verifyAccount
{
    public class Data
    {
        public string account { get; set; }
        public string bank { get; set; }
        public string recipient_name { get; set; }
        public string is_name_editable { get; set; }
        public string tid { get; set; }
        public double amount { get; set; }
        public double fee { get; set; }
        public string is_ifsc_required { get; set; }
        public string ifsc { get; set; }
        public string aadhar { get; set; }
    }

    public class RootObject
    {
        public string message { get; set; }
        public int response_type_id { get; set; }
        public int response_status_id { get; set; }
        public int status { get; set; }
        public Data data { get; set; }
    }

}

public class GetResendRefundOtp
{
    public class Data
    {
        public string tid { get; set; }
        public string otp { get; set; }
    }

    public class RootObject
    {
        public string message { get; set; }
        public int response_type_id { get; set; }
        public int response_status_id { get; set; }
        public int status { get; set; }
        public Data data { get; set; }
    }
}
public class Refund
{
    public class Data
    {
        public string refunded_amount { get; set; }
        public DateTime timestamp { get; set; }
        public string fee { get; set; }
        public string amount { get; set; }
        public string state { get; set; }
        public string service_tax { get; set; }
        public string tid { get; set; }
        public int client_ref_id { get; set; }
        public string refund_tid { get; set; }
    }

    public class RootObject
    {
        public string message { get; set; }
        public int response_type_id { get; set; }
        public int response_status_id { get; set; }
        public int status { get; set; }
        public Data data { get; set; }
    }
}

public class verifyPanCard
{
    public class Data
    {
        public string pan_number { get; set; }
        public string last_name { get; set; }
        public string middle_name { get; set; }
        public string title { get; set; }
        public string first_name { get; set; }
    }

    public class RootObject
    {
        public int response_status_id { get; set; }
        public Data data { get; set; }
        public int response_type_id { get; set; }
        public string message { get; set; }
        public int status { get; set; }
    }
}

public class DeleteBene
{
    public int response_status_id { get; set; }
    public int response_type_id { get; set; }
    public string message { get; set; }
    public int status { get; set; }
}


// multiDMT entity Start

public class MultiresendOTP
{

    public string id { get; set; }
    public string desc { get; set; }
    public string Error { get; set; }


}
public class MultiSendmoney
{    
    public bool status { get; set; }
    public int response_code { get; set; }
    public string message { get; set; }
    public string tid { get; set; }
    public string rrnid { get; set; }
}

public class GetCharges
{
    public class RootObject
    {
        public int status { get; set; }
        public string refundable { get; set; }
        public string totaldebit { get; set; }
        public string service_charge { get; set; }
        public string amount { get; set; }
    }
}

public class MultiVerifyOtp
{
    public class routes
    {
        public string routeid { get; set; }
        public string limit { get; set; }
        public string isuserexists { get; set; }
    }
    public class RootObject
    {
        public string message { get; set; }
        public string status { get; set; }
        public string mobile { get; set; }
        public routes data { get; set; }
    }
}

public class UvaLimit
{
    public class Route
    {
        public string routeid { get; set; }
        public string limit { get; set; }
        public string OtpLength { get; set; }
        public string RouteName { get; set; }
        public string isuserexists { get; set; }
        public int IsTransferOn { get; set; }
    }

    public class Root
    {
        public string status { get; set; }
        public string message { get; set; }
        public string name { get; set; }
        public string mobile { get; set; }
        public List<Route> routes { get; set; }
    }
}