﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MySql.Data.MySqlClient;
using System.Data;
using System.Web.UI.WebControls;

/// <summary>
/// Summary description for AdminProperty
/// </summary>
public class AdminProperty
{

    private string _name;
    public string adminName { get { return _name; } set { _name = value; } }

    private string _loginid;
    public string adminLoginId { get { return _loginid; } set { _loginid = value; } }

    private string _pwd;
    public string adminPassword { get { return _pwd; } set { _pwd = value; } }

    private string _date;
    public string LoginDate { get { return _date; } set { _date = value; } }

    public string UserTypeStr { get; set; }
    public string UserTypeStrDmt { get; set; }
    public string UserTypeStrId { get; set; }
    public string ID { get; set; }
    public string Status { get; set; }
    public string marqueetxt { get; set; }
    public string Error { get; set; }
    public string ChannelID { get; set; }
    public string SalesPerson { get; set; }
    public string templateID { get; set; }
    public string transdate  { get; set; }

    private string _sId;
    public string SrvcID { get { return _sId; } set { _sId = value; } }

    private string _pdrId;
    public string PdrID { get { return _pdrId; } set { _pdrId = value; } }

    private string _trnsId;
    public string TrnsID { get { return _trnsId; } set { _trnsId = value; } }

    private string _sname;
    public string SrvcName { get { return _sname; } set { _sname = value; } }

    private string _salias;
    public string SrvcAlias { get { return _salias; } set { _salias = value; } }

    private string _modifyby;
    public string ModifyBy { get { return _modifyby; } set { _modifyby = value; } }

    private string _pdr_name;
    public string PdrName { get { return _pdr_name; } set { _pdr_name = value; } }

    private string _pdr_alias;
    public string PdrAlias { get { return _pdr_alias; } set { _pdr_alias = value; } }

    private string _fk_serviceId;
    public string FkSId { get { return _fk_serviceId; } set { _fk_serviceId = value; } }

    private string _pdr_type;
    public string PdrType { get { return _pdr_type; } set { _pdr_type = value; } }

    private string _createby;
    public string PdrCreatedBy { get { return _createby; } set { _createby = value; } }

    private string _trns_name;
    public string TrnsName { get { return _trns_name; } set { _trns_name = value; } }

    private string _trans_alias;
    public string TrnsAlias { get { return _trans_alias; } set { _trans_alias = value; } }

    private string _trns_createby;
    public string TrnsCreatedBy { get { return _trns_createby; } set { _trns_createby = value; } }

    private string _userId;
    public string UserID { get { return _userId; } set { _userId = value; } }

    private string _amount;
    public string Amount { get { return _amount; } set { _amount = value; } }

    private string _remark;
    public string Remark { get { return _remark; } set { _remark = value; } }

    private string _addBy;
    public string ADDBY { get { return _addBy; } set { _addBy = value; } }

    private string _type;
    public string TYPE { get { return _type; } set { _type = value; } }

    public string fromDate { get; set; }
    public string toDate { get; set; }
    public string bankid { get; set; }
    public string OldTariffID { get; set; }
    private string _transactionid;
    public string TxnID { get { return _transactionid; } set { _transactionid = value; } }

    private string _tfid;
    public string TarifID { get { return _tfid; } set { _tfid = value; } }

    private string _tfname;
    public string TfName { get { return _tfname; } set { _tfname = value; } }

    private string _tfalias;
    public string TfAlias { get { return _tfalias; } set { _tfalias = value; } }

    private string _apiid;
    public string ApiID { get { return _apiid; } set { _apiid = value; } }

    private string _apiname;
    public string ApiName { get { return _apiname; } set { _apiname = value; } }

    private string _apicompny;
    public string ApiCompny { get { return _apicompny; } set { _apicompny = value; } }

    private string _apikey;
    public string ApiKey { get { return _apikey; } set { _apikey = value; } }

    private string _apiurl;
    public string ApiUrl { get { return _apiurl; } set { _apiurl = value; } }

    private string _apipwd;
    internal object payMode;

    public string ApiPwd { get { return _apipwd; } set { _apipwd = value; } }



    public MySqlDataReader DataReader { get; set; }
    public DataTable dt { get; set; }
    public DataSet DataSet { get; set; }
    public MySqlCommand cmd { get; set; }



    public int Result { get; set; }
    public string Query { get; set; }
    public string IpAddress { get; set; }
  

    public class Recharge
    {
        public int Result { get; set; }
        public string Provider { get; set; }
        public string Loginid { get; set; }
        public string Mobile { get; set; }
        public decimal Amount { get; set; }
        public string transType { get; set; }
        public string service { get; set; }
    }
    // DMT PROPERTY
    public string UserName { get; set; }

    public string MobileNumber { get; set; }

    public string EKOURL
    {
        get { return "http://dmrv1.cityrecharge.in/dmt_payes.aspx"; }
    }


    public string MutliUrl
    {
        get { return "http://dmrv1.cityrecharge.in/multidmt.aspx"; }
    }

	public string MutliUrlTest
    {
        get { return "http://dmrv1.cityrecharge.in/multidmt.aspx"; }
       
    }
    public string DmtBankIT
    {
        get { return "http://dmrv2.cityrecharge.in/multidmt.aspx"; }
    }
    public string DmtPaytmURL
    {
        get { return "http://dmrv1.cityrecharge.in/multidmt.aspx"; }
    }
    public string findprovider
    {
        get { return "http://apiv1.cityrecharge.in/recApiFinal/apiget.aspx?method=getopbymobile&mobile="; }
    }

    public string APIURL
    {
        get { return "http://api.payimps.in/recApiFinal/service.aspx"; }
    }

    public string APIURL1
    {
        get { return "http://api.payimps.in/recApiFinal/service.aspx"; }
    }

    public string otp { get; set; }

    public string ifscCode { get; set; }
    public string branch { get; set; }

    public string accountNumber { get; set; }

    public string bankId { get; set; }
    public int Count { get; set; }
    public string beneficryName { get; set; }
    public string Password { get;  set; }
    public string Tpin { get;  set; }
    public string Description { get;  set; }
    public string RemitterId { get; set; }
    public string Response { get; set; }
    public string DocType { get; set; }
    public string DocFront { get; set; }
    public string DocBack { get; set; }
    public string SelfPhoto { get; set; }
    public string GSTN { get; set; }
    public string OfficialName { get; set; }
    public string OfficeAddress { get; set; }
    public string AuthorisedName { get; set; }
    public string State { get; set; }
    public string City { get; set; }
    public string statecode { get; set; }
    public string pincode { get; set; }
    public string AdhaarNoFront { get; set; }
    public string AdhaarNoBack { get; set; }
    public string PancardFront { get; set; }
    public string ProfilePhoto { get; set; }
    public string PanNumber { get; set; }
    public string AdhaarNumber { get; set; }
    public string ViewName { get; set; }
    public string DateFormat { get; set; }

    public string Route { get; set; }
    public string MPin { get; set; }


    public string ExceptionMessage { get; set; }
    public byte[] PostData { get; set; }
    public string FileName { get; internal set; }
    public string FinalResponse { get; set; }
    public object ORDERID { get; set; }
    public string MID { get; set; }
    public string TransId { get; set; }
    public string TxnAmount { get; set; }
    public string PaytmentMode { get; set; }
    public string Currency { get; set; }
    public string TransDate { get; set; }
    public string RespCode { get; set; }
    public string RespMsg { get; set; }
    public string BankTransId { get; set; }
    public string BankName { get; set; }
    public string CheckSumHash { get; set; }
    public string ustype { get; set; }



    //----------------------------------------------------------------Distributor-----------------------------------------
    public string checkmobile { get; set; }

    public string retailerloginid { get; set; }

    public string retailerpassword { get; set; }

    public string retaileremail { get; set; }

    public string retailertype { get; set; }

    public string retailercretedby { get; set; }

    public string retailershopname { get; set; }

    public string retailershoppin { get; set; }

    public string retailershopaddress { get; set; }
    
    public string retaileraadhar { get; set; }

    public string retailerpancard { get; set; }

    public string retailergst { get; set; }

    public string retailername { get; set; }

    public string retailerid { get; set; }

    public string retpkid { get; set; }

    public string distripkid { get; set; }

    public string amount { get; set; }

    public string ipaddress { get; set; }

    public string usertype { get; set; }

    public string comment { get; set; }

    public string retlpkid { get; set; }

    public string distrilpkid { get; set; }

    public string lamount { get; set; }

    public string lipaddress { get; set; }

    public string lusertype { get; set; }

    public string lcomment { get; set; }

    public string load { get; set; }
    public string shopnames { get; set; }
    public string payModen;
    public string payslip;
    public string menupkid;

    public string paytype { get; set; }
    public string Amountn { get; set; }
    public string Priority { get; set; }
    public string UTRNO { get; set; }
    public string Mobile { get; set; }
    public string Adhaarcard { get; set; }
    public string PidData { get; set; }
    public string BankId { get; set; }
    public double AEPSAmount { get; set; }
    public string ServiceType { get; set; }
    public string transctnid { get; set; }
    public string SuperCNFPkID { get; set; }
    public string rtlid { get; set; }
    public string bankcode { get; set; }
    public string OpCode { get; set; }
    public string udurpass { get; set; }
    public object paydate { get; set; }
    public string Role { get; set; }
    public string Loadid { get; set; }

    public string RoleName { get; set; }
    public string RoleMenu { get; set; }
    public string RoleSubMenu { get; set; }
    public string RoleDesc { get; set; }
    public string RoleCreatedBy { get; set; }
    public string OfferPkID { get; set; }
    public string UserType { get; set; }
    public string Month { get; set; }
    public string Latitude { get; set; }
    public string Longitude { get; set; }
    public string BrowserId { get; set; }
    public string RetailCommission { get; set; }
    public string rAmount { get; set; }
    public string utrno { get; set; }
    public string bankname { get; set; }
    public string paymode { get; set; }
    public string rcvdate { get; set; }
    public string uploadpic { get; set; }
    public string APICommission { get; set; }
    public string ADMINCommission { get; set; }
    public string DistCommission { get; set; }
    public string CNFCommission { get; set; }
    public string pktkrid { get; set; }
    public string FullName { get; set; }
    public object TariffName { get;  set; }
    public object TariffAlias { get;  set; }
    public string providerlist { get; set; }
    public string api3 { get; set; }
    public string username { get; set; }
    public object aepstatus { get; set; }
    public object upkid { get; set; }
}