﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for RechargeEntity
/// </summary>
public class RechargeEntity
{
    public RechargeEntity()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    
}

public class LastSuccessTransaction
{

    public class LastTransaction
    {
        public string Image { get; set; }
        public string Provider { get; set; }
        public string Service { get; set; }
        public string Mobile { get; set; }
        public string Amount { get; set; }
        public string Status { get; set; }
        public string TransactionID { get; set; }
        public string Date { get; set; }
        public string Description { get; set; }
        public string AfterBalance { get; set; }
    }

    public class Detail
    {
        public string UserId { get; set; }
        public List<LastTransaction> records { get; set; }
        public string Operator { get; set; }
    }
}


public class FetchRequest
{
    public string mobile { get; set; }
    public string provider { get; set; }
    public string loginid { get; set; }
    public decimal amount { get; set; }
    public string ttype { get; set; }
    public string Service { get; set; }
    public string MplanID { get; set; }
}

public class BBPSRecharge
{
    public string AccountId { get; set; }
    public string Provider { get; set; }
    public string Loginid { get; set; }
    public decimal Amount { get; set; }
    public string transType { get; set; }
    public string service { get; set; }
    public string ApiType { get; set; }
    public string Mobile { get; set; }
}

public class MobiFetchBillResponse
{
    public class Datum
    {
        public string billAmount { get; set; }
        public string billnetamount { get; set; }
        public string billdate { get; set; }
        public string dueDate { get; set; }
        public bool acceptPayment { get; set; }
        public bool acceptPartPay { get; set; }
        public string cellNumber { get; set; }
        public string userName { get; set; }
        public string Message { get; set; }
    }

    public class Root
    {
        public bool success { get; set; }
        public List<Datum> data { get; set; }
    }

}

public class GetLatestOffers
{
    public class LatestRoffer
    {
        public string rs { get; set; }
        public string desc { get; set; }
    }

    public class Roffer
    {
        public string tel { get; set; }
        public object _operator { get; set; }
        public List<LatestRoffer> records { get; set; }
        public int status { get; set; }
        public double time { get; set; }
    }
}

public class OfferRequest
{
    public string Mobile { get; set; }
    public string Operator { get; set; }
    public string LoginId { get; set; }
}

public class PlanRequest
{
    public string Mobile { get; set; }
    public string Operator { get; set; }
    public string LoginId { get; set; }
}

public class RechargeResponse
{
    public string Id { get; set; }
    public string Result { get; set; }
}

public class GetOperator
{
    public string Result { get; set; }
}

public class Recharge
{
    public string Mobile { get; set; }
    public string Provider { get; set; }
    public string Loginid { get; set; }

    public decimal Amount { get; set; }
    public string transType { get; set; }
    public string service { get; set; }
}


public class Record
{
    public string MonthlyRecharge { get; set; }
    public string Balance { get; set; }
    public string customerName { get; set; }
    public string status { get; set; }
    public string NextRechargeDate { get; set; }
    public string lastrechargedate { get; set; }
    public int lastrechargeamount { get; set; }
    public string planname { get; set; }
}

public class Userdetail
{
    public string tel { get; set; }
    public object _operator { get; set; }
    public List<Record> records { get; set; }
    public int status { get; set; }
}

public class Rs
{
    public object MONTHS { get; set; }
}

public class Plan
{
    public Rs rs { get; set; }
    public string desc { get; set; }
    public string plan_name { get; set; }
    public string last_update { get; set; }
}

public class Records
{
    public List<Plan> Plan { get; set; }
    public object AddOnPack { get; set; }
}

public class DthPlans
{
    public Records records { get; set; }
    public int status { get; set; }
}
// Amar -- News Entity
public class Source
{
    public string id { get; set; }
    public string name { get; set; }
}
public class Article
{
    public Source source { get; set; }
    public string author { get; set; }
    public string title { get; set; }
    public string description { get; set; }
    public string url { get; set; }
    public string urlToImage { get; set; }
    public DateTime publishedAt { get; set; }
    public string content { get; set; }
}

public class RootObjectNews
{
    public string status { get; set; }
    public int totalResults { get; set; }
    public List<Article> articles { get; set; }
}
/// <summary>
/// /////////////////////////
/// </summary>
public class RootObject
{
    public Userdetail Userdetail { get; set; }
    public DthPlans DthPlans { get; set; }
}

public class DthOfferRequest
{
    public string Mobile { get; set; }
    public string Operator { get; set; }
    public string LoginId { get; set; }
}

public class ServicesApi
{
    public string Id { get; set; }
    public string Result { get; set; }
}

public class ServicesDatas
{
    public string mobile { get; set; }
    public string provider { get; set; }
    public string loginid { get; set; }
    public decimal amount { get; set; }
    public string ttype { get; set; }
    public string Service { get; set; }
}
