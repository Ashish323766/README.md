﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using MySql.Data.MySqlClient;
using System.Data.Odbc;
using System.Configuration;
using BussinessLogic;
using System.Net;
using System.IO;
using System.Text;
using DistributorLogic;
using System.Net.Mail;
using System.Web.Services;
using Newtonsoft.Json.Linq;
using RestSharp;

public partial class pages_addmerchantwithoutonboard : System.Web.UI.Page
{
	DBusinessLogics blog = new DBusinessLogics();
	AdminProperty objProp = new AdminProperty();
	protected void Page_Load(object sender, EventArgs e)
    {				
								
									
		diverr.Visible = false;
		if(!IsPostBack)
		{
			if (Session["merchMobile"] != null && HttpContext.Current.Session["UserId"]!=null)
			{
				txtmobiledata.Value = Session["merchMobile"].ToString();

				userlist("1");
				
			}
			else
			{
				if (HttpContext.Current.Session["UserId"] == null)
				{
					Response.RedirectToRoute("signin");
				}
				else
				{
					Response.Redirect("checkmerchant.aspx");
				}
			}
		}


	}

	

	public void userlist(string usertype)
	{
		objProp.usertype = usertype;
		objProp.Query = @"SELECT `pk_user_id`,concat(us_shop_name,'|',us_code,'|',us_loginid) as 'UserData' FROM `aks_user_login` WHERE us_type='" + objProp.usertype + "'";
		objProp.DataSet = blog.getFM(objProp);
		ddlparentuser.DataSource = objProp.DataSet;
		ddlparentuser.DataTextField = "UserData";
		ddlparentuser.DataValueField = "pk_user_id";
		ddlparentuser.DataBind();
		ddlparentuser.Items.Insert(0, "Choose Parent Merchant");
	}


	string usertypes;
	protected void ddlusertype_SelectedIndexChanged(object sender, EventArgs e)
	{
		try
		{
			string type = "0";
			if (ddlusertype.SelectedValue == "4")
			{
				type = "1";
			}
			else if (ddlusertype.SelectedValue == "3")
			{
				type = "4";
			}
			else if (ddlusertype.SelectedValue == "2")
			{
				type = "3";
			}
			objProp.usertype = type;
			objProp.Query = @"SELECT `pk_user_id`,concat(us_shop_name,'|',us_code,'|',us_loginid) as 'UserData' FROM `aks_user_login` WHERE us_type='" + objProp.usertype + "'";
			objProp.DataSet = blog.getFM(objProp);
			ddlparentuser.DataSource = objProp.DataSet;
			ddlparentuser.DataTextField = "UserData";
			ddlparentuser.DataValueField = "pk_user_id";
			ddlparentuser.DataBind();
		}
		catch (Exception ea)
		{
			ea.ToString();
		}
	}

	public void getServicec()
	{
		try
		{
			if (txtmobiledata.Value.Length > 9)
			{
				objProp.checkmobile = txtmobiledata.Value;
				if (objProp.checkmobile != "")
				{
					objProp.checkmobile = " and  us_loginid='" + objProp.checkmobile + "'";
				}
				else { objProp.checkmobile = ""; }

				objProp.Query = @"SELECT `us_loginid`,us_name,us_code FROM `aks_user_login` WHERE us_loginid is not null " + objProp.checkmobile + "";
				blog.checkmobile(objProp);

				if (objProp.DataSet.Tables[0].Rows.Count > 0)
				{
					diverr.Visible = true;
					lblmessgae.InnerHtml = "This Mobile Number Already Exists With " + objProp.DataSet.Tables[0].Rows[0]["us_name"].ToString() + " ( " + objProp.DataSet.Tables[0].Rows[0]["us_code"].ToString() + " )";
				}
				else
				{
					diverr.Visible = false;
					
					//checknumber.Visible = false;
					//updateDisProfile.Visible = true;
					//lblnewmobileno.InnerHtml = txtmobiledata.Value;
					//txtmobilenumber.Value = txtmobiledata.Value;
					//
					//diverror.Visible = false;
					//divsuccess.Visible = false;
				}
			}
			else
			{
				ClientScript.RegisterStartupScript(this.GetType(), "Alert", "successalert('Oops','Please Check Number Length!','error');", true);
			}
		}
		catch (Exception ea)
		{

		}
	}

	public void btncheckretailer_Click(object sender, EventArgs e)
	{
		try
		{
			if (txtfullname.Value.Trim() != "" && txtshoppincode.Value.Trim() != "")
			{
				if (txtadhar.Value.Length == 12)
				{
					if (txtpancard.Value.Length == 10)
					{
						if (txtshoppincode.Value.Length == 6)
						{
							string validChars = "0123456789";
							var stringChars = new char[8];
							var random = new Random();
							for (int i = 0; i < stringChars.Length; i++) { stringChars[i] = validChars[random.Next(validChars.Length)]; }
							var finalString = new String(stringChars);

							string tpinChars = "1234567890";
							var tpinstringChars = new char[6];
							var tpinrandom = new Random();
							for (int i = 0; i < tpinstringChars.Length; i++) { tpinstringChars[i] = tpinChars[tpinrandom.Next(tpinChars.Length)]; }
							var tpinfinalString = new String(tpinstringChars);

							string mpinChars = "1234567890";
							var mpinstringChars = new char[4];
							var mpinrandom = new Random();
							for (int i = 0; i < mpinstringChars.Length; i++) { mpinstringChars[i] = mpinChars[mpinrandom.Next(mpinChars.Length)]; }

							objProp.MPin = new String(mpinstringChars);
							objProp.retailername = txtfullname.Value.Trim();
							objProp.retaileremail = txtemail.Value.Trim();
							//txtemailaddress.Value = txtemail.Value.Trim();
							string emailid = txtemail.Value.Trim();
							HttpContext.Current.Session["emailid"] = emailid;

							//txtpannumber.Value = txtpancard.Value.Trim();
							string pannumber = txtpancard.Value.Trim();

							HttpContext.Current.Session["pannumber"] = pannumber;

							//txtaadharnumber.Value = txtadhar.Value.Trim();
							string adharnumber = txtadhar.Value.Trim();

							HttpContext.Current.Session["adharnumber"] = adharnumber;

							objProp.retailershopaddress = txtaddress.Value;// txtshopaddress.Value.Trim();
							objProp.retailershopname = txtshopname.Value.Trim();
							objProp.retailershoppin = txtshoppincode.Value.Trim();
							objProp.retaileraadhar = txtadhar.Value.Trim();
							objProp.retailercretedby = ddlparentuser.SelectedValue;
							objProp.retailerpassword = finalString;
							objProp.retailertype = ddlusertype.SelectedValue;
							objProp.retailerloginid = txtmobiledata.Value.Trim();
							string usermobile = txtmobiledata.Value.Trim();
							HttpContext.Current.Session["usermobile"] = usermobile;

							objProp.retailerpancard = txtpancard.Value.ToString().ToUpper().Trim();
							objProp.retailergst = "NA";
							objProp.Tpin = tpinfinalString;
							objProp.SalesPerson = HttpContext.Current.Session["UserId"].ToString();
							var details = finalString + " " + "\r\nT-Pin:" + " " + tpinfinalString;
							objProp.DataSet = blog.createcnf(objProp);
							if (objProp.DataSet.Tables[0].Rows.Count > 0)
							{
								if (objProp.DataSet.Tables[0].Rows[0]["id"].ToString() == "Y")
								{
									HttpContext.Current.Session["merid"] = objProp.DataSet.Tables[0].Rows[0]["merid"].ToString();
									HttpContext.Current.Session["meruscode"] = objProp.DataSet.Tables[0].Rows[0]["uid"].ToString();
									
									objProp.TYPE = "transactional";
					              objProp.MobileNumber = objProp.retailerloginid;
					             objProp.Description = "Dear User," +"Your Simple Mudra account is ready!" +"User ID: " + objProp.MobileNumber +",Password: " + objProp.retailerpassword +",MPIN: " + objProp.MPin +",TPIN: " + objProp.Tpin +",Thank you for choosing Simple Mudra.";
					            objProp.templateID = "1107171541409323156";
					              postMethodForForgotPassword1(objProp);


                                 	
									diverr.Visible = true;
									diverr.Attributes.Add("class", "alert alert-success alert-dismissible bg-success text-white border-0 fade show");
									lblmessgae.InnerHtml = objProp.DataSet.Tables[0].Rows[0]["result"].ToString();

                                   txtaddress.Value="";
                                   txtshopname.Value="";
                                   txtshoppincode.Value="";
                                   txtadhar.Value="";
                                   //Response.Redirect("merchantonboard.aspx");
								}
								else
								{
									diverr.Visible = true;
									diverr.Attributes.Add("class", "alert alert-danger alert-dismissible bg-danger text-white border-0 fade show");
									lblmessgae.InnerHtml = objProp.DataSet.Tables[0].Rows[0]["result"].ToString();

								}

							}

							

						}
						else
						{
							diverr.Visible = true;
							diverr.Attributes.Add("class", "alert alert-danger alert-dismissible bg-danger text-white border-0 fade show");
							lblmessgae.InnerHtml = "Pincode should be 6 digits.";
						}
					}
					else
					{
						diverr.Visible = true;
						diverr.Attributes.Add("class", "alert alert-danger alert-dismissible bg-danger text-white border-0 fade show");
						lblmessgae.InnerHtml = "Pan Number should be 10 digits.";
					}
				}
				else
				{
					diverr.Visible = true;
					diverr.Attributes.Add("class", "alert alert-danger alert-dismissible bg-danger text-white border-0 fade show");
					lblmessgae.InnerHtml = "Aadhar Number should be 12 digits.";
				}

			}
			else
			{
				diverr.Visible = true;
				diverr.Attributes.Add("class", "alert alert-danger alert-dismissible bg-danger text-white border-0 fade show");
				lblmessgae.InnerHtml = "Please fill all mandetory fields!";
			}

		}
		catch (Exception ea)
		{
			diverr.Visible = true;
			diverr.Attributes.Add("class", "alert alert-danger alert-dismissible bg-danger text-white border-0 fade show");
			lblmessgae.InnerHtml = "Technical Issue, Please try after sometime.";
		}
	}
	
	public string postMethodForForgotPassword1(AdminProperty Prop)
	{
		 string url = "https://api.trustsignal.io/v1/sms?api_key=808b7316-c52d-4ff6-9e77-7af0974f458a";
            string responseString = string.Empty;
            try
            {
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                var client = new RestClient(url);
                client.Timeout = -1;
                var request = new RestRequest(Method.POST);
                request.AddHeader("Content-Type", "application/json");
                var body = @"{""sender_id"": ""SIMUDR"",""to"": [" + Prop.MobileNumber + @"],""route"": """ + Prop.TYPE + @""",""message"": """ + Prop.Description + @""", ""template_id"": """ + Prop.templateID + @"""}";
                LogWrite("Request "+body,"_MSG");
				request.AddParameter("application/json", body, ParameterType.RequestBody);
                IRestResponse response = client.Execute(request);
				LogWrite("Respone "+response.Content,"_MSG");
                responseString = response.Content;
		}
		catch (Exception ea)
		{
			LogWrite("Exception " + ea.ToString(), "_MSG");
			responseString = "N";
		}
		return responseString;
	}
	
	  public void LogWrite(string query, string infile)
        {
            System.IO.StreamWriter file = null;
            try
            {

                string FileName = "C:\\MUDRA\\Addmerchant\\" + System.DateTime.Now.ToString("dd-MMM-yyyy") + "_LOG_" + infile.ToUpper() + ".txt";
                file = new System.IO.StreamWriter(FileName, true);
                file.WriteLine(".................................." + System.DateTime.Now.ToString() + " IP ..........................>\r\n" + query);
                file.Close();
            }
            catch (Exception ex)
            { }
        }
}