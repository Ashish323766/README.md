﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using MySql.Data.MySqlClient;
using System.Data.Odbc;
using System.Configuration;
using BussinessLogic;
using System.Net;
using System.IO;
using System.Text;
using DistributorLogic;
using System.Net.Mail;
using System.Web.Services;
using Newtonsoft.Json.Linq;

public partial class pages_DistributorView : System.Web.UI.Page
{
	SPBusinessLogics blog = new SPBusinessLogics();
	AdminProperty objProp = new AdminProperty();
	protected void Page_Load(object sender, EventArgs e)
    {
		//diverr.Visible = false;
		//if(!IsPostBack)			
			//{
		getServicec();
			//}
	}

	public void getServicec()
	{
		try
		{
			if(HttpContext.Current.Session["UserId"]!=null)
			{
				string Pkid =  HttpContext.Current.Session["UserId"].ToString() ;
				objProp.UserID = Pkid;
				objProp.usertype = "3";
				blog.ReatilerView(objProp);
				if (objProp.DataSet.Tables[0].Rows.Count > 0)
				{
					Repeater1.DataSource = objProp.DataSet;
					Repeater1.DataBind();
				}
				else
				{

				}
			}
		}
		catch (Exception ea)
		{

		}
	}

	
}