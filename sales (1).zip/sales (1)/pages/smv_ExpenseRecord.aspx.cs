﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DistributorLogic;
using BussinessLogic;
using MySql.Data.MySqlClient;
using System.Configuration;
using System.Data;

public partial class pages_smv_ExpenseRecord : System.Web.UI.Page
{
    DataTable dt = new DataTable();
    BusinessLogics blog = new BusinessLogics();
    AdminProperty objProp = new AdminProperty();
    protected void Page_Load(object sender, EventArgs e)
    {
        error_message.Visible = false;
        data();
    }

    public void data()
    {
        DataTable dTable = monthdata();
        if (dTable.Rows.Count > 0)
        {
            Repeater1.DataSource = dTable;
            Repeater1.DataBind();
        }
        else
        {
            error_message.Visible = true;
            error_message.InnerText = "Data not found";
        }
    }

    public static DataTable monthdata()
    {
        try
        {

            DataSet dSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sm_expenses_record");
            return dSet.Tables[0];
        }
        catch (Exception ea) { throw; }
    }

    
}