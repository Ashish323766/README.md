﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BussinessLogic;
using MySql.Data.MySqlClient;
using System.Configuration;
using System.Data;


public partial class pages_sm_leave_record : System.Web.UI.Page
{
    DataTable dt = new DataTable();
    BusinessLogics blog = new BusinessLogics();
    AdminProperty objProp = new AdminProperty();
    protected void Page_Load(object sender, EventArgs e)
    {
        error_message.Visible = false;
        data();
    }

    public void data()
    {
        string lbluscode = HttpContext.Current.Session["UserCode"].ToString();
        DataTable dTable = leavedate(lbluscode);
        if (dTable.Rows.Count > 0)
        {
            Repeater1.DataSource = dTable;
            Repeater1.DataBind();
        }
        else
        {
            error_message.Visible = true;
            error_message.InnerText = "Data not found";
        }
    }

    public static DataTable leavedate(string lbluscode)
    {
        try
        {
            MySqlParameter[] prm = new MySqlParameter[1];
            prm[0] = new MySqlParameter("_uscode", lbluscode);
            DataSet dSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sm_leave_records", prm);
            return dSet.Tables[0];

        }
        catch (Exception ea)
        { throw; }
    }


}