﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using MySql.Data.MySqlClient;
using System.Data.Odbc;
using System.Configuration;
using BussinessLogic;
using System.Net;
using System.IO;
using System.Text;
using DistributorLogic;
using System.Net.Mail;
using System.Web.Services;
using Newtonsoft.Json.Linq;

public partial class pages_retusereport : System.Web.UI.Page
{
	 SPBusinessLogics blog = new SPBusinessLogics();
	AdminProperty objProp = new AdminProperty();
	decimal Totalsaels;
	protected void Page_Load(object sender, EventArgs e)
    {
		diverr.Visible = false;
		if(HttpContext.Current.Session["UserId"]!=null)
		{
			if (txtdate.Text == "" && txtfromdate.Text == "")
			{
				txtfromdate.Text = DateTime.Today.ToString("yyyy-MM-dd");
				txtdate.Text = DateTime.Today.ToString("yyyy-MM-dd");
			}
			
		}
	}
 protected void btngetdata_Click(object sender, EventArgs e)
    {
        try
        {
            getServicec();
        }
        catch (Exception ea)
        { }
    }
	public void getServicec()
	{
		try
		{
			string Pkid = HttpContext.Current.Session["UserId"].ToString();
           // Authentication.GetUserDetailsByJsonObjectKey("Pkid", out Pkid);
            objProp.UserID = Pkid;
            if (txtdate.Text != "" && txtfromdate.Text !="")
            {
                objProp.fromDate = txtfromdate.Text;
                objProp.toDate = txtdate.Text;
            }else
            {
                objProp.fromDate = DateTime.Today.ToString("yyyy-MM-dd");
                objProp.toDate = DateTime.Today.ToString("yyyy-MM-dd");
            }

            objProp.Query = @"SELECT pk_user_id,CONCAT(us_code,'-',us_loginid,'-',us_name) AS 'uName',
ROUND((SELECT wl_balance FROM `aks_user_balance` a WHERE a.fk_user_id=pk_user_id),2) AS 'Balance',
ROUND(SUM(rch_amount),2) AS 'TOTAL_SALE',
ROUND(SUM(CASE rch_service WHEN 'DMT' THEN rch_amount ELSE 0 END),2) AS 'DMT',
ROUND(SUM(CASE rch_service WHEN 'DMT' THEN rch_com_distributer ELSE 0 END),2) AS 'DMT_COM',
ROUND(SUM(CASE rch_service WHEN 'MOBILE' THEN rch_amount WHEN 'DTH' THEN rch_amount ELSE 0 END),2) AS 'RECHARGE',
ROUND(SUM(CASE rch_service WHEN 'MOBILE' THEN rch_com_distributer  WHEN 'DTH' THEN rch_com_distributer ELSE 0 END),2) AS 'RECHARGE_COM',
ROUND(SUM(CASE rch_service WHEN 'CW' THEN rch_amount ELSE 0 END),2) AS 'AEPS',
ROUND(SUM(CASE rch_service WHEN 'CW' THEN rch_com_distributer ELSE 0 END),2) AS 'AEPS_COM',
ROUND(SUM(CASE rch_service WHEN 'ELECTRICITY' THEN rch_amount ELSE 0 END),2) AS 'BBPS',
ROUND(SUM(CASE rch_service WHEN 'ELECTRICITY' THEN rch_com_distributer ELSE 0 END),2) AS 'BBPS_COM'
FROM view_sale_report trans ,`aks_user_login` lg WHERE lg.pk_user_id=trans.rch_ret_id AND lg.us_type=2
AND lg.us_lvl_5_id='" + Pkid + "' AND  DATE(`Date`) BETWEEN '"+ objProp.fromDate + "' AND '" + objProp.toDate + "' GROUP BY rch_ret_id";

            blog.checkmobile(objProp);
            if (objProp.DataSet.Tables[0].Rows.Count > 0)
            {

                Repeater1.DataSource = objProp.DataSet;
                Repeater1.DataBind();
            }
            else
            {

            }
		}
		catch (Exception ea)
		{

		}
	}

	public void btncheckretailer_Click(object sender, EventArgs e)
	{
		getServicec();
	}
}