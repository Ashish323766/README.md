﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using MySql.Data.MySqlClient;
using System.Data.Odbc;
using System.Configuration;
using BussinessLogic;
using System.Net;
using System.IO;
using System.Text;
using DistributorLogic;
using System.Net.Mail;
using System.Web.Services;
using Newtonsoft.Json.Linq;

public partial class pages_merchantonboard : System.Web.UI.Page
{
    DBusinessLogics blog = new DBusinessLogics();
    AdminProperty objProp = new AdminProperty();
    protected void Page_Load(object sender, EventArgs e)
    {
        diverr.Visible = false;
        btnchkotp.Visible = false;
        divotp.Visible = false;
        if (!IsPostBack)
        {
            if (Session["merchMobile"] != null && HttpContext.Current.Session["adharnumber"] != null && HttpContext.Current.Session["pannumber"] != null && HttpContext.Current.Session["meruscode"] != null)
            {
                txtmobiledata.Value = HttpContext.Current.Session["usermobile"].ToString();
                txtpancard.Value = HttpContext.Current.Session["pannumber"].ToString();
                txtadhar.Value = HttpContext.Current.Session["adharnumber"].ToString();
                txtemail.Value = HttpContext.Current.Session["emailid"].ToString();

            }
            else
            {
                Response.Redirect("checkmerchant.aspx");
            }
        }
    }


    public void btncheckretailer_Click(object sender, EventArgs e)
    {
        signuponbd();
    }

    public void btncheckrotp_Click(object sender, EventArgs e)
    {
        validateinit();
    }


    //[WebMethod]
    public void signuponbd()
    {
        //SMJson myJson = new SMJson();
        //CommonDB objConn = new CommonDB();
        try
        {


            string usermobile = HttpContext.Current.Session["usermobile"].ToString();
            string pannumber = HttpContext.Current.Session["pannumber"].ToString();
            string adharnumber = HttpContext.Current.Session["adharnumber"].ToString();
            string emailid = HttpContext.Current.Session["emailid"].ToString();
            string userid = HttpContext.Current.Session["meruscode"].ToString();
            string account = "";
            string ifsc = "";


            if (!string.IsNullOrEmpty(emailid) && emailid != "string" && !string.IsNullOrEmpty(txtifsccode.Value) && txtifsccode.Value != "string" &&
                !string.IsNullOrEmpty(adharnumber) && adharnumber != "string" && !string.IsNullOrEmpty(txtaccountno.Value) && txtaccountno.Value != "string" && !string.IsNullOrEmpty(usermobile) && usermobile != "string" && !string.IsNullOrEmpty(pannumber) && pannumber != "string")
            {
                account = txtaccountno.Value;
                ifsc = txtifsccode.Value;

                string prms = "fetch=signupinitiatev1&mobileno=" + usermobile + "&panno=" + pannumber.ToUpper() + "&email=" + emailid + "&aadhar=" + adharnumber + "&lat=22.25689&long=77.24532&iAgree=Y&UserID=" + userid + "&accountNo=" + account + "&accountIfsc=" + ifsc.ToUpper();
                string jsonResponse = postMethodAll1("", prms);
                //string jsonResponse = "{\"statuscode\":\"TXN\",\"actcode\":null,\"status\":\"Transaction Successful\",\"data\":{\"aadhaar\":\"xxxxxxxx8823\",\"otpReferenceID\":\"ZDI4NDU0MTItODA4MC00OGZiLWI5ZDYtMGMxYjJmNDQ4MThh\",\"hash\":\"5PvLu8tvEPeOE6L/n07gdXHhiGIfP8g5HoEHrWKCCnar35mKYRpo/MD0hKVtUnvP75avK3LLd9/sHNWV174lHHiutFICVTdbW4KQ0QjoXITKIbqNaRRsQvnlpYJsZtu2hntQMP14dGVWtUe8LIZ9JNenV8wmxOPuf5epKCNUuzDUh+s/DbHjSqTUp8pAe0fdoziKgCGG6Ta6pQeRwNPPowUch/SsP9tdjvsFX8XTAmzQLJLOpC9bJNu+ZhHHnjTjKyjahXd6AGlWmE7VANeDLPrSCY1NwgCZqBDFMsFXrTI+DC89Y6HUWUj7NsYl9eJ4\"},\"timestamp\":\"2024-01-21 12:39:29\",\"ipay_uuid\":\"h0069b24bd42-7673-474b-911a-e1d4e396aaac-sRv8cEzgUdfJ\",\"orderid\":\"1240121123924HQZBK\",\"environment\":\"LIVE\"}";

                if (jsonResponse != "N" && jsonResponse != null)
                {
                    JObject jObjecttop = JObject.Parse(jsonResponse);
                    if (jObjecttop["status"].ToString().Contains("Successful") && jObjecttop["statuscode"].ToString().Contains("TXN"))
                    {

                        lblhash.Value = jObjecttop["data"]["hash"].ToString();
                        lblotpref.Value = jObjecttop["data"]["otpReferenceID"].ToString();
                        diverr.Visible = true;
                        btnchkotp.Visible = true;
                        divotp.Visible = true;
                        submit.Visible = false;
                        diverr.Attributes.Add("class", "alert alert-success alert-dismissible bg-success text-white border-0 fade show");
                        lblmessgae.InnerHtml = "OTP successfully send";

                    }
                    else if (jObjecttop["statuscode"].ToString().Contains("ERR"))
                    {
                        diverr.Visible = true;
                        diverr.Attributes.Add("class", "alert alert-danger alert-dismissible bg-danger text-white border-0 fade show");
                        lblmessgae.InnerHtml = jObjecttop["status"].ToString();
                    }
                    else
                    {
                        diverr.Visible = true;
                        diverr.Attributes.Add("class", "alert alert-danger alert-dismissible bg-danger text-white border-0 fade show");
                        lblmessgae.InnerHtml = "OTP not send";
                    }
                }
                else
                {
                    diverr.Visible = true;
                    diverr.Attributes.Add("class", "alert alert-danger alert-dismissible bg-danger text-white border-0 fade show");
                    lblmessgae.InnerHtml = "Invalid response. Please try later";
                }
                //return myJson.success("1");
            }
            else
            {
                diverr.Visible = true;
                diverr.Attributes.Add("class", "alert alert-danger alert-dismissible bg-danger text-white border-0 fade show");
                lblmessgae.InnerHtml = "Please enter all required details";
            }

        }
        catch (Exception ex)
        {
            diverr.Visible = true;
            diverr.Attributes.Add("class", "alert alert-danger alert-dismissible bg-danger text-white border-0 fade show");
            lblmessgae.InnerHtml = "Technical Issue. Please try after sometime" + ex.ToString();
        }
    }

    //[WebMethod]
    public void validateinit()
    {

        //SMJson myJson = new SMJson();
        //CommonDB objConn = new CommonDB();

        try
        {
            string tid = ""; string hash = ""; string otp = "";
            string userid = HttpContext.Current.Session["meruscode"].ToString();

            if (lblhash.Value != "" && lblotpref.Value != "")
            {
                tid = lblotpref.Value; hash = lblhash.Value;
                //otp = "738758";
                otp = txtvotp.Value;

                if (!string.IsNullOrEmpty(tid) && tid != "string" && !string.IsNullOrEmpty(hash) && hash != "string" &&
                    !string.IsNullOrEmpty(otp) && otp != "string")
                {
                    string prms = "fetch=validateinitiatev1&tid=" + tid + "&hashdata=" + hash + "&OTP=" + otp + "&UserID=" + userid;
                    string jsonResponse = postMethodAll1("", prms);
                    //string jsonResponse = "{\"statuscode\":\"TXN\",\"actcode\":null,\"status\":\"Transaction Successful\",\"data\":{\"outletId\":36158806,\"name\":\"SHEK FARID\",\"dateOfBirth\":\"2005-01-01\",\"gender\":\"M\",\"pincode\":\"781313\",\"state\":\"Assam\",\"districtName\":\"Barpeta\",\"address\":\"VILLROWMARI\",\"profilePic\":\"/9j/4AAQSkZJRgABAgAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCADIAKADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/WNeg9Mn6/1rwnV9Z1DXL5rq/uJZZD0yeFHoB2FV7mZ7u8eSRyxdySzdTz1qGVlLt5SnGeMnoKtaAKoU4BLZ9adKDDhgzY9aII2kcDIH1NSXsCxorq5IPHGSBTGJBJE5G9yD2OKkZGZshc57is8FmG5eo9KsQOW53kEeppAdj4W8can4alWMgXVqSN0TsQQPRT2/EGvbvDni/SvEtvmzkZZ1H7yCQYZf6H8K+b0KyMWDYZBz2/GtXRPEN1oOox3to/7xPlcDo69wRSYH00RxmmMOKz/AA7rlt4i0WDULbgOMMhOSjDqDWi3SpEMp4ximACpB2NACgcUuKKKQGZmng1CDUgPNWwJA1OFRg08GkA/3rxL4r+IPt2prpttIxjh4kwSAW9D2OPX3r2lj8p+lfNOuXDXet3s8vBaZzg9uaaHYwJY33qo69qDbToNwGfpV0RbplIHfNbNnp6Mvzgkk8ionVUdzSFJy2ObhLK4ZSVbGdr8Z+lXJDPKdxL+Ueo64rrF0C3u02ugCkcEDkfSsW8tZdKmaKT5xyOOuOxxUU68ajsiqlGUFcxWtsTlYwQT2pPsrI/KnB68VdhninlPm4yF+8O9WDLBhyj5K88nP5VtcxKsdoxid4w25cYamOZIWUSpwe4GMVG+qSQSERvgA9R3pr6p9qQRyYxkc4oA9E+GHiRrDxELGWUpb3I2lAfl39mx+n5V7nu3cj0r5LsJ3tdVgeJ9rRyqVbPvX0t4c1b+0LBN33wMGkwN3NPBwKjzmlU9qQiUGlpgNKTQBkg09c4qIGpFPNUBKKUGmbhShs0hjmPynnHHWvl3Urv7TqtzKDkPKzA+ozX1Ax44zXzNrdibPxTfWm3AjuHAH+zk4/TFHQa3HQKp2k+lbloQQKxURUAJOK2LFQQDvBB964K+up6FGyOmsJQFAB4rK8ZaV9t057u2BM8Pz5HXHf8AxrSs4igXH/1jWkq4yf7xrihNwldHTOClGzPG7GyuL242KuCBuIJxxVltDvVZwpAHYtxkV6fcWtrG3m+VGpVcA4AwKwdTuLSBNzSjIHXjFdixc5v3Ucv1aEV7zOGl0SZf4x7g1UfT7iFSSAcDPB6Vs3WrrLLiCPeoPJx1p8UsdyuQCDjlTXVGc/tHPKEL6GVpsTXF7DGOrMM17n4NvDFMImPWvGtBty+uIMcRlmPt/k16x4XG6/BFbNmB6krZANOBqKI/IB7VJSJHZpc8U0mjNAzKU04H1qMH2pwIpgSinJUQOO9SA0gHnmvGfiNaWCeLYLuzlhd5kZLhI2BKyL3YdiQcf8BPvXsea8d+IGmxWXioyRlQLlRcbVXG0nKt9ckFs+pNKTsi4K7ONa1a7mw7kRjoFqcaRLCC9tOQcdyRTJYp9jGDO72qc6Rb3VnbyRXaregMsqXKFgwYYyvBAI7d+4wQK53J330OnlVtri2moalAQss4dAcjBzXXWWpC4RcnnHesi7s7C30a1t4og1xCuGnzgtkkkYxyORg56D8oLJ2UHb26VyVkpao6aN46Mm1vUJXGxGIGfXpXOyWYitnvbiKeWBXAZu245IH9a07onzgHU8djWta3qyaU1hLElxbP95HUc856jBznPOaum+SOhNWLnI55bpHtpzFZN5UDbXZCrAdcHIPI46ioIkVphIg4NbAt1gtXtLeMRQO25lXPzH3J5P8AKofsyxr8qgD2q1UjfQiVOVveMuOI2t3dSK5QKMnacFs9q9d8CWpaJJGyTtHJ715itsJ9SQZxuQk/UdK9H8E6hKJUgGMbRn610wleVjlnG0bo9IBx0p4JIpgPA4p24VqYj6QgUm4GkLYoAygacGNQg81IDTAkDU/NRA08HtSGOLY5rzb4iwldYguXX5JLYRo3qyuxI/Jh+dej9RXm/wASrpjqFjbhMeVEZA56HecEfhsH51FT4TSn8RyFuAwwe1W0jVeTx+FZ0UoWU4PWtCOTzBkn6V51a6Z6VCziQ3JJXPan2gAIUdPWku0CQcdzgnPTNNtZbeG4SNplyTkjPNRq4mispjtRQHLbfwqC0OBuXIPfFW9Vu7IzhBIArcDIqrYbPtE0YfcoAPPY0op8moSa5y4G3nB5qvcHapHSrDABsA/jVS6cYIb060QXvCqvQoSHfdQgEgqC2R1ruPBDEX8WW5xj8a5C1tRL++3EMPl9sV0/hllttVhGcDPevSine55k2uWx68m7uc1JkAdKhjbcgIxjFSZ7VqYDw1RgFWJyTk55PSnZprNigDIBqQHAqAH8qeGqhk6txTwagU1IDQBJyKp6jZ2l5b7bu3inVPmUSIG2n1GelWqZJhkK9QaVgR4j4gRbbWZWiULGTwAMAUyGZQgwcmu08W+FPtFpNdWoLTJ8+wc7h3FeZCVk6HntXPVpcx00qvKbjzrIpVuVI5FRQtCYzEyr5Y9Rn9ayGmlC7lZeD/ESP6VdtRdy8rdwLjnByM1j7KyOlVOZlwJFArNBy56kZPH1qKG5VOCMHPPFJdLM8Ic6hCWzjaoOR+dZiqXcg3MjgdQABj8aFTvuEpuOxsPdDsao3E/mNjPHeqzMUPX9aLPbNfRws3U5I+nNXCkk7mNSo2rG9ZJttkGOTzXTaLol3NdRTBcIDnNYMYy6getep+Hl2WS8dq6UjkbNmAGOFVJ5AqbdUWaUHFUSS54qNjSbqYzc0gMhW96kB4qsjc1Ju4qwLKsKkV6qBqfnNIZZL01n4qHdikZuKAuNlwwI9a8g8d2MWnaik0KYM24uq/hziu91zxjpeis8TSi4u1/5d4jyDzwzdF5HPfnODXkOp6pcarqUl7duHlkALYGFQZwFA7Af/r71XJpcFLWwyCcSR8EEVcgsYJMFpJFH+y5FZU1nJgzWzbW6lexquurXUA2yRHI64rkcXL4WdSko/EdMdOscZw7EdmlYj8s1FKYYhhQoGOgHFc8NVu5TiOJufamSC/mH7w7FPbNSqcvtMp1Y9EW7rUFLFI8detWNFymoRySnBbIHtmqdlZANufnFTTEiUKhOSQAR65raNrqKMZXtzM73S7Y3F2gA4BzXqenR+TaqvtXgOj6xrVszGwllbYNz/uxJgDnuDgda7XS/itLG4j1KwiZd3MluxUqv+6c7j+Irb2b2Rg72u0eqhqcG4rltM8daBqW1RefZpWBPl3Q2Y5x977uTnoCTXSlsUmmtxXJC1RO2OaC3vUTtzUjMkN3qRWxVdW55p6tVgWVYU7dXM6v4w0rSAyecLi5GR5MJzgjPDHovIwe/tXE6/wCLNdnRS+6wgdjsSIlW45+ZvvZwR6Agg4ppDSbV0j0fV/E2laIGF5dL5o/5Yx/M54z07Z9TgVw+p+Ktb8RRSf2ds0vTV5eeRz5hQNjeQoL7M4BKKQDkE1xNnqC2102YhNDJE0bptBO1h1GRwwOCCO49M09NWuYbd7OHdHaurBFlfeU3AhiMAAkhmGSCRnjB5rVQSIbLt/ptro8EMVxJvup7QTxyRSrJGWE8iFQVyCpRVb2Ix3xWXPLF9khjTBYK7vj16Af+O5/GoAgjYkjORjNXrTbcafLb4iDRN53OAzLjDAEnsADjrxTktBJ9h1pIQoOaJIkeTcAAe4qG2JQBW5I4qaQ85rzJJqR3x1RMsGR9yoZoCAcjAHc0qySKPlbiq88kkhw7cUle43YfEQEIA4pkcZlnJLbVUgBuwc9Py5P/AAE0+COWeSO2t0LzSHaqr1zVueOOx0ssCrkh0hdc/vOcPKM87eAg7HDHAYMK6aUWte5hOSenYxluJopD5Ejxh1wdrEZHocfWnwwTSTJGi7nkYKoz1JPFQIpYFhnhatW8rxos0TlJo2DIwHII5BrsjFbnM5O1jYtv7Hml0xJZ2t4ghjuuNsjyEuwYEgoF5RMkjpkgc42tMutSsbhovDess8apHL9md1lRFYndk/dG07dzAD73UYrlr5I1vH2R+XBLiREJzsVgGUE+oBGam0yzF1d2FvG0kIupRazFHK78uufwwy/lTcSbnotp8QtQSW3hvtKS5M2WWWxc/PGGK7ljbJPKnuOOcV0lj4r0jUZfIW5+z3QIDW90vlSKx6Lg9T7DNeIjULxLu2ujN5jwIscW8Y2KowoG3BBHqCDnnOeabqF5PqF0biSKNMqFCRKQqgDHAycVm6aKUj2a7voNPtJbq5cJFGMsf0/MnArzPxB40vNSkeGGRre0OQI0OGcYx8x79+OnPfGat+MtZnu71rWKNJbKycNIFbmRhjdk9cDOMDpkk9scxqd1DqN1DNBCIo44whIGN5yTnGTgAEKBk4CgUQjbVg2Piv7pbdxaxxxMoDPOv+sPJHDHp97B24yOueaZBEZYbid5CZoCjjeAVK52ng9Tkpx6Zpti8dvfRmU7bdjslIGSFYYYj3wTT4Hayu/KuGMLAmGYkcopyr/jgmmqcU7lyrTkuVvQjuEiju3WDiIgOgJyVUgEAn1AOD71Fwy7WORTtreVDIVCqN0fuSDkn/x4D8Ki3Y9a0Mhy5BMbHI7VExaF9w496nDLIoDdqQoRkEbhSAkhkV0x3GB/n8qnB3cVSSIhiEztYY+np+uKvWFzDdBVJCSjggng+4rhxFO3vI66E7+6xhUj+HNRrGzOMg8nAxWssSlgDgir2mW9l/bMEVzP9ntpWRZ7gsEESEkEA+p7nsMnsSMKLTlqbVE1HQz7a1WIzmaXESJtmnjPKhh/q09XbkEcgDdnjdjL1W8kuh5rYXcAqIOiKBgKM84AGOck9SSSTXa/EOw8P6bJpq6I8aIY3822iuBKo5Uq+ckgtkjqchV6YrhYrc3f2gtIFMEW9U6l/mUYH0BJ/wCA16MF1OKUuiJBavBGFkXaxUNjPYgEfoRVZfkLDNaUzB7SznQlnMflysf76kgD8E8v86pTRhssK1My5Ntk0mykXAKb4iM8sQ24n8pAP+A1FBMyYdGYOrB0YHlWHBx79D/wGmWjE2V3CcALsmyfQHZtH1MgP/AaZEdr7SCVB5APUdx+INMRoazGo1OcxjCSHzo1x/A43r+hFUN5UnkjjNWb4sI7ctzLDugdv75Q8H6bWQD6VUmbKEj+LApNAJc3/wBotUjdJBcmWSWSbzeHDgZG3HfA79z68MjcAYIwDyKgZPKVG85JVIBBUngehz3oJ3DHT0qEyi25BH4U/UmEjxz4JE8YZixyXfo7H6sGNVFkLLk9Rwc1YmLtp1vIzZCu8SDPRRhv5uapCLU/7/7VKQwcyCdEHRY3ySf1jH41RUbn6cVetjG4hBLMZ7doXC85kBPlr+Yi/CqC8E0wHMm3kGmCR0bNO3HOCaMd6QEkU0bOobjkVTDrCj7kJkbG1wxBX1+tWo7OW5J8qF5MDJ2qTgVWuYHtAPNKMjdGRw2Prg8VMldajW+heh1Wa0fZcIZAOjA80+91hL0RosbIFJILHpn2/AVT3rcWiq3DqMKexqr5Z6VzulGMuZG3tZOPKy/Lujynyr+pNXtNaBbqQqzea8EkaJsBUs8TL1zxy3AxWdev+/wvUKqk++0Vc0VkfW7NnOIzdRkkdlDjj8q6Y7mTJYneXRgm3CW9xkn1Mq8D/wAgn86rAcY4q1ZgnS76I8KgjuGB7lW8sD/yMaoiT5iapkghEUhZslSrKR65HH64P4U3dg7z7CgksmMcVE6FYQ/JAOCP7vp+fP5VLkilCXY1bx0mlITP7y1hbAHLOsa7iT/32azCdsXOT8wq1YyK15YxHhHzA7H/AGmIJ/75cflVCaQbQo65Gad09ROLW5Wh+9k9CKep6j06UxT8mR160m7DexrNFPclEgLD16EVZQF7OVt3ypIoA92DZ/8AQRWa+4H0q/ppDzrbuI91wQqby2FbsTtPc8fjn60mJov2iXL2qC2LebDOGjCKSxZh1x7bB+dSXem/Zb6WGSRII1kKqZT8wHYlRlhkYPTvXQW+i7E8rU9YjhS4ARoYlWNXI6Y6DOQP4c1Ztz4a3Rx2NrJqNwRsbK7toXHzNuwAOgyPStUiDkxbReQZxHczxocSsqbFX0+bnv6gVCLvy1Cx28K4yNzLvLD3zkZ9wBXoev39lBoE0Fx5cbyxYSNefmHTA74OOa80LBhilJW2BakslzNMF3yu2OQGbgfT0qJhxTTx0oznGahjBJZbaKSOGQiKT78Z5Rvcj19+opkGJpVXJwWAI7ignBIpLfMd1vABwhP6VMkUmOMnm3hkHI3FufSpUOxRtOCBwa3l8HXUXho6486Y8veYQOQjcA59eQceh654rnwpPXpRFiZr3MqtrOsW0any3aZFHsr7v/ZKyjWohWPWJ5SQRLbzSjPfzIWI/wDQhWQD8xq2I09O02bUGwD5cKjLyEZCgdT71rDSrSPfFh2jZgWV3zjGcnjHQHH1J9qdp0oXSbZIowDKNxX1IYqOR6lMn/dFOuddt9LDwLGzsqh1Bx83PH5k7vwA9a5ZX5tD04KKgmzP1PSxFbf6KNhiYvt684GcH221z1/iO8mCH5BIQuPTPFbH/CTxvIyTQtHjGFJ3enf16/nWHNKss37sjavf+VawOWtZ7CbPkH0qLJBKt0PIoopmIjYHc1Exw2R0oooA3NKsItXmMskzRquPMVfvE+voM9fzrel1STSw8Wl2UkRlzunkTJZucfXtznv04xRRWkdrkPc5Wae7vJXmlaWZycs5BNVw8hPQ0UVNih4kcdakEhxg0UUr2AQyA1PDlg6rgl1Cj8SKKKG9AR1Wv6VeeHbKygk1SW5tJBKqxMu1QwUDIGTkfMfp+Ncg85xhaKKmGw9zRdwdVtV7NFbpge8aA/zrNDEE0UVbZKN7TbpngQbWzFDsU9Od7nI/76qlf3NqsksuAZsBfXHFFFZPdnWpP2aOekYzTPIAfmPGKlhQjrx7UUVcUczP/9k=\"},\"timestamp\":\"2024-01-21 13:48:11\",\"ipay_uuid\":\"h0059b24d5c1-a21c-4bb8-8fb8-0f739e20c24a-XApdeDrgRhmX\",\"orderid\":\"1240121134810UEMVR\",\"environment\":\"LIVE\"}";
                    JObject responseObject = JObject.Parse(jsonResponse);

                    if (responseObject["statuscode"].ToString() == "TXN")
                    {
                        JObject dataObject = (JObject)responseObject["data"];
                        HttpContext.Current.Session["data"] = dataObject;
                        string outletid = dataObject["outletId"].ToString();

                        string name = (string)dataObject["name"];
                        string dateOfBirth = (string)dataObject["dateOfBirth"];
                        string gender = (string)dataObject["gender"];
                        string pincode = (string)dataObject["pincode"];
                        string state = (string)dataObject["state"];
                        string districtName = (string)dataObject["districtName"];
                        string address = (string)dataObject["address"];
                        string profilePic = (string)dataObject["profilePic"];
                        string usermobile = HttpContext.Current.Session["usermobile"].ToString();
                        string pannumber = HttpContext.Current.Session["pannumber"].ToString();
                        string adharnumber = HttpContext.Current.Session["adharnumber"].ToString();

                        //string base64 = profilePic.Split('_')[1];//szName.Split(',')[1];
                        byte[] bytes = Convert.FromBase64String(profilePic);
                        string filenm = System.DateTime.Now.ToString("ddMMyyyyhhmmss") + userid + ".png";
                        string filePath = string.Format(@"~/Addharimg/" + filenm, Path.GetRandomFileName());

                        File.WriteAllBytes(HttpContext.Current.Server.MapPath(filePath), bytes);
                        DataTable dTable = docdatasave(usermobile, name, dateOfBirth, gender, pincode, state, districtName, address, profilePic, pannumber, adharnumber, outletid);

                        if (jsonResponse != "N" && jsonResponse != null)
                        {
                            JObject jObjecttop = JObject.Parse(jsonResponse);
                            if (jObjecttop["status"].ToString().Contains("Successful"))
                            {
                                //myJson.addItem("status", "200");
                                //myJson.addItem("name", jObjecttop["data"]["name"].ToString());
                                //myJson.addItem("sentmsg", "Successful");
                                //binddata();
                                string mmid = dTable.Rows[0]["mdata"].ToString();
                                diverr.Visible = true;
                                diverr.Attributes.Add("class", "alert alert-success alert-dismissible bg-success text-white border-0 fade show");
                                lblmessgae.InnerHtml = "Successful";
                                string mydata = "success.aspx?id=" + mmid + "&address=0";
                                Response.Redirect(mydata);

                            }
                            else
                            {
                                submit.Visible = false;
                                btnchkotp.Visible = true;
                                diverr.Visible = true;
                                divotp.Visible = true;
                                diverr.Attributes.Add("class", "alert alert-danger alert-dismissible bg-danger text-white border-0 fade show");
                                lblmessgae.InnerHtml = "Invalid OTP";
                            }
                        }
                        else
                        {
                            submit.Visible = false;
                            btnchkotp.Visible = true;
                            diverr.Visible = true;
                            divotp.Visible = true;
                            diverr.Attributes.Add("class", "alert alert-danger alert-dismissible bg-danger text-white border-0 fade show");
                            lblmessgae.InnerHtml = "Invalid OTP";
                        }
                    }
                    else
                    {
                        submit.Visible = true;
                        btnchkotp.Visible = false;
                        diverr.Visible = true;
                        divotp.Visible = true;
                        diverr.Attributes.Add("class", "alert alert-danger alert-dismissible bg-danger text-white border-0 fade show");
                        lblmessgae.InnerHtml = responseObject["status"].ToString();
                    }
                }
                else
                {
                    diverr.Visible = true;
                    divotp.Visible = true;
                    diverr.Attributes.Add("class", "alert alert-danger alert-dismissible bg-danger text-white border-0 fade show");
                    lblmessgae.InnerHtml = "Please enter OTP";
                }
            }
            else
            {
                diverr.Visible = true;
                diverr.Attributes.Add("class", "alert alert-danger alert-dismissible bg-danger text-white border-0 fade show");
                lblmessgae.InnerHtml = "Incorrect Data";
            }
        }
        catch (Exception ex)
        {
            diverr.Visible = true;
            diverr.Attributes.Add("class", "alert alert-danger alert-dismissible bg-danger text-white border-0 fade show");
            lblmessgae.InnerHtml = "Sometime went worng, Please try after sometime.";// +ex.ToString();
        }
    }



    public static DataTable docdatasave(string usermobile, string name, string dateOfBirth, string gender, string pincode, string state, string districtName, string address, string filenm, string pannumber, string adharnumber, string outletid)
    {
        try
        {
            MySqlParameter[] prm = new MySqlParameter[12];
            prm[0] = new MySqlParameter("_usermobile", usermobile.Trim());
            prm[1] = new MySqlParameter("_name", name.Trim());
            prm[2] = new MySqlParameter("_dateOfBirth", dateOfBirth.Trim());
            prm[3] = new MySqlParameter("_gender", gender.Trim());
            prm[4] = new MySqlParameter("_pincode", pincode.Trim());
            prm[5] = new MySqlParameter("_state", state.Trim());
            prm[6] = new MySqlParameter("_districtName", districtName.Trim());
            prm[7] = new MySqlParameter("_address", address.Trim());
            prm[8] = new MySqlParameter("_filenm", filenm.Trim());
            prm[9] = new MySqlParameter("_pannumber", pannumber.Trim());
            prm[10] = new MySqlParameter("_adharnumber", adharnumber.Trim());
            prm[11] = new MySqlParameter("_outletid", outletid.Trim());

            DataSet dSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "vksp_onboardingdatasave", prm);
            return dSet.Tables[0];
        }
        catch (Exception ea)
        { throw; }
    }

    public static string postMethodAll1(string baseUrl, string prms)
    {

        HttpWebRequest httpWReq = null;
        string url = "http://apins.simplemudra.in/Onboard.aspx";
        string responseString = string.Empty;
        try
        {
            httpWReq = (HttpWebRequest)WebRequest.Create(url);

            ASCIIEncoding encoding = new ASCIIEncoding();
            byte[] PostData = encoding.GetBytes(prms);
            httpWReq.Method = "POST";
            httpWReq.ContentType = "application/x-www-form-urlencoded";
            //	httpWReq.Headers.Add("apikey", "ede5f47d9169822f810a275ce55ca408");
            httpWReq.ContentLength = PostData.Length;
            using (Stream stream = httpWReq.GetRequestStream())
            {
                stream.Write(PostData, 0, PostData.Length);
            }
            HttpWebResponse response = (HttpWebResponse)httpWReq.GetResponse();
            responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
        }
        catch (Exception ea)
        {
            //objConn.LogWrite("Exception -" + ea.ToString(), "_Login");
            responseString = "N";
        }
        return responseString;
    }

    //public string postMethodAll(string baseUrl, string prms)
    //{
    //	HttpWebRequest httpWReq = null;
    //	string url = baseUrl;
    //	string responseString = string.Empty;
    //	try
    //	{
    //		httpWReq = (HttpWebRequest)WebRequest.Create(url);
    //
    //		ASCIIEncoding encoding = new ASCIIEncoding();
    //		byte[] PostData = encoding.GetBytes(prms);
    //		httpWReq.Method = "POST";
    //		httpWReq.ContentType = "application/x-www-form-urlencoded";
    //		httpWReq.Headers.Add("apikey", "ede5f47d9169822f810a275ce55ca408");
    //		httpWReq.ContentLength = PostData.Length;
    //		using (Stream stream = httpWReq.GetRequestStream())
    //		{
    //			stream.Write(PostData, 0, PostData.Length);
    //		}
    //		HttpWebResponse response = (HttpWebResponse)httpWReq.GetResponse();
    //		responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
    //	}
    //	catch (Exception ea)
    //	{
    //		//LogWrite("Exception -" + ea.ToString(), "_Login");
    //		responseString = "N";
    //	}
    //	return responseString;
    //}
}