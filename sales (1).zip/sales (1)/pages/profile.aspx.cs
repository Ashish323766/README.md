﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using MySql.Data.MySqlClient;
using System.Data.Odbc;
using System.Configuration;
using BussinessLogic;
using System.Net;
using System.IO;
using System.Text;
using DistributorLogic;
using System.Net.Mail;
using System.Web.Services;
using Newtonsoft.Json.Linq;

public partial class pages_profile : System.Web.UI.Page
{
	DBusinessLogics blog = new DBusinessLogics();
	AdminProperty objProp = new AdminProperty();
	protected void Page_Load(object sender, EventArgs e)
    {
		diverr.Visible = false;
		getServicec();
	}

	public void getServicec()
	{
		try
		{
			if (HttpContext.Current.Session["UserName"] != null)
			{
				string ShopName = HttpContext.Current.Session["UserName"].ToString();
				lblusername.InnerText = ShopName;

				string Mobile = HttpContext.Current.Session["UserMobile"].ToString();
				lblmobile.InnerText = Mobile;

				string ReferId =HttpContext.Current.Session["UserCode"].ToString();
				usid.InnerText = ReferId;
			}
		}
		catch (Exception ea)
		{

		}
	}

	
}