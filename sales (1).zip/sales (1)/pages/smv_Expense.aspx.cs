﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using DistributorLogic;
using MySql.Data.MySqlClient;
using System.Configuration;
public partial class pages_smv_Expense : System.Web.UI.Page
{
    DBusinessLogics blog = new DBusinessLogics();
    AdminProperty objProp = new AdminProperty();
    protected void Page_Load(object sender, EventArgs e)
    {
        diverr.Visible = false;
    }

    protected void txtbtn_Click(object sender, EventArgs e)
    {
        string empfirst = txtempfirst.Value;
        string emplast = txtemplast.Value;
        string id = txtid.Value;
        string deptm = txtdept.Value;
        string mfirst = txtmfirst.Value;
        string mlast = txtmlast.Value;
        string business = txtbusiness.Value;
        string detail = txtdetail.Value;
        string detail_1 = txtdetail1.Value;
        string price_1 = txtprice.Value;
        string price_2 = txtprice1.Value;
        string date_1 = txtdate.Value;
        string date_2 = txtdate1.Value;
        string apply_date = txtapply.Value;
        string ret_date = txtreturn.Value;

        //string fn = System.IO.Path.GetFileName(FileUpload1.PostedFile.FileName);
        //string SaveLocation = Server.MapPath("LoadSlip") + "\\" + fn;

        if (FileUpload1.HasFile)
        {
            string str = FileUpload1.FileName;
            string ss = System.IO.Path.GetExtension(str);
            string finalsname = txtmfirst.Value + '-' + DateTime.Now.ToString("ddMMyyyyhhmmss") + ss;
            FileUpload1.PostedFile.SaveAs(Server.MapPath("~/LoadSlip/" + finalsname));
            string Image = "LoadSlip/" + finalsname;
            objProp.payslip = Image;
        }
        else
        {
            objProp.payslip = "No Image";
        }
        string finalsname1 = objProp.payslip;

        DataTable dTable = docdatasave(empfirst, emplast, id, deptm, mfirst, mlast, business, detail, detail_1, price_1, price_2, date_1, date_2, apply_date, ret_date, finalsname1);
        if (dTable.Rows.Count > 0)
        {
            diverr.Visible = true;
            lblmessgae.InnerHtml = dTable.Rows[0]["result"].ToString();
            txtempfirst.Value = "";
            txtemplast.Value = "";
            txtid.Value = "";
            txtdept.Value = "";
            txtmfirst.Value = "";
            txtmlast.Value = "";
            txtbusiness.Value = "";
            txtdetail.Value = "";
            txtdetail1.Value = "";
            txtprice.Value = "";
            txtprice1.Value = "";
        }
        else
        {
            diverr.Visible = true;
            lblmessgae.InnerHtml = "Please fill up the coloumn";
        }
    }

    public static DataTable docdatasave(string empfirst, string emplast, string id, string deptm, string mfirst, string mlast, string business, string detail,
        string detail_1, string price_1, string price_2, string date_1, string date_2, string apply_date, string ret_date, string finalsname1)
    {
        try
        {
            MySqlParameter[] prm = new MySqlParameter[16];
            prm[0] = new MySqlParameter("_empfirst", empfirst.Trim());
            prm[1] = new MySqlParameter("_emplast", emplast.Trim());
            prm[2] = new MySqlParameter("_id", id.Trim());
            prm[3] = new MySqlParameter("_deptm", deptm.Trim());
            prm[4] = new MySqlParameter("_mfirst", mfirst.Trim());
            prm[5] = new MySqlParameter("_mlast", mlast.Trim());
            prm[6] = new MySqlParameter("_business", business.Trim());
            prm[7] = new MySqlParameter("_detail", detail.Trim());
            prm[8] = new MySqlParameter("_detail_1", detail_1.Trim());

            prm[9] = new MySqlParameter("_price_1", price_1.Trim());
            prm[10] = new MySqlParameter("_price_2", price_2.Trim());
            prm[11] = new MySqlParameter("_date_1", date_1.Trim());
            prm[12] = new MySqlParameter("_date_2", date_2.Trim());
            prm[13] = new MySqlParameter("_apply_date", apply_date.Trim());
            prm[14] = new MySqlParameter("_ret_date", ret_date.Trim());
            prm[15] = new MySqlParameter("_finalsname", finalsname1.Trim());


            DataSet dSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sm_expenses", prm);
            return dSet.Tables[0];
        }
        catch (Exception ea)
        { throw; }
    }
}

