﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BussinessLogic;
using MySql.Data.MySqlClient;
using System.Configuration;
using System.Data;
using System.Web.UI.HtmlControls;


public partial class pages_smv_salary_slip : System.Web.UI.Page
{
    DataTable dt = new DataTable();
    BusinessLogics blog = new BusinessLogics();
    protected void Page_Load(object sender, EventArgs e)
    {
        showdata();
        //string words = ConvertNumbertoWords(Convert.ToInt32(lbltotamount.Text));
        //lblword.Text = words;
    }
    public void showdata()
    {
        string Pkid = HttpContext.Current.Session["UserId"].ToString();
        //string month = DateTime.Today.ToString("MMMM");
       
        DataTable dtable = salary(Pkid);
        
        if (dtable.Rows.Count > 0)
        {
            lblmonth.Text= dtable.Rows[0]["month"].ToString();
            lblbranch.Text= dtable.Rows[0]["work_branch"].ToString();
            lblEmpname.Text = dtable.Rows[0]["emp_name"].ToString();
            txtEmpname.Text = dtable.Rows[0]["emp_name"].ToString();

            lbldate.Text = dtable.Rows[0]["slip_date"].ToString();
            lblEmpcode.Text = dtable.Rows[0]["emp_code"].ToString();
            lblemppf.Text = dtable.Rows[0]["pf_no"].ToString();
            lblempnod.Text = dtable.Rows[0]["no_of_day"].ToString();
            lblempesi.Text = dtable.Rows[0]["esi_no"].ToString();
            lblmop.Text = dtable.Rows[0]["mode_of_pay"].ToString();
            lbldesingantion.Text = dtable.Rows[0]["designation"].ToString();
            lblacc.Text = dtable.Rows[0]["account_no"].ToString();
            lblbasic.Text= dtable.Rows[0]["basic"].ToString();
            lblda.Text= dtable.Rows[0]["DA"].ToString();
            lblhra.Text= dtable.Rows[0]["HRA"].ToString();
            lblwa.Text= dtable.Rows[0]["WA"].ToString();
            lblca.Text= dtable.Rows[0]["CA"].ToString();
            lblcca.Text= dtable.Rows[0]["CCA"].ToString();
            lblma.Text= dtable.Rows[0]["MA"].ToString();
            lblsincentive.Text= dtable.Rows[0]["Sales Incentive"].ToString();
            lblleave.Text = dtable.Rows[0]["Leave Encashment"].ToString();
            lblholiday.Text = dtable.Rows[0]["Holiday Wages"].ToString();
            lblsallowance.Text = dtable.Rows[0]["Special Allowance"].ToString();
            lblbonus.Text = dtable.Rows[0]["Bonus"].ToString();
            lblindividual.Text = dtable.Rows[0]["Individual Incentive"].ToString();
            lblearning.Text = dtable.Rows[0]["Total_earning"].ToString();
            lblpf.Text= dtable.Rows[0]["PF"].ToString();
            lblesi.Text= dtable.Rows[0]["ESI"].ToString();
            lbltds.Text= dtable.Rows[0]["TDS"].ToString();
            lbllop.Text= dtable.Rows[0]["LOP"].ToString();
            lblpt.Text= dtable.Rows[0]["PT"].ToString();
            lblspl.Text= dtable.Rows[0]["SPL. Deduction"].ToString();
            lblewf.Text= dtable.Rows[0]["EWF"].ToString();
            lblcd.Text= dtable.Rows[0]["CD"].ToString();

            lbltotaldeduct.Text = dtable.Rows[0]["Total_deductions"].ToString();
            lbltotamount.Text = dtable.Rows[0]["Total_amount"].ToString();
            string words = ConvertNumbertoWords(Convert.ToInt32(lbltotamount.Text));
            lblword.Text = words;
        }




        else
        {

        }
    }
    public static DataTable salary(string Pkid)
    {
        try
        {
            MySqlParameter[] prm = new MySqlParameter[1];
            prm[0] = new MySqlParameter("_fk_user_id", Pkid.Trim());
           

            DataSet dSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "smv_salary_slip", prm);

            return dSet.Tables[0];

        }
        catch (Exception ea)
        {
            throw;
        }


    }
    public static string ConvertNumbertoWords(int number)
    {
        if (number == 0)
            return "ZERO";
        if (number < 0)
            return "minus " + ConvertNumbertoWords(Math.Abs(number));
        string words = "";

        if ((number / 1000000000) > 0)
        {
            words += ConvertNumbertoWords(number / 1000000000) + " Billion ";
            number %= 1000000000;
        }

        if ((number / 10000000) > 0)
        {
            words += ConvertNumbertoWords(number / 10000000) + " Crore ";
            number %= 10000000;
        }

        if ((number / 1000000) > 0)
        {
            words += ConvertNumbertoWords(number / 1000000) + " MILLION ";
            number %= 1000000;
        }
        if ((number / 1000) > 0)
        {
            words += ConvertNumbertoWords(number / 1000) + " THOUSAND ";
            number %= 1000;
        }
        if ((number / 100) > 0)
        {
            words += ConvertNumbertoWords(number / 100) + " HUNDRED ";
            number %= 100;
        }
        if (number > 0)
        {
            if (words != "")
                words += "AND ";
            var unitsMap = new[] { "ZERO", "ONE", "TWO", "THREE", "FOUR", "FIVE", "SIX", "SEVEN", "EIGHT", "NINE", "TEN", "ELEVEN", "TWELVE", "THIRTEEN", "FOURTEEN", "FIFTEEN", "SIXTEEN", "SEVENTEEN", "EIGHTEEN", "NINETEEN" };
            var tensMap = new[] { "ZERO", "TEN", "TWENTY", "THIRTY", "FORTY", "FIFTY", "SIXTY", "SEVENTY", "EIGHTY", "NINETY" };

            if (number < 20)
                words += unitsMap[number];
            else
            {
                words += tensMap[number / 10];
                if ((number % 10) > 0)
                    words += " " + unitsMap[number % 10];
            }
        }
        return words;
    }



    
}
