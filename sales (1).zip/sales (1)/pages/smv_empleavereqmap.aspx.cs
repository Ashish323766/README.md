﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DistributorLogic;
using MySql.Data.MySqlClient;

public partial class pages_smv_empleavereqmap : System.Web.UI.Page
{
    DBusinessLogics blog = new DBusinessLogics();
    AdminProperty objProp = new AdminProperty();
    protected void Page_Load(object sender, EventArgs e)
    {
        diverr.Visible = false;            
        txtempname.Value = HttpContext.Current.Session["UserName"].ToString();
        
        

    }


    

    protected void txtsubmit_Click(object sender, EventArgs e)
    {
        string  ldate = txtldate.Value;
        string returndate = txtretdate.Value;
        DateTime strt_date = Convert.ToDateTime(ldate);
        DateTime end_date = Convert.ToDateTime(returndate);
        
       
        string empname = txtempname.Value;
        string supvisname = txtsupname.Value;
        string department = txtdptment.SelectedValue;
        
        
       
       
        string descrip = txtdescrip.Value;
        string lbluscode= HttpContext.Current.Session["UserCode"].ToString();

        if (empname != "" && supvisname != "" && department != "" && ldate != "" && returndate != "" && lbluscode != ""  && descrip != "")
        {
            string check = "";
            for (int i = 0; i < CheckBoxList1.Items.Count; i++)
            {
                if (CheckBoxList1.Items[i].Selected)
                {

                    check = check + CheckBoxList1.Items[i].Text + "</br>";
                }

            }
            MySqlDataReader dTable = docdatasave(empname, supvisname, department, ldate, returndate, lbluscode, check, descrip);
        
            if (dTable.Read())
            {
                diverr.Visible = true;
                lblmessgae.InnerHtml = dTable["result"].ToString();
                txtempname.Value = "";
                txtsupname.Value = "";
                txtldate.Value = "";
                txtretdate.Value = "";
                txtdescrip.Value="";
           
            }
            dTable.Close();
        }
        else
        {
            diverr.Visible = true;
            lblmessgae.InnerHtml = "Fill All Columan";
        }
    }
    public static MySqlDataReader docdatasave(string empname, string  supvisname, string department, string  ldate, string
        returndate, string lbluscode, string check, string descrip)
    {
        try
        {
            MySqlParameter[] prm = new MySqlParameter[8];
            prm[0] = new MySqlParameter("_empname", empname.Trim());
            prm[1] = new MySqlParameter("_supvisname", supvisname.Trim());
            prm[2] = new MySqlParameter("_department", department.Trim());
            prm[3] = new MySqlParameter("_ldate", ldate.Trim());
            prm[4] = new MySqlParameter("_returndate", returndate.Trim());
            prm[5] = new MySqlParameter("_lbluscode", lbluscode.Trim());
            
            prm[6] = new MySqlParameter("_resigontoleve", check.Trim());
            prm[7] = new MySqlParameter("_descrip", descrip.Trim());


           MySqlDataReader dSet = DataLayer.ExecuteReader(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "smp_leave_sales", prm);
            return dSet;
        }
        catch (Exception ea)
        { throw; }
    }


}