﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BussinessLogic;
using MySql.Data.MySqlClient;
using System.Configuration;
using System.Data;
using System.Web.UI.HtmlControls;

public partial class pages_smv_emplo_attendence : System.Web.UI.Page
{
    DataTable dt = new DataTable();
    BusinessLogics blog = new BusinessLogics();

    protected void Page_Load(object sender, EventArgs e)
    {

        Button1.Visible = false;
        //  btnsinout.Attributes.Add("value", "Punch-OUT");

        DataSelect();

    }
    public void DataSelect()
    {

        string Pkid1 = HttpContext.Current.Session["UserId"].ToString();
        DataTable dTable1 = AttendanceRecordIn1(Pkid1);
        if (dTable1.Rows.Count > 0)
        {
            string todate = dTable1.Rows[0]["todate"].ToString();
            string month = dTable1.Rows[0]["tomonth"].ToString();
            string Month = DateTime.Today.ToString("MM");
            string Date = DateTime.Today.ToString("dd");
            if (todate == Date && month == Month)
            {
                string type = dTable1.Rows[0]["Att_In"].ToString();
                if (type == "P")
                {
                    txtsubmit.Visible = false;
                    Button1.Visible = true;
                    btnsinout.Visible = true;
                    btnsinout.Attributes.Add("class", "btn btn-danger btn-punch-out");
                    btnsinout.Attributes.Add("value", "Punch-OUT");
                    btnsinout.Attributes.Add("name", "Punch-OUT");
                    btnsinout.InnerHtml = "Punch-OUT";
                    ClientScript.RegisterStartupScript(this.GetType(), "Alert", "successalert('success','Report send successfully','success');", true);
                }
                if (type == "")
                {
                    btnsinout.Visible = true;
                    txtsubmit.Visible = false;
                    Button1.Visible = true;
                }
                string type1 = dTable1.Rows[0]["Att_out"].ToString();
                if (type1 == "I")
                {

                    btnsinout.Visible = false;
                }

            }

        }


    }


    public static DataTable AttendanceRecordIn1(string Pkid)
    {
        try
        {
            MySqlParameter[] prm = new MySqlParameter[1];
            prm[0] = new MySqlParameter("_fk_user_id", Pkid.Trim());
            DataSet dSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "smp_attendances", prm);
            return dSet.Tables[0];
        }
        catch (Exception ea) { throw; }
    }



    protected void txtsubmit_Click(object sender, EventArgs e)
    {

        punchIn();
    }
    protected void txtsubmit1_Click(object sender, EventArgs e)
    {

        punchOut();
    }
    public void punchIn()
    {
        string latitude = lat.Value;
        string longitude = lng.Value;
        string Type = "P";
        string Pkid = HttpContext.Current.Session["UserId"].ToString();
        //string in_out = btnsinout.Value;
        DataTable dTable = AttendanceInsert(Pkid, latitude, longitude, Type);
        if (dTable.Rows.Count > 0)
        {
            txtsubmit.Visible = false;
            Button1.Visible = true;
            btnsinout.Attributes.Add("class", "btn btn-danger btn-punch-out");
            btnsinout.Attributes.Add("value", "Punch-OUT");
            btnsinout.Attributes.Add("name", "Punch-OUT");
            btnsinout.InnerHtml = "Punch-OUT";
            ClientScript.RegisterStartupScript(this.GetType(), "Alert", "successalert('success','Report send successfully','success');", true);
            DataSelect();
        }
        else
        {
            //diverr.Visible = true;
            //lblmessgae.InnerHtml = "Fill All Columan";
        }
    }

    public void punchOut()
    {
        string latitude = lat.Value;
        string longitude = lng.Value;
        string Type = "I";
        string Pkid = HttpContext.Current.Session["UserId"].ToString();

        DataTable dTable = AttendanceInsert(Pkid, latitude, longitude, Type);
        if (dTable.Rows.Count > 0)
        {

            btnsinout.Visible = false;
            DataSelect();

        }
        else
        {
            //diverr.Visible = true;
            //lblmessgae.InnerHtml = "Fill All Columan";
        }
    }

    public static DataTable AttendanceInsert(string Pkid, string latitude, string longitude, string Type)
    {
        try
        {
            MySqlParameter[] prm = new MySqlParameter[4];
            prm[0] = new MySqlParameter("_fk_user_id", Pkid.Trim());
            prm[1] = new MySqlParameter("_latitude", latitude.Trim());
            prm[2] = new MySqlParameter("_longitude", longitude.Trim());
            prm[3] = new MySqlParameter("_type", Type.Trim());



            DataSet dSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sm_attend_insert", prm);

            return dSet.Tables[0];
        }
        catch (Exception ea) { throw; }
    }
}