﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class pages_Dashboard : System.Web.UI.Page
{
	SPBusinessLogics blog = new SPBusinessLogics();
	AdminProperty objProp = new AdminProperty();
	protected void Page_Load(object sender, EventArgs e)
    {
		if (HttpContext.Current.Session["UserId"] != null)
		{
			if (txtdate.Text == "" && txtfromdate.Text == "")
			{
				txtfromdate.Text = DateTime.Today.ToString("yyyy-MM-dd");
				txtdate.Text = DateTime.Today.ToString("yyyy-MM-dd");
			} 
			getServicec();
		}
		else
		{
			//getServicec();
			//Response.Redirect("checkmerchant.aspx");
		}
    }
	
	protected void btngetdata_Click(object sender, EventArgs e)
    {
        try
        {
            getSalesDatas();
        }catch(Exception ea)
        { }
    }
	 public void getSalesDatas()
    {
        try
        {
            string Pkid = HttpContext.Current.Session["UserId"].ToString();
            objProp.UserID = Pkid;
            if (txtdate.Text != "" && txtfromdate.Text !="")
            {
                objProp.fromDate = txtfromdate.Text;
                objProp.toDate = txtdate.Text;
            }else
            {
                objProp.fromDate = DateTime.Today.ToString("yyyy-MM-dd");
                objProp.toDate = DateTime.Today.ToString("yyyy-MM-dd");
            }
            blog.DashboardViewNew(objProp);
            if (objProp.DataSet.Tables[0].Rows.Count > 0)
            {
                //lbldmtsales.InnerText = objProp.DataSet.Tables[0].Rows[0]["DMT"].ToString();
                lbldmtsales1.Value = objProp.DataSet.Tables[0].Rows[0]["DMT"].ToString();
                //lbldmtsales1.Value ="10000";


               // lblrechargesales.InnerText = objProp.DataSet.Tables[0].Rows[0]["RECHARGE"].ToString();
                lblrechargesales1.Value = objProp.DataSet.Tables[0].Rows[0]["RECHARGE"].ToString();
                lblrechargesales2.Value = "95";
                lblrechargesales3.Value = "5";

                //lblbbpssales.InnerText = objProp.DataSet.Tables[0].Rows[0]["BBPS"].ToString();
                lblbbpssales1.Value = objProp.DataSet.Tables[0].Rows[0]["BBPS"].ToString();

               // lblsaleslic.InnerText = objProp.DataSet.Tables[0].Rows[0]["UPI"].ToString();
                lblsaleslic1.Value = objProp.DataSet.Tables[0].Rows[0]["UPI"].ToString();


               // lblsalesaeps.InnerText = objProp.DataSet.Tables[0].Rows[0]["AEPS"].ToString();
                lblsalesaeps1.Value = objProp.DataSet.Tables[0].Rows[0]["AEPS"].ToString();

                //lblmatmsales.InnerText = objProp.DataSet.Tables[0].Rows[0]["MATM"].ToString();
                lblmatmsales1.Value = objProp.DataSet.Tables[0].Rows[0]["MATM"].ToString();

               // lblcmstotal.InnerText = objProp.DataSet.Tables[0].Rows[0]["CMS"].ToString();
                lblcmstotal1.Value = objProp.DataSet.Tables[0].Rows[0]["CMS"].ToString();

            }
            else
            {

            }
        }
        catch (Exception ea)
        {
            string f = ea.Message;
           // ClientScript.RegisterStartupScript(this.GetType(), "Alert", "successalert('Oops','" + f + "','error');", true);
        }
    }

	public void getServicec()
	{
		try
		{
			string Pkid = HttpContext.Current.Session["UserId"].ToString();
			//Authentication.GetUserDetailsByJsonObjectKey("Pkid", out Pkid);
			objProp.UserID = Pkid;
			blog.DashboardView(objProp);
			if (objProp.DataSet.Tables[0].Rows.Count > 0)
			{
				lblretailer.InnerText = objProp.DataSet.Tables[0].Rows[0]["Ret"].ToString();
				lbldistributor.InnerText = objProp.DataSet.Tables[0].Rows[0]["Dist"].ToString();
				lblcnf.InnerText = objProp.DataSet.Tables[0].Rows[0]["CNF"].ToString();
				lblquery.InnerText = objProp.DataSet.Tables[0].Rows[0]["Query"].ToString();
			}
			else
			{

			}
		}
		catch (Exception ea)
		{
			//string f = ea.Message;
			//ClientScript.RegisterStartupScript(this.GetType(), "Alert", "successalert('Oops','" + f + "','error');", true);
		}
	}
}