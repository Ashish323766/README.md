﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using MySql.Data.MySqlClient;
using System.Data.Odbc;
using System.Configuration;
using BussinessLogic;
using System.Net;
using System.IO;
using System.Text;
using DistributorLogic;
using System.Net.Mail;
using System.Web.Services;
using Newtonsoft.Json.Linq;

public partial class pages_smv_attendencereport : System.Web.UI.Page
{
    SPBusinessLogics blog = new SPBusinessLogics();
    AdminProperty objProp = new AdminProperty();
    protected void Page_Load(object sender, EventArgs e)
    {
        //diverr.Visible = false;
        //if(!IsPostBack)			
        //{
        getServicec();
        //}
    }

    public void getServicec()
    {
        try
        {
            if (HttpContext.Current.Session["UserId"] != null)
            {
                string Pkid = HttpContext.Current.Session["UserId"].ToString();
                string month = ddlmonth.SelectedValue;
                DataTable dTable = AttendanceRecordIn(Pkid, month);
                if (dTable.Rows.Count > 0)
                {
                    Repeater1.DataSource = dTable;
                    Repeater1.DataBind();
                    tbldata.Visible = true;
                    error_message.Visible = false;
                }
                else
                {
                    tbldata.Visible = false;
                    error_message.Visible = true;
                    error_message.InnerText = "Data not found";
                }
            }
        }
        catch (Exception ea)
        {

        }
    }
    public static DataTable AttendanceRecordIn(string Pkid, string month)
    {
        try
        {
            MySqlParameter[] prm = new MySqlParameter[2];
            prm[0] = new MySqlParameter("_fk_user_id", Pkid.Trim());
            prm[1] = new MySqlParameter("_month", month.Trim());
            DataSet dSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sm_attendances", prm);
            return dSet.Tables[0];
        }
        catch (Exception ea) { throw; }
    }



    protected void btnsearch_Click(object sender, EventArgs e)
    {
        getServicec();
    }
}