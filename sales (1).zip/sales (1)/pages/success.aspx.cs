﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using MySql.Data.MySqlClient;
using System.Data.Odbc;
using System.Configuration;
using BussinessLogic;
using System.Net;
using System.IO;
using System.Text;
using DistributorLogic;
using System.Net.Mail;
using System.Web.Services;
using Newtonsoft.Json.Linq;
using System.Drawing;
using RestSharp;
public partial class pages_success : System.Web.UI.Page
{
	DBusinessLogics blog = new DBusinessLogics();
	AdminProperty objProp = new AdminProperty();
	protected void Page_Load(object sender, EventArgs e)
    {
		diverr.Visible = false;
		if (HttpContext.Current.Session["adharnumber"]!=null && Request.QueryString["id"]!=null)
		{
			
			getServicec();
		}
		else
		{
			//getServicec();
			Response.Redirect("checkmerchant.aspx");
		}
	}

	public void getServicec()
	{
		try
		{
			//HttpContext.Current.Session["merid"].ToString()
			DataTable dTable = docdatasave(HttpContext.Current.Session["merid"].ToString());
			if(dTable.Rows.Count>0)
			{
				if (dTable.Rows[0]["id"].ToString() == "1")
				{
					lblusername.InnerHtml = dTable.Rows[0]["name"].ToString();
					txtmobiledata.InnerHtml = dTable.Rows[0]["mobileuser"].ToString();
					txtpancard.InnerHtml = dTable.Rows[0]["panno"].ToString();
					txtadhar.InnerHtml = dTable.Rows[0]["aadharno"].ToString();
					txtaddress.InnerHtml = dTable.Rows[0]["address"].ToString();

					objProp.retailerpassword = dTable.Rows[0]["pwd"].ToString();
					objProp.MPin = dTable.Rows[0]["mpin"].ToString();
					objProp.Tpin = dTable.Rows[0]["tpin"].ToString();



					byte[] bytes = Convert.FromBase64String(dTable.Rows[0]["merpick"].ToString());

					using (MemoryStream ms = new MemoryStream(bytes))
					{
						string vivek = Convert.ToBase64String(bytes);
						merprofileimg.Src = "data:image/jpeg;base64," + vivek;
					}

					
					objProp.TYPE = "transactional";
					objProp.MobileNumber = txtmobiledata.InnerHtml.Trim();
					//objProp.Description = "Dear " + objProp.retailername + ",Your id Successfully Created Uisd : " + objProp.MobileNumber + ", password : " + objProp.retailerpassword + ", Mpin : " + objProp.MPin + ", Tpin : " + objProp.Tpin + "Thanks for using Simplemudra";
					objProp.Description = "Dear User," +"Your Simple Mudra account is ready!" +"User ID: " + objProp.MobileNumber +",Password: " + objProp.retailerpassword +",MPIN: " + objProp.MPin +",TPIN: " + objProp.Tpin +",Thank you for choosing Simple Mudra.";
					objProp.templateID = "1107171541409323156";
					postMethodForForgotPassword1(objProp);

					diverr.Visible = true;
					diverr.Attributes.Add("class", "alert alert-success alert-dismissible bg-success text-white border-0 fade show");
					lblmessgae.InnerHtml = "Merchent OnBoarding Successfull Done. Please Upload Documents!<br/><br/> मर्चेंट ऑनबोर्डिंग सफलतापूर्वक संपन्न हुई। कृपया दस्तावेज़ अपलोड करें";
				}
				else
				{
					diverr.Visible = true;
					diverr.Attributes.Add("class", "alert alert-danger alert-dismissible bg-danger text-white border-0 fade show");
					lblmessgae.InnerHtml = dTable.Rows[0]["result"].ToString();
				}

			}
		}
		catch (Exception ea)
		{

		}
	}

    public void btncheckrotp_Click(object sender, EventArgs e)
    {
        if (Request.QueryString["id"] != null)
        {
            string mmi = "https://admin.simplemudra.co.in/kyc/pages/userkyc_detailss.aspx?ctp=D&uno=" + Request.QueryString["id"].ToString();
            //Page.ClientScript.RegisterStartupScript(this.GetType(), "OpenWindow", "window.open("+ mmi + ",'_newtab');", true);
            Response.Redirect("https://admin.simplemudra.co.in/kyc/pages/userkyc_detailss.aspx?ctp=D&uno=" + Request.QueryString["id"].ToString());
        }
    }

    public static DataTable docdatasave(string usermobile)
	{
		try
		{
			MySqlParameter[] prm = new MySqlParameter[1];
			prm[0] = new MySqlParameter("_userid", usermobile.Trim());
			DataSet dSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "sp_get_userimage", prm);
			return dSet.Tables[0];
		}
		catch (Exception ea)
		{ throw; }
	}

	public string postMethodForForgotPassword1(AdminProperty Prop)
	{
		string url = "https://api.trustsignal.io/v1/sms?api_key=808b7316-c52d-4ff6-9e77-7af0974f458a";
		string responseString = string.Empty;
		try
		{
			ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
			var client = new RestClient(url);
			client.Timeout = -1;
			var request = new RestRequest(Method.POST);
			request.AddHeader("Content-Type", "application/json");
			var body = @"{""sender_id"": ""SIMUDR"",""to"": [" + Prop.MobileNumber + @"],""route"": """ + Prop.TYPE + @""",""message"": """ + Prop.Description + @""", ""template_id"": """ + Prop.templateID + @"""}";
			//LogWrite("Request " + body, "_MSG");
			request.AddParameter("application/json", body, ParameterType.RequestBody);
			IRestResponse response = client.Execute(request);
			//LogWrite("Respone " + response.Content, "_MSG");
			responseString = response.Content;

		}
		catch (Exception ea)
		{
			//LogWrite("Exception " + ea.ToString(), "_MSG");
			responseString = "N";
		}
		return responseString;
	}

}