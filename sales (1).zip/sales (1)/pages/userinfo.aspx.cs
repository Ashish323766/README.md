﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Configuration;
using System.Net;
using System.Text;
using System.Web.Services;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using BussinessLogic;
using System.Data;
using System.Web.Script.Serialization;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

public partial class pages_userinfo : System.Web.UI.Page
{
    string jsonResponse = "";
    string ipv4String = "";
    BusinessLogics blog = new BusinessLogics();
    AdminProperty objProp = new AdminProperty();
    protected void Page_Load(object sender, EventArgs e)
    {
        string HostName = Dns.GetHostName();
        IPAddress[] ipaddress = Dns.GetHostAddresses(HostName);
        foreach (IPAddress ip4 in ipaddress.Where(ip => ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork))
        {
            ipv4String = ip4.ToString();
        }

        if (Request.QueryString["icus"] != null)
        {
            var base64EncodedBytes = System.Convert.FromBase64String(Request.QueryString["icus"].ToString());
            jsonResponse = System.Text.Encoding.UTF8.GetString(base64EncodedBytes);
            if (jsonResponse.Split('|').Length == 6)
            {
                //Sandeep|Sandeep|7428727955|harjuniya@gmail.com|3|21
                objProp.firstname = jsonResponse.Split('|')[0];
                objProp.lastname = jsonResponse.Split('|')[1];
                objProp.MobileNumber = jsonResponse.Split('|')[2];
                objProp.EmailAddress = jsonResponse.Split('|')[3];
                objProp.CompanyId = jsonResponse.Split('|')[4];
                objProp.UserId = jsonResponse.Split('|')[5];
                objProp.IpAddress = ipv4String;//Request.UserHostAddress; //jsonResponse.Split('|')[6];
                getcompid(objProp);
            }
            else
            {
                Response.RedirectToRoute("invalid");
            }
        }
        else
        {
            Response.RedirectToRoute("invalid");
        }

    }

    public void getcompid(AdminProperty objProp)
    {
        
        try
        {
            if (objProp.CompanyId != "" && objProp.IpAddress != "")
            {
                objProp.DataSet = blog.getcompurl(objProp);
                if (objProp.DataSet.Tables[0].Rows.Count > 0)
                {
                    Session["curl"] = objProp.DataSet.Tables[0].Rows[0]["url"].ToString();
                    txturl.Value = objProp.DataSet.Tables[0].Rows[0]["url"].ToString();
					
					objProp.firstname = jsonResponse.Split('|')[0];
					objProp.lastname = jsonResponse.Split('|')[1];
                    objProp.MobileNumber = jsonResponse.Split('|')[2];
                    objProp.EmailAddress = jsonResponse.Split('|')[3];
                    objProp.CompanyId = jsonResponse.Split('|')[4];
                    objProp.UserId = jsonResponse.Split('|')[5];
					objProp.CompLogo = objProp.DataSet.Tables[0].Rows[0]["url"].ToString();//jsonResponse.Split(new char[] { '|' }, 8)[6];
                    objProp.IpAddress = ipv4String; //Request.UserHostAddress; //jsonResponse.Split('|')[6];
					
					firstName.InnerHtml =objProp.firstname; //"AMARENDRA KUMAR" ;//
					// lastName.InnerHtml = objProp.lastname;
					lblusermobile.InnerHtml = objProp.MobileNumber;
					emailAddress.InnerHtml = objProp.EmailAddress;

					txtcompid.Value = objProp.CompanyId;
					txtuserid.Value = objProp.UserId;

					lbltxtcompid.InnerHtml = objProp.CompanyId;
					lbltxtuserid.InnerHtml = objProp.UserId;				
					imglogo.ImageUrl="https://kycportal.in/complogo/"+objProp.CompLogo;

                    string geoloc=lbladdress.InnerText;
                    string lat=lbllatitude.InnerText;
                    string longi=lbllongitude.InnerText;
                    string transid = DateTime.Now.ToString("yyyyMMddmmss");

                    pages_userinfo objpg = new pages_userinfo();
                  //  lblalldata.Value = "{\"ResponseCode\":\"1\",\"Message\":\"Success\",\"CompanyDetail\":[{\"IsAdhaarVerified\":\"0\",\"IsAccountVerified\":\"0\",\"IsGstVerified\":\"0\",\"IsPanVerified\":\"1\",\"CompanyId\":\"3\",\"Logo\":\"logo.png\",\"PanName\":\"BGDPK4135Q|Sandeep\",\"GstDetail\":\"\",\"AccountDetail\":\"\"}]}";
                  lblalldata.Value=  objpg.checkuser(objProp.CompanyId, objProp.UserId, objProp.IpAddress, objProp.firstname, "", objProp.MobileNumber, objProp.EmailAddress, geoloc, lat, longi);

                 //  string dd= getCompanyDetails(jsonResponse);                    
					
                }
				else
				{
					Response.RedirectToRoute("invalid");
				}
            }
            else
            {Response.RedirectToRoute("invalid"); }
        }
        catch (Exception ea)
        {
				Response.RedirectToRoute("invalid");
        }
    }

    public void updateStatus(string type,string compid,string userid,string number,string name,string ifsc)
    {
        try 
        {
            BusinessLogics blog = new BusinessLogics();

            objProp.CompanyId = compid;
            objProp.UserId = userid;
            objProp.ServiceType = type;
            objProp.PanNumber = number;
            objProp.UserName = name;
            objProp.ifscCode = ifsc;
            blog.updateStatusOfCompany(objProp);
                       
        }
        catch (Exception ea)
        {
            blog.LogWrite("exception" + ea.ToString(), "_LOG_FILE");
        }
    }
    public void updatePhoto(string compid, string userid, string photo,string type)
    {
        try
        {
            BusinessLogics blog = new BusinessLogics();

            objProp.CompanyId = compid;
            objProp.UserId = userid;
            objProp.ServiceType = type;
            objProp.SelfPhoto = photo;
            blog.updatePhotoOfCompany(objProp);

        }
        catch (Exception ea)
        {
            blog.LogWrite("exception" + ea.ToString(), "_LOG_FILE");
        }
    }
    [WebMethod]
    public static string getCompanyDetails(string request)
    {
      //  string jsonResponse = "";
        MyJson myJson = new MyJson();
        JObject jObject = JObject.Parse(request);

        if (jObject["ResponseCode"].ToString() != "1")
        {
            return myJson.error(jObject["Message"].ToString());
        }

        if (jObject["Message"].ToString().Contains("Success"))
        {
            myJson.addItem("IsAdhaarVerified", jObject["IsAdhaarVerified"].ToString());
            myJson.addItem("IsAccountVerified", jObject["IsAccountVerified"].ToString());
            myJson.addItem("IsGstVerified", jObject["IsGstVerified"].ToString());
            myJson.addItem("IsPanVerified", jObject["IsPanVerified"].ToString());
            myJson.addItem("CompanyId", jObject["CompanyId"].ToString());
            myJson.addItem("Logo", jObject["Logo"].ToString());
            myJson.addItem("PanName", jObject["PanName"].ToString());
            myJson.addItem("GstDetail", jObject["GstDetail"].ToString());
            myJson.addItem("AccountDetail", jObject["AccountDetail"].ToString());
            myJson.addItem("RespCode", jObject["ResponseCode"].ToString());
            myJson.addItem("Message", jObject["Message"].ToString());

            return myJson.success("1");
        }
        else
        {
            return myJson.success("0");
        }
    }

    [WebMethod]
    public static string checkPanCardDetails(string pan,string cid,string usid)
    {
        string jsonResponse = "";
        MyJson myJson = new MyJson();

        try
        {
            pan = pan.ToUpper().Trim();
            if (pan.Length != 10)
            {
                return myJson.error("Please enter valid pan number.");
            }

            if (!Miscellaneous.isAllPanDigits(pan))
            {
                return myJson.error("Please enter valid pan number.");
            }

            StringBuilder sb = new StringBuilder();
            string ff = "{\"data\": {\"customer_pan_number\": \"@" + pan + "\",\"consent\": \"Y\",\"consent_text\": \"Dubey Password Dubey Password Dubey PasswordDubey Password Dubey Password Dubey Password Dubey Password\"}}";
            String actualString = ff.Replace("\"@", "\"");
            sb.Append(actualString);

         /*     jsonResponse = "{\"request_id\": \"1a0ce7a8-c010-48ef-90c4-2466af0f1118\",\"task_id\": \"fa4a2132-fd24-449a-9107-c5bf7a935072\",\"group_id\":\"a2731f3f-d994-436e-9430-be51bf33cc9e\","+
                   "\"success\": true,\"response_code\": \"100\",\"response_message\": \"Valid Authentication\",\"metadata\": {\"billable\": \"Y\"},"+
                   "\"result\": {\"pan_number\": \"BGDPK4135Q\",\"pan_status\": \"VALID\",\"user_full_name\": \"Sandeep\"},\"request_timestamp\": \"2021-11-18T07:04:09.982Z\","+
                   "\"response_timestamp\": \"2021-11-18T07:04:10.897Z\"}";
            */          

            jsonResponse = PanApiHttpRequest.PostRequest(sb.ToString());

            JObject jObject = JObject.Parse(jsonResponse);

            if (jObject["response_code"].ToString() != "100")
            {
                return myJson.error("Unable to fetch details, Please try again later.");
            }

            if (jObject["response_message"].ToString().Contains("Valid Authentication"))
            {
                myJson.addItem("name", jObject["result"]["user_full_name"].ToString());
                //  myJson.addItem("mobile", jObject["mobile"].ToString());

                //(string type,string compid,string userid,string number,string name,string ifsc)

                pages_userinfo objpg = new pages_userinfo();
                string name = jObject["result"]["user_full_name"].ToString();
               // string userid = usid;
                objpg.updateStatus("1", cid, usid,pan,name,"");
                return myJson.success("1");
            }
            else
            {
                myJson.addItem("pan", pan);
                return myJson.success("0");
            }

        }
        catch (Exception ex)
        {
           // return myJson.error(jsonResponse);
             return myJson.communication_error();
        }
    }

    [WebMethod]
    public static string checkAdhaarCardDetails(string adhar, string usname, string email, string regaddress, string uphoto, string geoloc, string lati, string longi, string pan, string mob, string cid, string usid)
    {
        string jsonResponse = "";
        MyJson myJson = new MyJson();
        string pdfString = "";
        try
        {
            adhar = adhar.Trim();
            if (adhar.Length != 12)
            {
                return myJson.error("Please enter valid aadhaar number.");
            }

            pages_userinfo objpg = new pages_userinfo();
            //saveUserpic
            string uphoto1 = "";
            //create pdf
            string pdfName = pan.ToUpper();//+ "_" + System.DateTime.Now.ToString();
            pdfString = objpg.createpdf(usname, regaddress, uphoto, geoloc, lati, longi, adhar, pan);
            objpg.savepdf(pdfName, pdfString);
            //get pdf
            string yourFile = HttpContext.Current.Server.MapPath(@"~/kycpdf/" + pdfName + ".pdf");
            byte[] AsBytes = File.ReadAllBytes(yourFile);
            String pdfBase64 = Convert.ToBase64String(AsBytes); //"JVBERi0xLjQKJeLjz9MKMiAwIG9iaiA8PC9MZW5ndGggNTQvRmlsdGVyL0ZsYXRlRGVjb2RlPj5zdHJlYW0KeJwr5HIK4TI0ULAwNlIISeEyUNA1tAAx9N0MFUCsNC4N70hnzZAsoJQBSMI1hCuQCwA2YwtXCmVuZHN0cmVhbQplbmRvYmoKNCAwIG9iajw8L1R5cGUvUGFnZS9NZWRpYUJveFswIDAgNTk1IDg0Ml0vUGFyZW50IDMgMCBSL0NvbnRlbnRzIDIgMCBSL1Jlc291cmNlczw8L0ZvbnQ8PC9GMSAxIDAgUj4+L1Byb2NTZXQgWy9QREYgL1RleHQgL0ltYWdlQiAvSW1hZ2VDIC9JbWFnZUldPj4+PgplbmRvYmoKMSAwIG9iajw8L1R5cGUvRm9udC9TdWJ0eXBlL1R5cGUxL0Jhc2VGb250L0hlbHZldGljYS9FbmNvZGluZy9XaW5BbnNpRW5jb2Rpbmc+PgplbmRvYmoKMyAwIG9iajw8L1R5cGUvUGFnZXMvS2lkc1s0IDAgUl0vQ291bnQgMT4+CmVuZG9iago1IDAgb2JqPDwvUGFnZXMgMyAwIFIvVHlwZS9DYXRhbG9nPj4KZW5kb2JqCjYgMCBvYmo8PC9DcmVhdGlvbkRhdGUoRDoyMDIxMTIwNDE4MTgwOSswNSczMCcpL1Byb2R1Y2VyKGlUZXh0U2hhcnAgNC4xLjIgXChiYXNlZCBvbiBpVGV4dCAyLjEuMnVcKSkvTW9kRGF0ZShEOjIwMjExMjA0MTgxODA5KzA1JzMwJyk+PgplbmRvYmoKeHJlZgowIDcKMDAwMDAwMDAwMCA2NTUzNSBmIAowMDAwMDAwMjkxIDAwMDAwIG4gCjAwMDAwMDAwMTUgMDAwMDAgbiAKMDAwMDAwMDM3OCAwMDAwMCBuIAowMDAwMDAwMTM1IDAwMDAwIG4gCjAwMDAwMDA0MjggMDAwMDAgbiAKMDAwMDAwMDQ3MiAwMDAwMCBuIAp0cmFpbGVyCjw8L1NpemUgNy9JbmZvIDYgMCBSL0lEIFs8NTgxMmIxZGEzZTBmMzc1Y2NhNWRjMDlkMWQ4YWI1ZjA+PGFjNjgwNTM0ZGQ1ZmYxZDY5ZWI2ODFhNDJjNmU3ZTRhPl0vUm9vdCA1IDAgUj4+CnN0YXJ0eHJlZgo2MTUKJSVFT0YK";

            StringBuilder sb = new StringBuilder();
            string city = "Ghaziabad";
            string infoid = "TWVyY2hhbnQgKEFtYXJlbmRyYSBLdW1hcikgYW5kIGNvbXBhbnkgKFZpc2VzaCBJbmZvc3lzdGVtcyBMdGQpIEFncmVlbWVudA==";
            string ff = "{\"document\": {\"data\": \"@" + pdfBase64 + "\",\"info\": \"@" + infoid + "\",\"sign\": [{\"page_num\": 0,\"x_coord\":100,\"y_coord\":300}]},\"signer_name\": \"@" + usname + "\",\"signer_email\": \"@" + email + "\",\"signer_city\": \"@" + city + "\",\"purpose\": \"Merchant and Company Agreement\",\"response_url\": \"https://ekyc.indiacard.in/callback.aspx\"}";
            String actualString = ff.Replace("\"@", "\"");
            sb.Append(actualString);
            
        /*   jsonResponse = "{\"request_id\": \"61b8c4cedc0746749b6006bc\",\"success\": true,\"webhook_security_key\": \"7d7a39a4-cbbc-4521-8418-475ceb826db8\",\"request_timestamp\": \"2021-11-18T14:09:28.961Z\"," +
                                               "\"expires_at\": \"2021-11-18T14:19:28.961Z\"}" ;
              */                               

     jsonResponse = AdhaarApiHttpRequest.PostRequest(sb.ToString());



            if (!string.IsNullOrEmpty(jsonResponse))
            {
                objpg.updateStatus("3", cid, usid, adhar, "", "");

                return myJson.success(jsonResponse);
            }
            else
            {
                
                myJson.addItem("adhaar", adhar);
                return myJson.success("0");
            }

        }
        catch (Exception ex)
        {
            // return myJson.error(jsonResponse);
            return myJson.communication_error();
            //return myJson.success("1");
        }
    }

    public string createpdf(string uname, string regAddress, string uphoto, string geoloc, string lati, string longi, string adhaar, string pan)
    {
         StringBuilder sb = new StringBuilder();
        sb.Append("<html><header class='clearfix' >");
        sb.Append("<center><h2>E-KYC</h2></center>");
        sb.Append("</header><body style='background-color: #fff;'>");
        sb.Append("<center><div style='width:80%;padding:10px'>");
        sb.Append("<table style='font-family: arial, sans-serif; border-collapse: collapse;  width: 100%;background-color: #fff;text-align:center'><tr><td style='border:1px solid #fff;background-color: #fff;'>");
        sb.Append("<center><img height='200' width='150' src='" + uphoto + @"'/></center>");
        sb.Append("</td></tr></table><br/>");
        sb.Append("<table cellpadding='5' cellspacing='0' style='width:70%;border: 1px solid #000;border-collapse: collapse;background-color: #fff;'>");
        sb.Append("<tbody style='background-color: #fff;'>");
        sb.Append("<tr>");
        sb.Append("<td style='border: 1px solid #000; text-align: left; padding: 8px;background-color: #fff;'>");
        sb.Append("<table style='width:100%;background-color: #fff;'>");
        sb.Append("<tr>");
        sb.Append("<td style='width:150px;border: 1px solid #000;background-color: #fff;'>Name  </td><td style='width:350px;text-align:left;border: 1px solid #000;background-color: #fff;'>" + uname + "</td>");
        sb.Append("</tr>");
        sb.Append("<tr>");
        sb.Append("<td style='width:150px;border: 1px solid #000;background-color: #fff;'>Register Address  </td><td style='border: 1px solid #000;background-color: #fff;'>" + regAddress + "</td>");
        sb.Append("</tr>");
        sb.Append("<tr>");
        sb.Append("<td style='width:150px;border: 1px solid #000;background-color: #fff;'>Geo Location  </td><td style='border: 1px solid #000;background-color: #fff;'>" + geoloc + "</td>");
        sb.Append("</tr>");
        sb.Append("<tr>");
        sb.Append("<td style='width:150px;border: 1px solid #000;background-color: #fff;'>Latitude  </td><td style='border: 1px solid #000;background-color: #fff;'>" + lati + "</td>");
        sb.Append("</tr>");
        sb.Append("<tr>");
        sb.Append("<td style='width:150px;border: 1px solid #000;background-color: #fff;'>Longitude  </td><td style='border: 1px solid #000;background-color: #fff;'>" + longi + "</td>");
        sb.Append("</tr>");
        sb.Append("</table>");
        sb.Append("</td>");
        sb.Append("</tr>");
        sb.Append("<tr>");
        sb.Append("<th colspan='5' ><center>( At the time of KYC or Retailer shop location )</center></th>");
        sb.Append("</tr>");
        sb.Append("<tr>");
        sb.Append("<th colspan='5' style='background-color: #dddddd;'><b style='float:left'>Aadhaar Card Number</b></th>");
        sb.Append("</tr>");
        sb.Append("<tr>");
        sb.Append("<th colspan='5' style='background-color: #fff;'><b style='float:left;font-size:20px;margin-top:5px'>" + adhaar + "</b></th>");
        sb.Append("</tr>");
        sb.Append("<tr>");
        sb.Append("<th colspan='5' style='background-color: #dddddd;'><b style='float:left'>Pan Card Number</b></th>");
        sb.Append("</tr>");
        sb.Append("<tr>");
        sb.Append("<th colspan='5' style='background-color: #fff;'><b style='float:left;font-size:20px;margin-top:5px'>" + pan.ToUpper() + "</b></th>");
        sb.Append("</tr>");
        sb.Append("</tbody>");
        sb.Append("</table>");
        sb.Append("<div id='agreement'>");
        sb.Append("<div><br/></div>");
        sb.Append("<div ><table style='width:500px;border:1px solid #fff;background-color: #fff;'><tr><td style='width:40px;border:1px solid #fff;background-color: #fff;text-align-right'><center><img height='30' width='30' src='https://indiacard.in/images/oie_M3zrupHoucCO.png'/>&nbsp;<span>By signing this , I agree with below aggreement.</span></center></td></tr></table></div>");
        sb.Append("</div></center>");
        sb.Append("<br/>");
        sb.Append("<footer>");
        sb.Append("<table align='center' style='background-color: #fff;'><tr><td  style='border:1px solid #fff'><center><div style='margin-top:20px'>E-sign Issued By</div></center></td></tr>");
        sb.Append("<tr><td  style='border:1px solid #fff'><center><div style='margin-top:0px'>NSDL e-Governance Infrastructure Limited</div><center></td></tr>");
        sb.Append("<tr><td  style='border:1px solid #fff'><center><div style='margin-top:0px'></div><center></td></tr>");
        sb.Append("<tr><td  style='border:1px solid #fff'><center><div style='margin-top:0px'></div><center></td></tr></table>");
        sb.Append("</footer></div> </body></html>");
        string pdfString = sb.ToString();
        return pdfString;
    }

    public void savepdf(string pan, string pdfString)
    {
        string pdf = "";
        FileStream file = null;
        Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 10f, 0f);
        try
        {
            string dtm = DateTime.Now.ToString("yyyyMMddhss");
            StringReader sr = new StringReader(pdfString);

            HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
            using (MemoryStream memoryStream = new MemoryStream())
            {
                if (!Directory.Exists(Server.MapPath(@"~/kycpdf/")))
                {
                    Directory.CreateDirectory(Server.MapPath(@"~/kycpdf/"));
                }
                file = new FileStream(Server.MapPath(@"~/kycpdf/") + pan.ToUpper() + ".pdf", FileMode.Create, System.IO.FileAccess.Write);

                PdfWriter writer = PdfWriter.GetInstance(pdfDoc, file);
                pdfDoc.Open();

                htmlparser.Parse(sr);
                writer.CloseStream = false;
                pdfDoc.Close();
                file.Close();
                memoryStream.Close();
            }
        }
        catch (Exception ea)
        {

            pdf = ea.ToString();
            pdfDoc.Close();
            file.Close();

        }
    }


    [WebMethod]
    public static string saveImgpdf1(string immg, string pan,string compid,string userid)
    {
        string ppn = "";
        try
        {
            ppn = pan.ToUpper();
            string szName = immg;
            //  string bs64=HttpContext.Current.
            string base64 = szName.Split(',')[1];//HttpContext.Current.Request.Form["txtimgurl"].Split(',')[1];// Request.Form["txtimgurl"].Split(',')[1];//Request.Form[hfImageData.UniqueID].Split(',')[1];
            byte[] bytes = Convert.FromBase64String(base64);
            string filePath = string.Format(@"~/userpic/" + pan.ToUpper() + ".png", Path.GetRandomFileName());
            string filenm = pan.ToUpper() + ".png";
            File.WriteAllBytes(HttpContext.Current.Server.MapPath(filePath), bytes);

            //save img
            //updatePhoto(string compid, string userid, string photo,string type)
            pages_userinfo objpg = new pages_userinfo();
            objpg.updatePhoto(compid, userid, filenm,"1");

        }
        catch (Exception ea) { }
        return ppn;
    }

    public void saverecord(string compid, string usid1, string transid, string fname, string lname, string mob, string email, string regAddress, string uphoto, string geoloc, string lati, string longi, string adhaar, string pan, string ispanverify, string isadverify, string acc, string ifsc)
    {
        BusinessLogics blog = new BusinessLogics();
        var panBytes = System.Text.Encoding.UTF8.GetBytes(pan);
        string encryptpan = System.Convert.ToBase64String(panBytes);
        var adBytes = System.Text.Encoding.UTF8.GetBytes(adhaar);
        string encryptad = System.Convert.ToBase64String(adBytes);

        try
        {


            objProp.CompanyId = compid;
            objProp.UserId = usid1;
            objProp.TransId = transid;
            objProp.firstname = fname;
            objProp.lastname = lname;
            objProp.MobileNumber = mob;
            objProp.EmailAddress = email;
            objProp.PanNumber = encryptpan;
            objProp.IsPanVerify = ispanverify;
            objProp.AdhaarNumber = encryptad;
            objProp.IsAdharVerify = isadverify;
            objProp.SelfPhoto = uphoto;
            objProp.OfficeAddress = regAddress;
            objProp.GeoLocation = geoloc + ", Latitude : " + lati + ", Longitude : " + longi;
            objProp.accountNumber = acc;
            objProp.ifscCode = ifsc;
            blog.savekyc(objProp);
        }
        catch (Exception ea)
        {
            blog.LogWrite("exception" + ea.ToString() ,"_LOG_FILE");
        }
    }

    [WebMethod]
    public static string checkGstinDetails(string gstin, string cid, string usid)
    {
        BusinessLogics blog = new BusinessLogics();
        MyJson myJson = new MyJson();

        try
        {
            gstin = gstin.Trim();
            if (gstin.Length != 15)
            {
                return myJson.error("Please enter valid GSTIN number.");
            }

            StringBuilder sb = new StringBuilder();
            string ff = "{\"data\": {\"business_gstin_number\": \"@" + gstin + "\",\"consent\": \"Y\",\"consent_text\": \"I hear by declare my consent agreement for fetching my information\"}}";
            String actualString = ff.Replace("\"@", "\"");
            sb.Append(actualString);

        /*    string jsonResponse ="{\"request_id\": \"539f545d-3ff7-4fb7-8d13-ae4484876125\",\"task_id\": \"ba1f6460-c153-4603-8527-d15516ce144e\",\"group_id\":\"9d946f65-4369-4fcf-a50f-e3272ec26b6b\",\"success\": true,\"response_code\": \"100\",  \"response_message\": \"Valid Authentication\",\"metadata\": {\"billable\": \"Y\"},\"result\": {\"business_constitution\": \"Private Limited Company\","+
 "\"business_nature\": [\"Supplier of Services\"],\"central_jurisdiction\": \"RANGE-III\",\"central_jurisdiction_code\": \"UC0503\","+
 "\"current_registration_status\": \"Active\",\"gstin\": \"27AAACQ4198G1Z7\",\"last_updated\": \"19/01/2021\",\"legal_name\": \"QUAGGA TECH PRIVATE LIMITED\","+
 "\"other_business_address\": {\"bnm\": \"\",\"bno\": \"\",\"loc\": \"\",\"ntr\": \"\",\"st\": \"\"},\"primary_business_address\": {\"building_name\": \"\","+
  "\"building_number\": \"\",\"city\": \"\",\"district\": \"Pune\",\"flat_number\": \"1ST AND 2ND FLOOR\",\"latitude\": \"\",\"location\": \"Pune\","+
 "\"longitude\": \"\",\"business_nature\": \"Supplier of Services\",\"pincode\": \"411006\",\"street\": \"SHASTRI NAGAR, YERWADA\",\"state_code\": \"Maharashtra\","+
 "\"buliding_name\": \"OPP. GOLF COURSE\",\"buliding_number\": \"SKY LOFT, CREATICITY MALL\"},\"register_cancellation_date\": \"\",\"register_date\": \"01-07-2017\",\"state_jurisdiction\": \"VADGAON-SHERI_701\",\"state_jurisdiction_code\": \"MHCG1229\",\"tax_payer_type\": \"Regular\",\"trade_name\": \"QUAGGA TECH PRIVATE LIMITED\"},\"request_timestamp\": \"2021-06-23T20:58:33.972Z\",\"response_timestamp\": \"2021-06-23T20:58:34.244Z\"}";

          */
            string jsonResponse = GstinApihttpRequest.PostRequest(sb.ToString());

            blog.LogWrite("jsonResponse: " + jsonResponse, "_LOG_FILE");
            JObject jObject = JObject.Parse(jsonResponse);

            if (jObject["response_code"].ToString() != "100")
            {
                return myJson.error("Unable to fetch details, Please try again later.");
            }

            if (jObject["response_message"].ToString().Contains("Valid Authentication"))
            {
                myJson.addItem("busname", jObject["result"]["business_constitution"].ToString());
                myJson.addItem("isvalid", jObject["response_message"].ToString());
                myJson.addItem("isactive", jObject["result"]["current_registration_status"].ToString());

                //address
                myJson.addItem("flatno", jObject["result"]["primary_business_address"]["flat_number"].ToString());
                myJson.addItem("street", jObject["result"]["primary_business_address"]["street"].ToString());
                myJson.addItem("buildno", jObject["result"]["primary_business_address"]["location"].ToString());
                myJson.addItem("city", jObject["result"]["primary_business_address"]["flat_number"].ToString());
                myJson.addItem("state", jObject["result"]["primary_business_address"]["state_code"].ToString());
                myJson.addItem("pincode", jObject["result"]["primary_business_address"]["pincode"].ToString());

                pages_userinfo objpg = new pages_userinfo();
                string name = jObject["result"]["business_constitution"].ToString();
                string address = jObject["result"]["primary_business_address"]["flat_number"].ToString() + "," + jObject["result"]["primary_business_address"]["street"].ToString() + "," + jObject["result"]["primary_business_address"]["location"].ToString() + "," +
                    jObject["result"]["primary_business_address"]["flat_number"].ToString() + ", " + jObject["result"]["primary_business_address"]["state_code"].ToString() + "-" + jObject["result"]["primary_business_address"]["pincode"].ToString();
                objpg.updateStatus("2", cid, usid, gstin, name, address);

                return myJson.success("1");
            }
            else
            {
                myJson.addItem("gst", gstin);
                return myJson.success("0");
            }

        }
        catch (Exception ex)
        {
            blog.LogWrite("Exception: " + ex.ToString(), "_LOG_FILE");
           //   return myJson.error(ex.ToString());
            return myJson.communication_error();
        }
    }


    [WebMethod]
    public static string checkAccountValidationDetails(string acc, string ifsc, string adhar, string usname, string email, string regaddress, string uphoto, string geoloc, string lati, string longi, string pan, string mob, string cid, string usid)
    {
        MyJson myJson = new MyJson();

        try
        {
            acc = acc.Trim();
            if (acc.Length < 9)
            {
                return myJson.error("Please enter valid account number.");
            }
            pages_userinfo objpg = new pages_userinfo();
            StringBuilder sb = new StringBuilder();
            string ff = "{\"data\": {\"account_number\": \"@" + acc + "\",\"ifsc\": \"@" + ifsc + "\",\"consent\": \"Y\",\"consent_text\": \"I hear by declare my consent agreement for fetching my information\"}}";
            String actualString = ff.Replace("\"@", "\"");
            sb.Append(actualString);

           // string jsonResponse = "{\"request_id\": \"bf42439f-165a-4736-a3d8-a6de1009bfd7\",\"task_id\": \"dad1b2fe-ca02-4c81-bad3-7212340a318c\",\"group_id\":\"4c0b78b6-0dd0-4b05-b096-1e2cc4f5d5e9\",\"success\": true,\"response_code\": \"100\",  \"response_message\": \"Valid Authentication\",\"metadata\": {\"billable\": \"Y\",\"reason_code\": \"TXN\",\"reason_message\": \"Transaction Successful\"},\"result\": {\"bank_ref_no\": \"117502830580\",\"beneficiary_name\": \"RAHUL GUPTA\",\"transaction_remark\": \"Transaction Successful\",   \"verification_status\": \"VERIFIED\"},\"request_timestamp\": \"2021-06-23T20:55:06.214Z\",\"response_timestamp\": \"2021-06-23T20:55:11.554Z\"}";

            string jsonResponse = BankApihttpRequest.PostRequest_Bank(sb.ToString());

            JObject jObject = JObject.Parse(jsonResponse);

            if (jObject["response_code"].ToString() != "100")
            {
                return myJson.error("Unable to fetch details, Please try again later.");
            }

            if (jObject["response_message"].ToString().Contains("Valid Authentication"))
            {
                myJson.addItem("benename", jObject["result"]["beneficiary_name"].ToString());

                string name = jObject["result"]["beneficiary_name"].ToString();
                string compid = cid;//objpg.txtcompid.Value;//"CITY001";
                string usid1 = usid;//objpg.txtuserid.Value;//"R1001";
                string transid = DateTime.Now.ToString("yyyyMMddmmss");
                //  objpg.checkuser(compid, usid1, transid, usname, usname, mob, email, regaddress, uphoto, geoloc, lati, longi, adhar, pan, "Y", "Y", acc, ifsc);

                objpg.updateStatus("4", cid, usid, acc, name, ifsc);
                return myJson.success("1");
            }
            else
            {
                myJson.addItem("acc", acc);
                return myJson.success("0");
            }

        }
        catch (Exception ex)
        {
            //    return myJson.error(ex.ToString());
            return myJson.communication_error();
        }
    }


    // personal details
    public string saverecord_personal(string compid, string usid1, string transid, string fname, string lname, string mob, string email,string geoloc, string lati, string longi)
    {
        string personalString = "";
        BusinessLogics blog = new BusinessLogics();
        try
        {


            objProp.CompanyId = compid;
            objProp.UserId = usid1;
            objProp.TransId = transid;
            objProp.firstname = fname;
            objProp.lastname = lname;
            objProp.MobileNumber = mob;
            objProp.EmailAddress = email;
            objProp.GeoLocation = geoloc + ", Latitude : " + lati + ", Longitude : " + longi;
          objProp.DataSet=  blog.savepersonal(objProp);
          if (objProp.DataSet.Tables[0].Rows.Count > 0)
          {
              if (objProp.DataSet.Tables[0].Rows[0]["id"].ToString() == "Y")
              {
                  personalString = objProp.DataSet.Tables[0].Rows[0]["transid"].ToString();
              }

          }

        }
        catch (Exception ea)
        {
            blog.LogWrite("exception" + ea.ToString(), "_LOG_FILE");
        }
        return personalString;
    }

    public string checkuser(string compid, string usid1, string ipaddress, string fname, string lname, string mob, string email, string geoloc, string lati, string longi)
    {
        object jsonObject = string.Empty;
        string personalString = "";
        BusinessLogics blog = new BusinessLogics();
        DataTable dataTable = new DataTable();
        MyJson myJson = new MyJson();
        List<CompanyDetails> compdels=new List<CompanyDetails> ();
        CompanyResponse objprespnse = new CompanyResponse();
        try
        {   

            objProp.CompanyId = compid;
            objProp.UserId = usid1;
            objProp.IpAddress = ipaddress;
            objProp.firstname = fname;
            objProp.lastname = lname;
            objProp.MobileNumber = mob;
            objProp.EmailAddress = email;
            objProp.GeoLocation = geoloc + ", Latitude : " + lati + ", Longitude : " + longi;
            objProp.Latitude = lati;
            objProp.Longitude = longi;
            objProp.DataSet = blog.companydetails(objProp);
            if (objProp.DataSet.Tables[0].Rows.Count > 0)
            {
                if (objProp.DataSet.Tables[0].Rows[0]["Id"].ToString() == "1")
                {
                    dataTable = objProp.DataSet.Tables[0];
                    var compArray = dataTable.Rows;
                    jsonResponse = "";
                    
                    StringBuilder list = new StringBuilder();

                    for (int x = 0; x < compArray.Count; x++)
                    {
                        CompanyDetails cd = new CompanyDetails();
                        cd.IsAdhaarVerified = compArray[x]["_IsAdhaarVerified"].ToString();
                        cd.IsAccountVerified = compArray[x]["_IsAccountVerified"].ToString();
                        cd.IsGstVerified = compArray[x]["_IsGstVerified"].ToString();
                        cd.IsPanVerified = compArray[x]["_IsPanVerified"].ToString();
                        cd.CompanyId = compArray[x]["CompanyId"].ToString();
                        cd.Logo = compArray[x]["Logo"].ToString();
                        cd.PanName = compArray[x]["PanName"].ToString();
                        cd.GstDetail = compArray[x]["GstDetail"].ToString();
                        cd.AccountDetail = compArray[x]["AccountDetail"].ToString();
                        cd.Photo = compArray[x]["Photo"].ToString();
                        compdels.Add(cd);
                    }
                    objprespnse.ResponseCode = objProp.DataSet.Tables[0].Rows[0]["Id"].ToString();
                    objprespnse.Message = objProp.DataSet.Tables[0].Rows[0]["Result"].ToString();
                    objprespnse.CompanyDetail = compdels;
                }
                else if(objProp.DataSet.Tables[0].Rows[0]["Id"].ToString() == "2")
                {
                    objprespnse.ResponseCode = objProp.DataSet.Tables[0].Rows[0]["Id"].ToString();
                    objprespnse.Message = objProp.DataSet.Tables[0].Rows[0]["Result"].ToString();
                    objprespnse.CompanyDetail = compdels;
                }
                else
                {
                    objprespnse.ResponseCode = objProp.DataSet.Tables[0].Rows[0]["Id"].ToString();
                    objprespnse.Message = objProp.DataSet.Tables[0].Rows[0]["Result"].ToString();
                    objprespnse.CompanyDetail = compdels;
                }
                personalString = new JavaScriptSerializer().Serialize(objprespnse).ToString();
            }
            

        }
        catch (Exception ea)
        {
            blog.LogWrite("exception" + ea.ToString(), "_LOG_FILE");
        }
        return personalString;
    }

    public class CompanyDetails
    {
        public string IsAdhaarVerified { get; set; }
        public string IsAccountVerified { get; set; }
        public string IsGstVerified { get; set; }
        public string IsPanVerified { get; set; }
        public string CompanyId { get; set; }
        public string Logo { get; set; }
        public string PanName { get; set; }
        public string GstDetail { get; set; }
        public string AccountDetail { get; set; }
        public string Photo { get; set; }
    }

    public class CompanyResponse
    {
        public string ResponseCode { get; set; }
        public string Message { get; set; }
        public List<CompanyDetails> CompanyDetail { get; set; }
    }
}