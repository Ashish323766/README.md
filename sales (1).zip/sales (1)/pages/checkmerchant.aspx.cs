﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using MySql.Data.MySqlClient;
using System.Data.Odbc;
using System.Configuration;
using BussinessLogic;
using System.Net;
using System.IO;
using System.Text;
using DistributorLogic;
using System.Net.Mail;
using System.Web.Services;
using Newtonsoft.Json.Linq;

public partial class pages_checkmerchant : System.Web.UI.Page
{
	DBusinessLogics blog = new DBusinessLogics();
	AdminProperty objProp = new AdminProperty();

	protected void Page_Load(object sender, EventArgs e)
    {
		diverr.Visible = false;
	}

	public void getServicec()
	{
		try
		{
			if (txtmobiledata.Value.Length > 9)
			{
				objProp.checkmobile = txtmobiledata.Value;
				if (objProp.checkmobile != "")
				{
					objProp.checkmobile = " and  us_loginid='" + objProp.checkmobile + "'";
				}
				else { objProp.checkmobile = ""; }

				objProp.Query = @"SELECT `us_loginid`,us_name,us_code FROM `aks_user_login` WHERE us_loginid is not null " + objProp.checkmobile + "";
				blog.checkmobile(objProp);

				if (objProp.DataSet.Tables[0].Rows.Count > 0)
				{
					diverr.Visible = true;
					lblmessgae.InnerHtml = "This Mobile Number Already Exists With " + objProp.DataSet.Tables[0].Rows[0]["us_name"].ToString() + " ( " + objProp.DataSet.Tables[0].Rows[0]["us_code"].ToString() + " )";
				}
				else
				{
					diverr.Visible = false;
					Session["merchMobile"] = txtmobiledata.Value.Trim();
					Response.Redirect("addmerchant.aspx");
					//checknumber.Visible = false;
					//updateDisProfile.Visible = true;
					//lblnewmobileno.InnerHtml = txtmobiledata.Value;
					//txtmobilenumber.Value = txtmobiledata.Value;
					//
					//diverror.Visible = false;
					//divsuccess.Visible = false;
				}
			}
			else
			{
				ClientScript.RegisterStartupScript(this.GetType(), "Alert", "successalert('Oops','Please Check Number Length!','error');", true);
			}
		}
		catch (Exception ea)
		{

		}
	}

	public void btncheckretailer_Click(object sender, EventArgs e)
	{
		getServicec();
	}
}