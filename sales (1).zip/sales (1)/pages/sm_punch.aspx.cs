﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BussinessLogic;
using MySql.Data.MySqlClient;
using System.Configuration;
using System.Data;
using System.Web.UI.HtmlControls;

public partial class pages_sm_punch : System.Web.UI.Page
{
    DataTable dt = new DataTable();
    BusinessLogics blog = new BusinessLogics();
    protected void Page_Load(object sender, EventArgs e)
    {
       
        txtsubmit1.Visible = false;
        getdata();
    }

    protected void txtsubmit_Click(object sender, EventArgs e)
    {
        punchin();
    }
    protected void txtsubmit1_Click(object sender, EventArgs e)
    {
        punchout();
    }
    public void punchin()
    {
        string Pkid = HttpContext.Current.Session["UserId"].ToString();
        string latitude = lat.Value;
        string longitude = lat.Value;
        string Type = "P";
        DataTable dtable = AttendanceInsert(Pkid, latitude, longitude, Type);
        if (dtable.Rows.Count > 0)
        {
            btn.Attributes.Add("class", "btn btn-danger");
            btn.Attributes.Add("value", "Punch-Out");
            btn.Attributes.Add("name", "Punch-Out");
            btn.InnerText= "Punch-Out";
            txtsubmit.Visible = false;
            txtsubmit1.Visible = true;
        }
        else
        {
            
        }

    }
    public void punchout()
    {
        string Pkid = HttpContext.Current.Session["UserId"].ToString();
        string latitude = lat.Value;
        string longitude = lat.Value;
        string Type = "I";
        DataTable dtable = AttendanceInsert(Pkid, latitude, longitude, Type);
        if (dtable.Rows.Count > 0)
        {
            btn.Visible = false;
        }
        else
        {
            
        }


    }
    public static DataTable AttendanceInsert(string Pkid, string latitude, string longitude, string Type)
    {
        try
        {
            MySqlParameter[] prm = new MySqlParameter[4];
            prm[0] = new MySqlParameter("_fk_user_id", Pkid.Trim());
            prm[1] = new MySqlParameter("_latitude", latitude.Trim());
            prm[2] = new MySqlParameter("_longitude", longitude.Trim());
            prm[3] = new MySqlParameter("_type", Type.Trim());

            DataSet dSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "smp_punchinsert", prm);

            return dSet.Tables[0];

        }
        catch (Exception ea)
        {
            throw;
        }
    }

    public void getdata()
    {
        string Pkid = HttpContext.Current.Session["UserId"].ToString();
        DataTable dtable = Attendanceselect(Pkid);
        if (dtable.Rows.Count > 0)
        {
            Repeater1.DataSource = dtable;
            Repeater1.DataBind();
            
        }
        if (dtable.Rows.Count > 0)
        {
            string Todate = dtable.Rows[0]["todate"].ToString();
            string month = dtable.Rows[0]["tomonth"].ToString();
            string date = DateTime.Today.ToString("dd");
            string Month = DateTime.Today.ToString("MM");
            if (Todate == date && month == Month)
            {
                string type = dtable.Rows[0]["att_in"].ToString();
                if (type == "P")
                {
                    btn.Visible = true;
                    btn.Attributes.Add("class", "btn btn-danger");
                    btn.Attributes.Add("value", "Punch-Out");
                    btn.Attributes.Add("name", "Punch-Out");
                    btn.InnerHtml = "Punch-Out";
                    txtsubmit.Visible = false;
                    txtsubmit1.Visible = true;

                }
                if (type == "")
                {
                    btn.Visible = true;
                    txtsubmit.Visible = false;
                    txtsubmit1.Visible = true;
                }
                string type1 = dtable.Rows[0]["att_out"].ToString();
                if (type == "I")
                {
                    btn.Visible = false;
                }

            }
        }
        else
        {

        }
    }
    public static DataTable Attendanceselect(string Pkid)
    {
        try
        {
            MySqlParameter[] prm = new MySqlParameter[1];
            prm[0] = new MySqlParameter("_fk_user_id", Pkid.Trim());

            
            DataSet dSet = DataLayer.ExecuteDataset(Convert.ToString(ConfigurationManager.ConnectionStrings["champshopconstr"]), CommandType.StoredProcedure, "smp_punchselect", prm);

            return dSet.Tables[0];

        }
        catch (Exception ea)
        {
            throw;
        }


    }
}