﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Master_Api : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
		if (HttpContext.Current.Session["UserName"] != null)
		{
			lblusername.InnerHtml = HttpContext.Current.Session["UserName"].ToString();
			lbluscode.InnerHtml = HttpContext.Current.Session["UserCode"].ToString();
		}
		else
		{
			Response.Redirect("../index.aspx");
		}
    }
}
